define(["@grafana/data","@grafana/runtime","@grafana/ui","lodash","react"], function(__WEBPACK_EXTERNAL_MODULE__grafana_data__, __WEBPACK_EXTERNAL_MODULE__grafana_runtime__, __WEBPACK_EXTERNAL_MODULE__grafana_ui__, __WEBPACK_EXTERNAL_MODULE_lodash__, __WEBPACK_EXTERNAL_MODULE_react__) { return /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./module.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "../node_modules/css-loader/dist/cjs.js?!../node_modules/postcss-loader/src/index.js?!../node_modules/sass-loader/dist/cjs.js!./css/common.css":
/*!**************************************************************************************************************************************************************!*\
  !*** ../node_modules/css-loader/dist/cjs.js??ref--8-1!../node_modules/postcss-loader/src??ref--8-2!../node_modules/sass-loader/dist/cjs.js!./css/common.css ***!
  \**************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/api.js */ "../node_modules/css-loader/dist/runtime/api.js")(true);
// Module
exports.push([module.i, "pre.gf-formatted-error,\npre.gf-formatted-warning {\n  background: transparent;\n  border: none;\n  padding-bottom: 0;\n  color: #ff6060;\n}\n\npre.gf-formatted-warning,\nspan.gf-formatted-warning {\n  color: #f79520;\n}\n\n.alert-warning {\n  background-image: linear-gradient(90deg, #eb7b18, #eb7b18);\n}", "",{"version":3,"sources":["common.css"],"names":[],"mappings":"AAAA;;EAEE,uBAAuB;EACvB,YAAY;EACZ,iBAAiB;EACjB,cAAc;AAChB;;AAEA;;EAEE,cAAc;AAChB;;AAEA;EACE,0DAA0D;AAC5D","file":"common.css","sourcesContent":["pre.gf-formatted-error,\npre.gf-formatted-warning {\n  background: transparent;\n  border: none;\n  padding-bottom: 0;\n  color: #ff6060;\n}\n\npre.gf-formatted-warning,\nspan.gf-formatted-warning {\n  color: #f79520;\n}\n\n.alert-warning {\n  background-image: linear-gradient(90deg, #eb7b18, #eb7b18);\n}"]}]);



/***/ }),

/***/ "../node_modules/css-loader/dist/cjs.js?!../node_modules/postcss-loader/src/index.js?!../node_modules/sass-loader/dist/cjs.js!./css/query_editor.css":
/*!********************************************************************************************************************************************************************!*\
  !*** ../node_modules/css-loader/dist/cjs.js??ref--8-1!../node_modules/postcss-loader/src??ref--8-2!../node_modules/sass-loader/dist/cjs.js!./css/query_editor.css ***!
  \********************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/api.js */ "../node_modules/css-loader/dist/runtime/api.js")(true);
// Module
exports.push([module.i, ".min-width-10 {\n  min-width: 10rem;\n}\n\n.min-width-12 {\n  min-width: 12rem;\n}\n\n.min-width-20 {\n  min-width: 20rem;\n}\n\n.gf-form-select-wrapper select.gf-form-input {\n  height: 2.64rem;\n}\n\n.gf-form-select-wrapper--caret-indent.gf-form-select-wrapper::after {\n  right: 0.775rem;\n}\n\n.gf-tabs-cognite.active:before,\n.gf-tabs-cognite.active:focus:before,\n.gf-tabs-cognite.active:hover:before {\n  background-image: linear-gradient(90deg, #33b5e5 0, #00b3ff 99%, #1b1b1b);\n}\n\n.custom-query input {\n  font-family: monospace;\n}\n\npre code,\n.help-panel {\n  line-height: 2;\n}\n\n.cognite-dropdown,\n.gf-form-switch {\n  margin-right: 4px;\n}\n\n.gf-dropdown-wrapper {\n  min-width: 200px;\n}\n\n.templateQueryRow {\n  width: 100%;\n  height: 8em;\n  display: flex;\n  margin: 6px;\n}\n\n.templateRow {\n  width: 100%;\n  display: flex;\n  margin: 6px;\n}\n\n.longInputFild > input {\n  width: 38.5em !important;\n}", "",{"version":3,"sources":["query_editor.css"],"names":[],"mappings":"AAAA;EACE,gBAAgB;AAClB;;AAEA;EACE,gBAAgB;AAClB;;AAEA;EACE,gBAAgB;AAClB;;AAEA;EACE,eAAe;AACjB;;AAEA;EACE,eAAe;AACjB;;AAEA;;;EAGE,yEAAyE;AAC3E;;AAEA;EACE,sBAAsB;AACxB;;AAEA;;EAEE,cAAc;AAChB;;AAEA;;EAEE,iBAAiB;AACnB;;AAEA;EACE,gBAAgB;AAClB;;AAEA;EACE,WAAW;EACX,WAAW;EACX,aAAa;EACb,WAAW;AACb;;AAEA;EACE,WAAW;EACX,aAAa;EACb,WAAW;AACb;;AAEA;EACE,wBAAwB;AAC1B","file":"query_editor.css","sourcesContent":[".min-width-10 {\n  min-width: 10rem;\n}\n\n.min-width-12 {\n  min-width: 12rem;\n}\n\n.min-width-20 {\n  min-width: 20rem;\n}\n\n.gf-form-select-wrapper select.gf-form-input {\n  height: 2.64rem;\n}\n\n.gf-form-select-wrapper--caret-indent.gf-form-select-wrapper::after {\n  right: 0.775rem;\n}\n\n.gf-tabs-cognite.active:before,\n.gf-tabs-cognite.active:focus:before,\n.gf-tabs-cognite.active:hover:before {\n  background-image: linear-gradient(90deg, #33b5e5 0, #00b3ff 99%, #1b1b1b);\n}\n\n.custom-query input {\n  font-family: monospace;\n}\n\npre code,\n.help-panel {\n  line-height: 2;\n}\n\n.cognite-dropdown,\n.gf-form-switch {\n  margin-right: 4px;\n}\n\n.gf-dropdown-wrapper {\n  min-width: 200px;\n}\n\n.templateQueryRow {\n  width: 100%;\n  height: 8em;\n  display: flex;\n  margin: 6px;\n}\n\n.templateRow {\n  width: 100%;\n  display: flex;\n  margin: 6px;\n}\n\n.longInputFild > input {\n  width: 38.5em !important;\n}"]}]);



/***/ }),

/***/ "../node_modules/css-loader/dist/runtime/api.js":
/*!******************************************************!*\
  !*** ../node_modules/css-loader/dist/runtime/api.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/*
  MIT License http://www.opensource.org/licenses/mit-license.php
  Author Tobias Koppers @sokra
*/
// css base code, injected by the css-loader
module.exports = function (useSourceMap) {
  var list = []; // return the list of modules as css string

  list.toString = function toString() {
    return this.map(function (item) {
      var content = cssWithMappingToString(item, useSourceMap);

      if (item[2]) {
        return '@media ' + item[2] + '{' + content + '}';
      } else {
        return content;
      }
    }).join('');
  }; // import a list of modules into the list


  list.i = function (modules, mediaQuery) {
    if (typeof modules === 'string') {
      modules = [[null, modules, '']];
    }

    var alreadyImportedModules = {};

    for (var i = 0; i < this.length; i++) {
      var id = this[i][0];

      if (id != null) {
        alreadyImportedModules[id] = true;
      }
    }

    for (i = 0; i < modules.length; i++) {
      var item = modules[i]; // skip already imported module
      // this implementation is not 100% perfect for weird media query combinations
      // when a module is imported multiple times with different media queries.
      // I hope this will never occur (Hey this way we have smaller bundles)

      if (item[0] == null || !alreadyImportedModules[item[0]]) {
        if (mediaQuery && !item[2]) {
          item[2] = mediaQuery;
        } else if (mediaQuery) {
          item[2] = '(' + item[2] + ') and (' + mediaQuery + ')';
        }

        list.push(item);
      }
    }
  };

  return list;
};

function cssWithMappingToString(item, useSourceMap) {
  var content = item[1] || '';
  var cssMapping = item[3];

  if (!cssMapping) {
    return content;
  }

  if (useSourceMap && typeof btoa === 'function') {
    var sourceMapping = toComment(cssMapping);
    var sourceURLs = cssMapping.sources.map(function (source) {
      return '/*# sourceURL=' + cssMapping.sourceRoot + source + ' */';
    });
    return [content].concat(sourceURLs).concat([sourceMapping]).join('\n');
  }

  return [content].join('\n');
} // Adapted from convert-source-map (MIT)


function toComment(sourceMap) {
  // eslint-disable-next-line no-undef
  var base64 = btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap))));
  var data = 'sourceMappingURL=data:application/json;charset=utf-8;base64,' + base64;
  return '/*# ' + data + ' */';
}

/***/ }),

/***/ "../node_modules/decode-uri-component/index.js":
/*!*****************************************************!*\
  !*** ../node_modules/decode-uri-component/index.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var token = '%[a-f0-9]{2}';
var singleMatcher = new RegExp(token, 'gi');
var multiMatcher = new RegExp('(' + token + ')+', 'gi');

function decodeComponents(components, split) {
	try {
		// Try to decode the entire string first
		return decodeURIComponent(components.join(''));
	} catch (err) {
		// Do nothing
	}

	if (components.length === 1) {
		return components;
	}

	split = split || 1;

	// Split the array in 2 parts
	var left = components.slice(0, split);
	var right = components.slice(split);

	return Array.prototype.concat.call([], decodeComponents(left), decodeComponents(right));
}

function decode(input) {
	try {
		return decodeURIComponent(input);
	} catch (err) {
		var tokens = input.match(singleMatcher);

		for (var i = 1; i < tokens.length; i++) {
			input = decodeComponents(tokens, i).join('');

			tokens = input.match(singleMatcher);
		}

		return input;
	}
}

function customDecodeURIComponent(input) {
	// Keep track of all the replacements and prefill the map with the `BOM`
	var replaceMap = {
		'%FE%FF': '\uFFFD\uFFFD',
		'%FF%FE': '\uFFFD\uFFFD'
	};

	var match = multiMatcher.exec(input);
	while (match) {
		try {
			// Decode as big chunks as possible
			replaceMap[match[0]] = decodeURIComponent(match[0]);
		} catch (err) {
			var result = decode(match[0]);

			if (result !== match[0]) {
				replaceMap[match[0]] = result;
			}
		}

		match = multiMatcher.exec(input);
	}

	// Add `%C2` at the end of the map to make sure it does not replace the combinator before everything else
	replaceMap['%C2'] = '\uFFFD';

	var entries = Object.keys(replaceMap);

	for (var i = 0; i < entries.length; i++) {
		// Replace all decoded components
		var key = entries[i];
		input = input.replace(new RegExp(key, 'g'), replaceMap[key]);
	}

	return input;
}

module.exports = function (encodedURI) {
	if (typeof encodedURI !== 'string') {
		throw new TypeError('Expected `encodedURI` to be of type `string`, got `' + typeof encodedURI + '`');
	}

	try {
		encodedURI = encodedURI.replace(/\+/g, ' ');

		// Try the built in decoder first
		return decodeURIComponent(encodedURI);
	} catch (err) {
		// Fallback to a more advanced decoder
		return customDecodeURIComponent(encodedURI);
	}
};


/***/ }),

/***/ "../node_modules/deepdash/getCondense.js":
/*!***********************************************!*\
  !*** ../node_modules/deepdash/getCondense.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


function getCondense(_) {
  function condense(arr) {
    var indexes = [];
    for (var i = 0; i < arr.length; i++) {
      if (!(i in arr)) {
        indexes.push(i);
      }
    }
    var length = indexes.length;

    while (length--) {
      arr.splice(indexes[length], 1);
    }
    return arr;
  }
  return condense;
}

module.exports = getCondense;


/***/ }),

/***/ "../node_modules/deepdash/getCondenseDeep.js":
/*!***************************************************!*\
  !*** ../node_modules/deepdash/getCondenseDeep.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var getCondense = __webpack_require__(/*! ./getCondense.js */ "../node_modules/deepdash/getCondense.js");
var getEachDeep = __webpack_require__(/*! ./getEachDeep.js */ "../node_modules/deepdash/getEachDeep.js");

function getCondenseDeep(_) {
  var eachDeep = getEachDeep(_);
  var condense = getCondense();
  var _each = _.each || _.forArray;
  function condenseDeep(obj, options) {
    options = _.merge(
      {
        checkCircular: false,
      },
      options || {}
    );
    var eachDeepOptions = {
      checkCircular: options.checkCircular,
    };
    var arrays = [];
    //console.log('condenseDeep → eachDeep');
    eachDeep(
      obj,
      function(value, key, parent, context) {
        if (!context.isCircular && _.isArray(value)) { arrays.push(value); }
      },
      eachDeepOptions
    );
    if (_.isArray(obj)) { arrays.push(obj); }
    _each(arrays, condense);
    return obj;
  }
  return condenseDeep;
}

module.exports = getCondenseDeep;


/***/ }),

/***/ "../node_modules/deepdash/getEachDeep.js":
/*!***********************************************!*\
  !*** ../node_modules/deepdash/getEachDeep.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var getIterate = __webpack_require__(/*! ./private/getIterate.js */ "../node_modules/deepdash/private/getIterate.js");

function getEachDeep(_) {
  var iterate = getIterate(_);

  function eachDeep(obj, callback, options) {
    if (callback === undefined) { callback = _.identity; }
    options = _.merge(
      {
        includeRoot: !_.isArray(obj),
        pathFormat: 'string',
        checkCircular: false,
        leavesOnly: false,
      },
      options || {}
    );
    if (options.childrenPath !== undefined) {
      if (!options.includeRoot && options.rootIsChildren === undefined) {
        options.rootIsChildren = _.isArray(obj);
      }
      if (
        !_.isString(options.childrenPath) &&
        !_.isArray(options.childrenPath)
      ) {
        throw Error('childrenPath can be string or array');
      } else {
        if (_.isString(options.childrenPath)) {
          options.childrenPath = [options.childrenPath];
        }
        options.strChildrenPath = options.childrenPath;
        options.childrenPath = [];
        for (var i = options.strChildrenPath.length - 1; i >= 0; i--) {
          options.childrenPath[i] = _.toPath(options.strChildrenPath[i]);
        }
      }
    }
    iterate({
      value: obj,
      callback: callback,
      options: options,
      obj: obj,
    });
    return obj;
  }
  return eachDeep;
}

module.exports = getEachDeep;


/***/ }),

/***/ "../node_modules/deepdash/getExists.js":
/*!*********************************************!*\
  !*** ../node_modules/deepdash/getExists.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


function getExists(_) {
  function exists(obj, path) {
    path = _.isArray(path) ? _.clone(path) : _.toPath(path);
    var key = path.pop();
    var parent = path.length ? _.get(obj, path) : obj;
    return parent !== undefined && key in parent;
  }
  return exists;
}

getExists.notChainable = true;

module.exports = getExists;


/***/ }),

/***/ "../node_modules/deepdash/getFilterDeep.js":
/*!*************************************************!*\
  !*** ../node_modules/deepdash/getFilterDeep.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var getPathToString = __webpack_require__(/*! ./getPathToString.js */ "../node_modules/deepdash/getPathToString.js");
var getEachDeep = __webpack_require__(/*! ./getEachDeep.js */ "../node_modules/deepdash/getEachDeep.js");
var getCondenseDeep = __webpack_require__(/*! ./getCondenseDeep.js */ "../node_modules/deepdash/getCondenseDeep.js");
var getExists = __webpack_require__(/*! ./getExists.js */ "../node_modules/deepdash/getExists.js");

function getFilterDeep(_) {
  // console.log('getFilterDeep:', _);
  var eachDeep = getEachDeep(_);
  var pathToString = getPathToString(_);
  var condenseDeep = getCondenseDeep(_);
  var exists = getExists(_);

  function filterDeep(obj, predicate, options) {
    predicate = _.iteratee(predicate);
    if (!options) {
      options = {};
    } else {
      options = _.cloneDeep(options);
      if (options.leafsOnly !== undefined) {
        options.leavesOnly = options.leafsOnly;
      }
    }
    if (!options.onTrue) {
      options.onTrue = {};
    }
    if (!options.onFalse) {
      options.onFalse = {};
    }
    if (!options.onUndefined) {
      options.onUndefined = {};
    }
    if (options.childrenPath !== undefined) {
      if (options.onTrue.skipChildren === undefined) {
        options.onTrue.skipChildren = false;
      }
      if (options.onUndefined.skipChildren === undefined) {
        options.onUndefined.skipChildren = false;
      }
      if (options.onFalse.skipChildren === undefined) {
        options.onFalse.skipChildren = false;
      }

      if (options.onTrue.cloneDeep === undefined) {
        options.onTrue.cloneDeep = true;
      }
      if (options.onUndefined.cloneDeep === undefined) {
        options.onUndefined.cloneDeep = true;
      }
      if (options.onFalse.cloneDeep === undefined) {
        options.onFalse.cloneDeep = true;
      }
    }
    options = _.merge(
      {
        checkCircular: false,
        keepCircular: true,
        //replaceCircularBy: <by>,
        leavesOnly: options.childrenPath === undefined,
        condense: true,
        cloneDeep: _.cloneDeep,
        pathFormat: 'string',
        onTrue: { skipChildren: true, cloneDeep: true, keepIfEmpty: true },
        onUndefined: {
          skipChildren: false,
          cloneDeep: false,
          keepIfEmpty: false,
        },
        onFalse: {
          skipChildren: true,
          cloneDeep: false,
          keepIfEmpty: false,
        },
      },
      options
    );

    var eachDeepOptions = {
      pathFormat: options.pathFormat,
      checkCircular: options.checkCircular,
      childrenPath: options.childrenPath,
      includeRoot: options.includeRoot,
      rootIsChildren: options.rootIsChildren,
      callbackAfterIterate: true,
      leavesOnly: false,
    };

    var res = _.isArray(obj) ? [] : _.isObject(obj) ? {} : null;
    var replies = {};
    var rootReply;
    var foundCircular = [];
    // console.log('filterDeep → eachDeep', eachDeepOptions);
    eachDeep(
      obj,
      function(value, key, parent, context) {
        delete context['break'];
        var curPath = pathToString(context.path);
        if (!context.afterIterate) {
          if (!context.isCircular) {
            // console.log(context.path, { leaf: context.isLeaf });
            var reply =
              !options.leavesOnly || context.isLeaf
                ? predicate(value, key, parent, context)
                : undefined;

            if (!_.isObject(reply)) {
              if (reply === undefined) {
                reply = _.clone(options.onUndefined);
              } else if (reply) {
                reply = _.clone(options.onTrue);
              } else {
                reply = _.clone(options.onFalse);
              }
            }
            if (reply.empty === undefined) {
              reply.empty = true;
            }
            // console.log(context.path + '?', reply);
            if (curPath !== undefined) {
              replies[curPath] = reply;

              // _.eachRight(context.parents, function(parent) {
              //   var p = pathToString(parent.path);
              //   if (p !== undefined && !replies[p]) {
              //     replies[p] = _.clone(options.onUndefined);
              //     replies[p].empty = reply.empty;
              //   } else {
              //     return false;
              //   }
              // });

              if (!rootReply) {
                rootReply = {
                  skipChildren: false,
                  cloneDeep: false,
                  keepIfEmpty: false,
                  empty: reply.empty,
                };
              }
            } else {
              rootReply = reply;
              // console.log('root reply', reply);
            }
            // console.log('→', replies);
            if (reply.keepIfEmpty || !reply.skipChildren) {
              if (options.cloneDeep && reply.cloneDeep) {
                if (context.path !== undefined) {
                  _.set(res, context.path, options.cloneDeep(value));
                } else {
                  res = options.cloneDeep(value);
                }
              } else {
                if (context.path !== undefined) {
                  _.set(
                    res,
                    context.path,
                    _.isArray(value) ? [] : _.isPlainObject(value) ? {} : value
                  );
                } else {
                  res = _.isArray(value)
                    ? []
                    : _.isPlainObject(value)
                    ? {}
                    : value;
                }
              }
            }
            return !reply.skipChildren;
          } else {
            // console.log('fc: ', context.path);
            _.unset(res, context.path);

            if (options.keepCircular) {
              foundCircular.push([context.path, context.circularParent.path]);
            }
            return false;
          }
        } else if (context.afterIterate && !context.isCircular) {
          // console.log('ai: ', context.path);
          if (
            curPath === undefined &&
            rootReply.empty &&
            !rootReply.keepIfEmpty
          ) {
            res = null;
          } else if (
            curPath !== undefined &&
            replies[curPath].empty &&
            !replies[curPath].keepIfEmpty
          ) {
            // console.log('remove ' + context.path);
            _.unset(res, context.path);
          } else {
            _.eachRight(context.parents, function(parent) {
              var p = pathToString(parent.path);
              if (p !== undefined && replies[p].empty) {
                replies[p].empty = false;
              } else {
                return false;
              }
            });
            rootReply.empty = false;
          }
          // console.log('←', replies);
          return;
        }
      },
      eachDeepOptions
    );
    if (rootReply && rootReply.empty && !rootReply.keepIfEmpty) {
      res = null;
    }
    _.each(foundCircular, function(c) {
      var cv;
      var found = c[1] === undefined || exists(res, c[1]);
      if (!found) { return; }
      // console.log('circular: ', c[0], c[1]);
      if (_.has(options, 'replaceCircularBy')) {
        cv = options.replaceCircularBy;
      } else {
        cv = c[1] !== undefined ? _.get(res, c[1]) : res;
      }
      _.set(res, c[0], cv);
    });
    if (options.condense) {
      //console.log('filterDeep → condenseDeep');
      res = condenseDeep(res, { checkCircular: options.checkCircular });
    }
    if (_.isArray(res) && !res.length && !eachDeepOptions.includeRoot)
      { return null; }
    return res;
  }
  return filterDeep;
}

module.exports = getFilterDeep;


/***/ }),

/***/ "../node_modules/deepdash/getOmitDeep.js":
/*!***********************************************!*\
  !*** ../node_modules/deepdash/getOmitDeep.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var getFilterDeep = __webpack_require__(/*! ./getFilterDeep.js */ "../node_modules/deepdash/getFilterDeep.js");
var getPathMatches = __webpack_require__(/*! ./getPathMatches.js */ "../node_modules/deepdash/getPathMatches.js");

function getOmitDeep(_) {
  var pathMatches = getPathMatches(_);
  var filterDeep = getFilterDeep(_);

  function omitDeep(obj, paths, options) {
    options = _.merge(
      {
        invert: false,
      },
      options || {}
    );
    var isOmit = !options.invert;
    options = _.merge(
      {
        onMatch: {
          cloneDeep: false,
          skipChildren: false,
          keepIfEmpty: !isOmit,
        },
        onNotMatch: {
          cloneDeep: false,
          skipChildren: false,
          keepIfEmpty: isOmit,
        },
      },
      options
    );
    options.leavesOnly = false;
    options.childrenPath = undefined;
    options.includeRoot = undefined;
    options.pathFormat = 'array';
    options.onTrue = options.invert ? options.onMatch : options.onNotMatch;
    options.onFalse = options.invert ? options.onNotMatch : options.onMatch;

    var test = function(value, key, parent, context) {
      if (pathMatches(context.path, paths) !== false) {
        return options.invert;
      } else {
        return !options.invert;
      }
    };
    return filterDeep(obj, test, options);
  }
  return omitDeep;
}

module.exports = getOmitDeep;


/***/ }),

/***/ "../node_modules/deepdash/getPathMatches.js":
/*!**************************************************!*\
  !*** ../node_modules/deepdash/getPathMatches.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var getPathToString = __webpack_require__(/*! ./getPathToString.js */ "../node_modules/deepdash/getPathToString.js");

function getPathMatches(_) {
  var pathToString = getPathToString(_);
  function pathMatches(path, paths) {
    var pathString;
    var pathArray;
    if (_.isString(path)) {
      pathString = path;
    } else {
      pathArray = path;
    }
    if (!_.isArray(paths)) {
      paths = [paths];
    } else {
      paths = _.cloneDeep(paths);
    }
    for (var i = 0; i < paths.length; i++) {
      if (_.isString(paths[i])) {
        paths[i] = _.toPath(paths[i]);
      }
      if (_.isArray(paths[i])) {
        if (pathArray === undefined) {
          pathArray = _.toPath(pathString);
        }
        if (
          pathArray.length >= paths[i].length &&
          _.isEqual(_.takeRight(pathArray, paths[i].length), paths[i])
        ) {
          // console.log('path matched');
          return paths[i];
        }
      } else if (paths[i] instanceof RegExp) {
        if (pathString === undefined) {
          pathString = pathToString(path);
        }
        if (paths[i].test(pathString)) {
          // console.log('regex matched', paths[i]);
          return paths[i];
        }
      } else {
        throw new Error(
          'To match path use only string/regex or array of them.'
        );
      }
    }
    // console.log('matched nothing');
    return false;
  }
  return pathMatches;
}

getPathMatches.notChainable = true;

module.exports = getPathMatches;


/***/ }),

/***/ "../node_modules/deepdash/getPathToString.js":
/*!***************************************************!*\
  !*** ../node_modules/deepdash/getPathToString.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var rxArrIndex = /\D/;
var rxVarName = /^[a-zA-Z_$]+([\w_$]*)$/;
var rxQuot = /"/g;

function concatPaths() {
  var paths = [], len = arguments.length;
  while ( len-- ) paths[ len ] = arguments[ len ];

  return paths.reduce(
    function (acc, p) { return acc ? (!p || p.startsWith('[') ? ("" + acc + p) : (acc + "." + p)) : p; },
    ''
  );
}

function getPathToString(_) {
  function pathToString(path) {
    var prefixes = [], len = arguments.length - 1;
    while ( len-- > 0 ) prefixes[ len ] = arguments[ len + 1 ];

    if (_.isString(path)) { return concatPaths.apply(void 0, prefixes.concat( [path] )); }
    if (!_.isArray(path)) { return undefined; }
    prefixes = concatPaths.apply(void 0, prefixes);
    return path.reduce(function (acc, value) {
      var type = typeof value;
      if (type === 'number') {
        if (value < 0 || value % 1 !== 0) {
          return (acc + "[\"" + value + "\"]");
        } else {
          return (acc + "[" + value + "]");
        }
      } else if (type !== 'string') {
        return (acc + "[\"" + value + "\"]");
      } else if (!value) {
        return (acc + "[\"\"]");
      }
      if (!rxArrIndex.test(value)) {
        return (acc + "[" + value + "]");
      }
      if (rxVarName.test(value)) {
        if (acc) {
          return (acc + "." + value);
        } else {
          return ("" + acc + value);
        }
      }
      return (acc + "[\"" + (value.replace(rxQuot, '\\"')) + "\"]");
    }, prefixes);
  }
  return pathToString;
}

getPathToString.notChainable = true;

module.exports = getPathToString;


/***/ }),

/***/ "../node_modules/deepdash/getPaths.js":
/*!********************************************!*\
  !*** ../node_modules/deepdash/getPaths.js ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var getEachDeep = __webpack_require__(/*! ./getEachDeep.js */ "../node_modules/deepdash/getEachDeep.js");

function getPaths(_) {
  var eachDeep = getEachDeep(_);
  function paths(obj, options) {
    if (options && options.leafsOnly !== undefined) {
      options.leavesOnly = options.leafsOnly;
    }
    options = _.merge(
      {
        checkCircular: false,
        includeCircularPath: true,
        leavesOnly: !options || options.childrenPath === undefined,
        pathFormat: 'string',
      },
      options || {}
    );
    var eachDeepOptions = {
      pathFormat: options.pathFormat,
      checkCircular: options.checkCircular,
      includeRoot: options.includeRoot,
      childrenPath: options.childrenPath,
      rootIsChildren: options.rootIsChildren,
      leavesOnly: options.leavesOnly,
    };
    var res = [];
    eachDeep(
      obj,
      function(value, key, parent, context) {
        if (!context.isCircular || options.includeCircularPath) {
          if (context.path !== undefined) {
            res.push(context.path);
          }
        }
      },
      eachDeepOptions
    );
    return res;
  }
  return paths;
}

module.exports = getPaths;


/***/ }),

/***/ "../node_modules/deepdash/private/getHasChildren.js":
/*!**********************************************************!*\
  !*** ../node_modules/deepdash/private/getHasChildren.js ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


function getHasChildren(_) {
  function hasChildren(obj, childrenPath) {
    return _.some(childrenPath, function (cp) {
      var children = _.get(obj, cp);
      return !_.isEmpty(children);
    });
  }
  return hasChildren;
}

module.exports = getHasChildren;


/***/ }),

/***/ "../node_modules/deepdash/private/getIterate.js":
/*!******************************************************!*\
  !*** ../node_modules/deepdash/private/getIterate.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var getPathToString = __webpack_require__(/*! ../getPathToString.js */ "../node_modules/deepdash/getPathToString.js");
var getHasChildren = __webpack_require__(/*! ./getHasChildren.js */ "../node_modules/deepdash/private/getHasChildren.js");

function getIterate(_) {
  var pathToString = getPathToString(_);
  var hasChildren = getHasChildren(_);
  var _each = _.each || _.forArray;
  function iterate(ref) {
    var value = ref.value;
    var callback = ref.callback;
    var options = ref.options;
    var key = ref.key;
    var path = ref.path;
    var strPath = ref.strPath;
    var depth = ref.depth; if ( depth === void 0 ) depth = 0;
    var parent = ref.parent;
    var parents = ref.parents; if ( parents === void 0 ) parents = [];
    var obj = ref.obj;
    var childrenPath = ref.childrenPath;
    var strChildrenPath = ref.strChildrenPath;

    if (options['break']) { return; }
    var currentObj = {
      value: value,
      key: key,
      path:
        options.pathFormat == 'array' ? path : strPath || pathToString(path),
      parent: parent,
    };

    var currentParents = parents.concat( [currentObj]);
    var isCircular;
    var circularParentIndex = undefined;
    var circularParent = undefined;
    if (options.checkCircular) {
      if (_.isObject(value) && !_.isEmpty(value)) {
        circularParentIndex = -1;
        var i = parents.length;
        while (i--) {
          if (parents[i].value === value) {
            circularParentIndex = i;
            break;
          }
        }

        circularParent = parents[circularParentIndex] || null;
      } else {
        circularParentIndex = -1;
        circularParent = null;
      }
      isCircular = circularParentIndex !== -1;
    }
    var isLeaf =
      !_.isObject(value) ||
      _.isEmpty(value) ||
      isCircular ||
      (options.childrenPath !== undefined &&
        !hasChildren(value, options.childrenPath));
    var needCallback =
      (depth || options.includeRoot) && (!options.leavesOnly || isLeaf);

    if (needCallback) {
      var context = {
        path: currentObj.path,
        parent: parent,
        parents: parents,
        obj: obj,
        depth: depth,
        isCircular: isCircular,
        circularParent: circularParent,
        circularParentIndex: circularParentIndex,
        isLeaf: isLeaf,
        "break": function () {
          options['break'] = true;
          return false;
        },
      };
      if (options.childrenPath !== undefined) {
        currentObj.childrenPath =
          options.pathFormat == 'array' ? childrenPath : strChildrenPath;
        context.childrenPath = currentObj.childrenPath;
      }
      try {
        var res = callback(value, key, parent && parent.value, context);
      } catch (err) {
        if (err.message) {
          err.message += "\ncallback failed before deep iterate at:\n" + (context.path);
        }
        throw err;
      }
    }
    if (
      !options['break'] &&
      res !== false &&
      !isCircular &&
      _.isObject(value)
    ) {
      if (options.childrenPath !== undefined) {
        function forChildren(children, cp, scp) {
          if (children && _.isObject(children)) {
            _.forOwn(children, function(childValue, childKey) {
              var childPath = (path || []).concat( (cp || []), [childKey]);
              var strChildPath =
                options.pathFormat == 'array'
                  ? pathToString([childKey], strPath || '', scp || '')
                  : undefined;
              iterate({
                value: childValue,
                callback: callback,
                options: options,
                key: childKey,
                path: childPath,
                strPath: strChildPath,
                depth: depth + 1,
                parent: currentObj,
                parents: currentParents,
                obj: obj,
                childrenPath: cp,
                strChildrenPath: scp,
              });
            });
          }
        }

        if (!depth && options.rootIsChildren) {
          if (_.isArray(value)) {
            forChildren(value);
          } else {
            _.forOwn(value, function(childValue, childKey) {
              iterate({
                value: childValue,
                callback: callback,
                options: options,
                key: childKey,
                path: [childKey],
                strPath: pathToString([childKey]),
                depth: depth + 1,
                parent: currentObj,
                parents: currentParents,
                obj: obj,
              });
            });
          }
        } else {
          _each(options.childrenPath, function(cp, i) {
            var children = _.get(value, cp);
            forChildren(children, cp, options.strChildrenPath[i]);
          });
        }
      } else {
        _.forOwn(value, function(childValue, childKey) {
          if (_.isArray(value)) {
            if (childValue === undefined && !(childKey in value)) {
              return; //empty slot
            }
          }

          var childPath = (path || []).concat( [childKey]);
          var strChildPath =
            options.pathFormat == 'array'
              ? pathToString([childKey], strPath || '')
              : undefined;

          iterate({
            value: childValue,
            callback: callback,
            options: options,
            key: childKey,
            path: childPath,
            strPath: strChildPath,
            depth: depth + 1,
            parent: currentObj,
            parents: currentParents,
            obj: obj,
          });
        });
      }
    }
    if (options.callbackAfterIterate && needCallback) {
      context.afterIterate = true;
      try {
        callback(value, key, parent && parent.value, context);
      } catch (err) {
        if (err.message) {
          err.message += "\ncallback failed after deep iterate at:\n" + (context.path);
        }
        throw err;
      }
    }
  }
  return iterate;
}

module.exports = getIterate;


/***/ }),

/***/ "../node_modules/filter-obj/index.js":
/*!*******************************************!*\
  !*** ../node_modules/filter-obj/index.js ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

module.exports = function (obj, predicate) {
	var ret = {};
	var keys = Object.keys(obj);
	var isArr = Array.isArray(predicate);

	for (var i = 0; i < keys.length; i++) {
		var key = keys[i];
		var val = obj[key];

		if (isArr ? predicate.indexOf(key) !== -1 : predicate(key, val, obj)) {
			ret[key] = val;
		}
	}

	return ret;
};


/***/ }),

/***/ "../node_modules/ms/index.js":
/*!***********************************!*\
  !*** ../node_modules/ms/index.js ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * Helpers.
 */

var s = 1000;
var m = s * 60;
var h = m * 60;
var d = h * 24;
var w = d * 7;
var y = d * 365.25;

/**
 * Parse or format the given `val`.
 *
 * Options:
 *
 *  - `long` verbose formatting [false]
 *
 * @param {String|Number} val
 * @param {Object} [options]
 * @throws {Error} throw an error if val is not a non-empty string or a number
 * @return {String|Number}
 * @api public
 */

module.exports = function (val, options) {
  options = options || {};
  var type = typeof val;
  if (type === 'string' && val.length > 0) {
    return parse(val);
  } else if (type === 'number' && isFinite(val)) {
    return options.long ? fmtLong(val) : fmtShort(val);
  }
  throw new Error(
    'val is not a non-empty string or a valid number. val=' +
      JSON.stringify(val)
  );
};

/**
 * Parse the given `str` and return milliseconds.
 *
 * @param {String} str
 * @return {Number}
 * @api private
 */

function parse(str) {
  str = String(str);
  if (str.length > 100) {
    return;
  }
  var match = /^(-?(?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)?$/i.exec(
    str
  );
  if (!match) {
    return;
  }
  var n = parseFloat(match[1]);
  var type = (match[2] || 'ms').toLowerCase();
  switch (type) {
    case 'years':
    case 'year':
    case 'yrs':
    case 'yr':
    case 'y':
      return n * y;
    case 'weeks':
    case 'week':
    case 'w':
      return n * w;
    case 'days':
    case 'day':
    case 'd':
      return n * d;
    case 'hours':
    case 'hour':
    case 'hrs':
    case 'hr':
    case 'h':
      return n * h;
    case 'minutes':
    case 'minute':
    case 'mins':
    case 'min':
    case 'm':
      return n * m;
    case 'seconds':
    case 'second':
    case 'secs':
    case 'sec':
    case 's':
      return n * s;
    case 'milliseconds':
    case 'millisecond':
    case 'msecs':
    case 'msec':
    case 'ms':
      return n;
    default:
      return undefined;
  }
}

/**
 * Short format for `ms`.
 *
 * @param {Number} ms
 * @return {String}
 * @api private
 */

function fmtShort(ms) {
  var msAbs = Math.abs(ms);
  if (msAbs >= d) {
    return Math.round(ms / d) + 'd';
  }
  if (msAbs >= h) {
    return Math.round(ms / h) + 'h';
  }
  if (msAbs >= m) {
    return Math.round(ms / m) + 'm';
  }
  if (msAbs >= s) {
    return Math.round(ms / s) + 's';
  }
  return ms + 'ms';
}

/**
 * Long format for `ms`.
 *
 * @param {Number} ms
 * @return {String}
 * @api private
 */

function fmtLong(ms) {
  var msAbs = Math.abs(ms);
  if (msAbs >= d) {
    return plural(ms, msAbs, d, 'day');
  }
  if (msAbs >= h) {
    return plural(ms, msAbs, h, 'hour');
  }
  if (msAbs >= m) {
    return plural(ms, msAbs, m, 'minute');
  }
  if (msAbs >= s) {
    return plural(ms, msAbs, s, 'second');
  }
  return ms + ' ms';
}

/**
 * Pluralization helper.
 */

function plural(ms, msAbs, n, name) {
  var isPlural = msAbs >= n * 1.5;
  return Math.round(ms / n) + ' ' + name + (isPlural ? 's' : '');
}


/***/ }),

/***/ "../node_modules/nearley/lib/nearley.js":
/*!**********************************************!*\
  !*** ../node_modules/nearley/lib/nearley.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

(function(root, factory) {
    if ( true && module.exports) {
        module.exports = factory();
    } else {
        root.nearley = factory();
    }
}(this, function() {

    function Rule(name, symbols, postprocess) {
        this.id = ++Rule.highestId;
        this.name = name;
        this.symbols = symbols;        // a list of literal | regex class | nonterminal
        this.postprocess = postprocess;
        return this;
    }
    Rule.highestId = 0;

    Rule.prototype.toString = function(withCursorAt) {
        var symbolSequence = (typeof withCursorAt === "undefined")
                             ? this.symbols.map(getSymbolShortDisplay).join(' ')
                             : (   this.symbols.slice(0, withCursorAt).map(getSymbolShortDisplay).join(' ')
                                 + " ● "
                                 + this.symbols.slice(withCursorAt).map(getSymbolShortDisplay).join(' ')     );
        return this.name + " → " + symbolSequence;
    }


    // a State is a rule at a position from a given starting point in the input stream (reference)
    function State(rule, dot, reference, wantedBy) {
        this.rule = rule;
        this.dot = dot;
        this.reference = reference;
        this.data = [];
        this.wantedBy = wantedBy;
        this.isComplete = this.dot === rule.symbols.length;
    }

    State.prototype.toString = function() {
        return "{" + this.rule.toString(this.dot) + "}, from: " + (this.reference || 0);
    };

    State.prototype.nextState = function(child) {
        var state = new State(this.rule, this.dot + 1, this.reference, this.wantedBy);
        state.left = this;
        state.right = child;
        if (state.isComplete) {
            state.data = state.build();
            // Having right set here will prevent the right state and its children
            // form being garbage collected
            state.right = undefined;
        }
        return state;
    };

    State.prototype.build = function() {
        var children = [];
        var node = this;
        do {
            children.push(node.right.data);
            node = node.left;
        } while (node.left);
        children.reverse();
        return children;
    };

    State.prototype.finish = function() {
        if (this.rule.postprocess) {
            this.data = this.rule.postprocess(this.data, this.reference, Parser.fail);
        }
    };


    function Column(grammar, index) {
        this.grammar = grammar;
        this.index = index;
        this.states = [];
        this.wants = {}; // states indexed by the non-terminal they expect
        this.scannable = []; // list of states that expect a token
        this.completed = {}; // states that are nullable
    }


    Column.prototype.process = function(nextColumn) {
        var states = this.states;
        var wants = this.wants;
        var completed = this.completed;

        for (var w = 0; w < states.length; w++) { // nb. we push() during iteration
            var state = states[w];

            if (state.isComplete) {
                state.finish();
                if (state.data !== Parser.fail) {
                    // complete
                    var wantedBy = state.wantedBy;
                    for (var i = wantedBy.length; i--; ) { // this line is hot
                        var left = wantedBy[i];
                        this.complete(left, state);
                    }

                    // special-case nullables
                    if (state.reference === this.index) {
                        // make sure future predictors of this rule get completed.
                        var exp = state.rule.name;
                        (this.completed[exp] = this.completed[exp] || []).push(state);
                    }
                }

            } else {
                // queue scannable states
                var exp = state.rule.symbols[state.dot];
                if (typeof exp !== 'string') {
                    this.scannable.push(state);
                    continue;
                }

                // predict
                if (wants[exp]) {
                    wants[exp].push(state);

                    if (completed.hasOwnProperty(exp)) {
                        var nulls = completed[exp];
                        for (var i = 0; i < nulls.length; i++) {
                            var right = nulls[i];
                            this.complete(state, right);
                        }
                    }
                } else {
                    wants[exp] = [state];
                    this.predict(exp);
                }
            }
        }
    }

    Column.prototype.predict = function(exp) {
        var rules = this.grammar.byName[exp] || [];

        for (var i = 0; i < rules.length; i++) {
            var r = rules[i];
            var wantedBy = this.wants[exp];
            var s = new State(r, 0, this.index, wantedBy);
            this.states.push(s);
        }
    }

    Column.prototype.complete = function(left, right) {
        var copy = left.nextState(right);
        this.states.push(copy);
    }


    function Grammar(rules, start) {
        this.rules = rules;
        this.start = start || this.rules[0].name;
        var byName = this.byName = {};
        this.rules.forEach(function(rule) {
            if (!byName.hasOwnProperty(rule.name)) {
                byName[rule.name] = [];
            }
            byName[rule.name].push(rule);
        });
    }

    // So we can allow passing (rules, start) directly to Parser for backwards compatibility
    Grammar.fromCompiled = function(rules, start) {
        var lexer = rules.Lexer;
        if (rules.ParserStart) {
          start = rules.ParserStart;
          rules = rules.ParserRules;
        }
        var rules = rules.map(function (r) { return (new Rule(r.name, r.symbols, r.postprocess)); });
        var g = new Grammar(rules, start);
        g.lexer = lexer; // nb. storing lexer on Grammar is iffy, but unavoidable
        return g;
    }


    function StreamLexer() {
      this.reset("");
    }

    StreamLexer.prototype.reset = function(data, state) {
        this.buffer = data;
        this.index = 0;
        this.line = state ? state.line : 1;
        this.lastLineBreak = state ? -state.col : 0;
    }

    StreamLexer.prototype.next = function() {
        if (this.index < this.buffer.length) {
            var ch = this.buffer[this.index++];
            if (ch === '\n') {
              this.line += 1;
              this.lastLineBreak = this.index;
            }
            return {value: ch};
        }
    }

    StreamLexer.prototype.save = function() {
      return {
        line: this.line,
        col: this.index - this.lastLineBreak,
      }
    }

    StreamLexer.prototype.formatError = function(token, message) {
        // nb. this gets called after consuming the offending token,
        // so the culprit is index-1
        var buffer = this.buffer;
        if (typeof buffer === 'string') {
            var lines = buffer
                .split("\n")
                .slice(
                    Math.max(0, this.line - 5), 
                    this.line
                );

            var nextLineBreak = buffer.indexOf('\n', this.index);
            if (nextLineBreak === -1) nextLineBreak = buffer.length;
            var col = this.index - this.lastLineBreak;
            var lastLineDigits = String(this.line).length;
            message += " at line " + this.line + " col " + col + ":\n\n";
            message += lines
                .map(function(line, i) {
                    return pad(this.line - lines.length + i + 1, lastLineDigits) + " " + line;
                }, this)
                .join("\n");
            message += "\n" + pad("", lastLineDigits + col) + "^\n";
            return message;
        } else {
            return message + " at index " + (this.index - 1);
        }

        function pad(n, length) {
            var s = String(n);
            return Array(length - s.length + 1).join(" ") + s;
        }
    }

    function Parser(rules, start, options) {
        if (rules instanceof Grammar) {
            var grammar = rules;
            var options = start;
        } else {
            var grammar = Grammar.fromCompiled(rules, start);
        }
        this.grammar = grammar;

        // Read options
        this.options = {
            keepHistory: false,
            lexer: grammar.lexer || new StreamLexer,
        };
        for (var key in (options || {})) {
            this.options[key] = options[key];
        }

        // Setup lexer
        this.lexer = this.options.lexer;
        this.lexerState = undefined;

        // Setup a table
        var column = new Column(grammar, 0);
        var table = this.table = [column];

        // I could be expecting anything.
        column.wants[grammar.start] = [];
        column.predict(grammar.start);
        // TODO what if start rule is nullable?
        column.process();
        this.current = 0; // token index
    }

    // create a reserved token for indicating a parse fail
    Parser.fail = {};

    Parser.prototype.feed = function(chunk) {
        var lexer = this.lexer;
        lexer.reset(chunk, this.lexerState);

        var token;
        while (true) {
            try {
                token = lexer.next();
                if (!token) {
                    break;
                }
            } catch (e) {
                // Create the next column so that the error reporter
                // can display the correctly predicted states.
                var nextColumn = new Column(this.grammar, this.current + 1);
                this.table.push(nextColumn);
                var err = new Error(this.reportLexerError(e));
                err.offset = this.current;
                err.token = e.token;
                throw err;
            }
            // We add new states to table[current+1]
            var column = this.table[this.current];

            // GC unused states
            if (!this.options.keepHistory) {
                delete this.table[this.current - 1];
            }

            var n = this.current + 1;
            var nextColumn = new Column(this.grammar, n);
            this.table.push(nextColumn);

            // Advance all tokens that expect the symbol
            var literal = token.text !== undefined ? token.text : token.value;
            var value = lexer.constructor === StreamLexer ? token.value : token;
            var scannable = column.scannable;
            for (var w = scannable.length; w--; ) {
                var state = scannable[w];
                var expect = state.rule.symbols[state.dot];
                // Try to consume the token
                // either regex or literal
                if (expect.test ? expect.test(value) :
                    expect.type ? expect.type === token.type
                                : expect.literal === literal) {
                    // Add it
                    var next = state.nextState({data: value, token: token, isToken: true, reference: n - 1});
                    nextColumn.states.push(next);
                }
            }

            // Next, for each of the rules, we either
            // (a) complete it, and try to see if the reference row expected that
            //     rule
            // (b) predict the next nonterminal it expects by adding that
            //     nonterminal's start state
            // To prevent duplication, we also keep track of rules we have already
            // added

            nextColumn.process();

            // If needed, throw an error:
            if (nextColumn.states.length === 0) {
                // No states at all! This is not good.
                var err = new Error(this.reportError(token));
                err.offset = this.current;
                err.token = token;
                throw err;
            }

            // maybe save lexer state
            if (this.options.keepHistory) {
              column.lexerState = lexer.save()
            }

            this.current++;
        }
        if (column) {
          this.lexerState = lexer.save()
        }

        // Incrementally keep track of results
        this.results = this.finish();

        // Allow chaining, for whatever it's worth
        return this;
    };

    Parser.prototype.reportLexerError = function(lexerError) {
        var tokenDisplay, lexerMessage;
        // Planning to add a token property to moo's thrown error
        // even on erroring tokens to be used in error display below
        var token = lexerError.token;
        if (token) {
            tokenDisplay = "input " + JSON.stringify(token.text[0]) + " (lexer error)";
            lexerMessage = this.lexer.formatError(token, "Syntax error");
        } else {
            tokenDisplay = "input (lexer error)";
            lexerMessage = lexerError.message;
        }
        return this.reportErrorCommon(lexerMessage, tokenDisplay);
    };

    Parser.prototype.reportError = function(token) {
        var tokenDisplay = (token.type ? token.type + " token: " : "") + JSON.stringify(token.value !== undefined ? token.value : token);
        var lexerMessage = this.lexer.formatError(token, "Syntax error");
        return this.reportErrorCommon(lexerMessage, tokenDisplay);
    };

    Parser.prototype.reportErrorCommon = function(lexerMessage, tokenDisplay) {
        var lines = [];
        lines.push(lexerMessage);
        var lastColumnIndex = this.table.length - 2;
        var lastColumn = this.table[lastColumnIndex];
        var expectantStates = lastColumn.states
            .filter(function(state) {
                var nextSymbol = state.rule.symbols[state.dot];
                return nextSymbol && typeof nextSymbol !== "string";
            });

        if (expectantStates.length === 0) {
            lines.push('Unexpected ' + tokenDisplay + '. I did not expect any more input. Here is the state of my parse table:\n');
            this.displayStateStack(lastColumn.states, lines);
        } else {
            lines.push('Unexpected ' + tokenDisplay + '. Instead, I was expecting to see one of the following:\n');
            // Display a "state stack" for each expectant state
            // - which shows you how this state came to be, step by step.
            // If there is more than one derivation, we only display the first one.
            var stateStacks = expectantStates
                .map(function(state) {
                    return this.buildFirstStateStack(state, []) || [state];
                }, this);
            // Display each state that is expecting a terminal symbol next.
            stateStacks.forEach(function(stateStack) {
                var state = stateStack[0];
                var nextSymbol = state.rule.symbols[state.dot];
                var symbolDisplay = this.getSymbolDisplay(nextSymbol);
                lines.push('A ' + symbolDisplay + ' based on:');
                this.displayStateStack(stateStack, lines);
            }, this);
        }
        lines.push("");
        return lines.join("\n");
    }
    
    Parser.prototype.displayStateStack = function(stateStack, lines) {
        var lastDisplay;
        var sameDisplayCount = 0;
        for (var j = 0; j < stateStack.length; j++) {
            var state = stateStack[j];
            var display = state.rule.toString(state.dot);
            if (display === lastDisplay) {
                sameDisplayCount++;
            } else {
                if (sameDisplayCount > 0) {
                    lines.push('    ^ ' + sameDisplayCount + ' more lines identical to this');
                }
                sameDisplayCount = 0;
                lines.push('    ' + display);
            }
            lastDisplay = display;
        }
    };

    Parser.prototype.getSymbolDisplay = function(symbol) {
        return getSymbolLongDisplay(symbol);
    };

    /*
    Builds a the first state stack. You can think of a state stack as the call stack
    of the recursive-descent parser which the Nearley parse algorithm simulates.
    A state stack is represented as an array of state objects. Within a
    state stack, the first item of the array will be the starting
    state, with each successive item in the array going further back into history.

    This function needs to be given a starting state and an empty array representing
    the visited states, and it returns an single state stack.

    */
    Parser.prototype.buildFirstStateStack = function(state, visited) {
        if (visited.indexOf(state) !== -1) {
            // Found cycle, return null
            // to eliminate this path from the results, because
            // we don't know how to display it meaningfully
            return null;
        }
        if (state.wantedBy.length === 0) {
            return [state];
        }
        var prevState = state.wantedBy[0];
        var childVisited = [state].concat(visited);
        var childResult = this.buildFirstStateStack(prevState, childVisited);
        if (childResult === null) {
            return null;
        }
        return [state].concat(childResult);
    };

    Parser.prototype.save = function() {
        var column = this.table[this.current];
        column.lexerState = this.lexerState;
        return column;
    };

    Parser.prototype.restore = function(column) {
        var index = column.index;
        this.current = index;
        this.table[index] = column;
        this.table.splice(index + 1);
        this.lexerState = column.lexerState;

        // Incrementally keep track of results
        this.results = this.finish();
    };

    // nb. deprecated: use save/restore instead!
    Parser.prototype.rewind = function(index) {
        if (!this.options.keepHistory) {
            throw new Error('set option `keepHistory` to enable rewinding')
        }
        // nb. recall column (table) indicies fall between token indicies.
        //        col 0   --   token 0   --   col 1
        this.restore(this.table[index]);
    };

    Parser.prototype.finish = function() {
        // Return the possible parsings
        var considerations = [];
        var start = this.grammar.start;
        var column = this.table[this.table.length - 1]
        column.states.forEach(function (t) {
            if (t.rule.name === start
                    && t.dot === t.rule.symbols.length
                    && t.reference === 0
                    && t.data !== Parser.fail) {
                considerations.push(t);
            }
        });
        return considerations.map(function(c) {return c.data; });
    };

    function getSymbolLongDisplay(symbol) {
        var type = typeof symbol;
        if (type === "string") {
            return symbol;
        } else if (type === "object") {
            if (symbol.literal) {
                return JSON.stringify(symbol.literal);
            } else if (symbol instanceof RegExp) {
                return 'character matching ' + symbol;
            } else if (symbol.type) {
                return symbol.type + ' token';
            } else if (symbol.test) {
                return 'token matching ' + String(symbol.test);
            } else {
                throw new Error('Unknown symbol type: ' + symbol);
            }
        }
    }

    function getSymbolShortDisplay(symbol) {
        var type = typeof symbol;
        if (type === "string") {
            return symbol;
        } else if (type === "object") {
            if (symbol.literal) {
                return JSON.stringify(symbol.literal);
            } else if (symbol instanceof RegExp) {
                return symbol.toString();
            } else if (symbol.type) {
                return '%' + symbol.type;
            } else if (symbol.test) {
                return '<' + String(symbol.test) + '>';
            } else {
                throw new Error('Unknown symbol type: ' + symbol);
            }
        }
    }

    return {
        Parser: Parser,
        Grammar: Grammar,
        Rule: Rule,
    };

}));


/***/ }),

/***/ "../node_modules/query-string/index.js":
/*!*********************************************!*\
  !*** ../node_modules/query-string/index.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

const strictUriEncode = __webpack_require__(/*! strict-uri-encode */ "../node_modules/strict-uri-encode/index.js");
const decodeComponent = __webpack_require__(/*! decode-uri-component */ "../node_modules/decode-uri-component/index.js");
const splitOnFirst = __webpack_require__(/*! split-on-first */ "../node_modules/split-on-first/index.js");
const filterObject = __webpack_require__(/*! filter-obj */ "../node_modules/filter-obj/index.js");

const isNullOrUndefined = value => value === null || value === undefined;

function encoderForArrayFormat(options) {
	switch (options.arrayFormat) {
		case 'index':
			return key => (result, value) => {
				const index = result.length;

				if (
					value === undefined ||
					(options.skipNull && value === null) ||
					(options.skipEmptyString && value === '')
				) {
					return result;
				}

				if (value === null) {
					return [...result, [encode(key, options), '[', index, ']'].join('')];
				}

				return [
					...result,
					[encode(key, options), '[', encode(index, options), ']=', encode(value, options)].join('')
				];
			};

		case 'bracket':
			return key => (result, value) => {
				if (
					value === undefined ||
					(options.skipNull && value === null) ||
					(options.skipEmptyString && value === '')
				) {
					return result;
				}

				if (value === null) {
					return [...result, [encode(key, options), '[]'].join('')];
				}

				return [...result, [encode(key, options), '[]=', encode(value, options)].join('')];
			};

		case 'comma':
		case 'separator':
			return key => (result, value) => {
				if (value === null || value === undefined || value.length === 0) {
					return result;
				}

				if (result.length === 0) {
					return [[encode(key, options), '=', encode(value, options)].join('')];
				}

				return [[result, encode(value, options)].join(options.arrayFormatSeparator)];
			};

		default:
			return key => (result, value) => {
				if (
					value === undefined ||
					(options.skipNull && value === null) ||
					(options.skipEmptyString && value === '')
				) {
					return result;
				}

				if (value === null) {
					return [...result, encode(key, options)];
				}

				return [...result, [encode(key, options), '=', encode(value, options)].join('')];
			};
	}
}

function parserForArrayFormat(options) {
	let result;

	switch (options.arrayFormat) {
		case 'index':
			return (key, value, accumulator) => {
				result = /\[(\d*)\]$/.exec(key);

				key = key.replace(/\[\d*\]$/, '');

				if (!result) {
					accumulator[key] = value;
					return;
				}

				if (accumulator[key] === undefined) {
					accumulator[key] = {};
				}

				accumulator[key][result[1]] = value;
			};

		case 'bracket':
			return (key, value, accumulator) => {
				result = /(\[\])$/.exec(key);
				key = key.replace(/\[\]$/, '');

				if (!result) {
					accumulator[key] = value;
					return;
				}

				if (accumulator[key] === undefined) {
					accumulator[key] = [value];
					return;
				}

				accumulator[key] = [].concat(accumulator[key], value);
			};

		case 'comma':
		case 'separator':
			return (key, value, accumulator) => {
				const isArray = typeof value === 'string' && value.includes(options.arrayFormatSeparator);
				const isEncodedArray = (typeof value === 'string' && !isArray && decode(value, options).includes(options.arrayFormatSeparator));
				value = isEncodedArray ? decode(value, options) : value;
				const newValue = isArray || isEncodedArray ? value.split(options.arrayFormatSeparator).map(item => decode(item, options)) : value === null ? value : decode(value, options);
				accumulator[key] = newValue;
			};

		default:
			return (key, value, accumulator) => {
				if (accumulator[key] === undefined) {
					accumulator[key] = value;
					return;
				}

				accumulator[key] = [].concat(accumulator[key], value);
			};
	}
}

function validateArrayFormatSeparator(value) {
	if (typeof value !== 'string' || value.length !== 1) {
		throw new TypeError('arrayFormatSeparator must be single character string');
	}
}

function encode(value, options) {
	if (options.encode) {
		return options.strict ? strictUriEncode(value) : encodeURIComponent(value);
	}

	return value;
}

function decode(value, options) {
	if (options.decode) {
		return decodeComponent(value);
	}

	return value;
}

function keysSorter(input) {
	if (Array.isArray(input)) {
		return input.sort();
	}

	if (typeof input === 'object') {
		return keysSorter(Object.keys(input))
			.sort((a, b) => Number(a) - Number(b))
			.map(key => input[key]);
	}

	return input;
}

function removeHash(input) {
	const hashStart = input.indexOf('#');
	if (hashStart !== -1) {
		input = input.slice(0, hashStart);
	}

	return input;
}

function getHash(url) {
	let hash = '';
	const hashStart = url.indexOf('#');
	if (hashStart !== -1) {
		hash = url.slice(hashStart);
	}

	return hash;
}

function extract(input) {
	input = removeHash(input);
	const queryStart = input.indexOf('?');
	if (queryStart === -1) {
		return '';
	}

	return input.slice(queryStart + 1);
}

function parseValue(value, options) {
	if (options.parseNumbers && !Number.isNaN(Number(value)) && (typeof value === 'string' && value.trim() !== '')) {
		value = Number(value);
	} else if (options.parseBooleans && value !== null && (value.toLowerCase() === 'true' || value.toLowerCase() === 'false')) {
		value = value.toLowerCase() === 'true';
	}

	return value;
}

function parse(query, options) {
	options = Object.assign({
		decode: true,
		sort: true,
		arrayFormat: 'none',
		arrayFormatSeparator: ',',
		parseNumbers: false,
		parseBooleans: false
	}, options);

	validateArrayFormatSeparator(options.arrayFormatSeparator);

	const formatter = parserForArrayFormat(options);

	// Create an object with no prototype
	const ret = Object.create(null);

	if (typeof query !== 'string') {
		return ret;
	}

	query = query.trim().replace(/^[?#&]/, '');

	if (!query) {
		return ret;
	}

	for (const param of query.split('&')) {
		if (param === '') {
			continue;
		}

		let [key, value] = splitOnFirst(options.decode ? param.replace(/\+/g, ' ') : param, '=');

		// Missing `=` should be `null`:
		// http://w3.org/TR/2012/WD-url-20120524/#collect-url-parameters
		value = value === undefined ? null : ['comma', 'separator'].includes(options.arrayFormat) ? value : decode(value, options);
		formatter(decode(key, options), value, ret);
	}

	for (const key of Object.keys(ret)) {
		const value = ret[key];
		if (typeof value === 'object' && value !== null) {
			for (const k of Object.keys(value)) {
				value[k] = parseValue(value[k], options);
			}
		} else {
			ret[key] = parseValue(value, options);
		}
	}

	if (options.sort === false) {
		return ret;
	}

	return (options.sort === true ? Object.keys(ret).sort() : Object.keys(ret).sort(options.sort)).reduce((result, key) => {
		const value = ret[key];
		if (Boolean(value) && typeof value === 'object' && !Array.isArray(value)) {
			// Sort object keys, not values
			result[key] = keysSorter(value);
		} else {
			result[key] = value;
		}

		return result;
	}, Object.create(null));
}

exports.extract = extract;
exports.parse = parse;

exports.stringify = (object, options) => {
	if (!object) {
		return '';
	}

	options = Object.assign({
		encode: true,
		strict: true,
		arrayFormat: 'none',
		arrayFormatSeparator: ','
	}, options);

	validateArrayFormatSeparator(options.arrayFormatSeparator);

	const shouldFilter = key => (
		(options.skipNull && isNullOrUndefined(object[key])) ||
		(options.skipEmptyString && object[key] === '')
	);

	const formatter = encoderForArrayFormat(options);

	const objectCopy = {};

	for (const key of Object.keys(object)) {
		if (!shouldFilter(key)) {
			objectCopy[key] = object[key];
		}
	}

	const keys = Object.keys(objectCopy);

	if (options.sort !== false) {
		keys.sort(options.sort);
	}

	return keys.map(key => {
		const value = object[key];

		if (value === undefined) {
			return '';
		}

		if (value === null) {
			return encode(key, options);
		}

		if (Array.isArray(value)) {
			return value
				.reduce(formatter(key), [])
				.join('&');
		}

		return encode(key, options) + '=' + encode(value, options);
	}).filter(x => x.length > 0).join('&');
};

exports.parseUrl = (url, options) => {
	options = Object.assign({
		decode: true
	}, options);

	const [url_, hash] = splitOnFirst(url, '#');

	return Object.assign(
		{
			url: url_.split('?')[0] || '',
			query: parse(extract(url), options)
		},
		options && options.parseFragmentIdentifier && hash ? {fragmentIdentifier: decode(hash, options)} : {}
	);
};

exports.stringifyUrl = (object, options) => {
	options = Object.assign({
		encode: true,
		strict: true
	}, options);

	const url = removeHash(object.url).split('?')[0] || '';
	const queryFromUrl = exports.extract(object.url);
	const parsedQueryFromUrl = exports.parse(queryFromUrl, {sort: false});

	const query = Object.assign(parsedQueryFromUrl, object.query);
	let queryString = exports.stringify(query, options);
	if (queryString) {
		queryString = `?${queryString}`;
	}

	let hash = getHash(object.url);
	if (object.fragmentIdentifier) {
		hash = `#${encode(object.fragmentIdentifier, options)}`;
	}

	return `${url}${queryString}${hash}`;
};

exports.pick = (input, filter, options) => {
	options = Object.assign({
		parseFragmentIdentifier: true
	}, options);

	const {url, query, fragmentIdentifier} = exports.parseUrl(input, options);
	return exports.stringifyUrl({
		url,
		query: filterObject(query, filter),
		fragmentIdentifier
	}, options);
};

exports.exclude = (input, filter, options) => {
	const exclusionFilter = Array.isArray(filter) ? key => !filter.includes(key) : (key, value) => !filter(key, value);

	return exports.pick(input, exclusionFilter, options);
};


/***/ }),

/***/ "../node_modules/split-on-first/index.js":
/*!***********************************************!*\
  !*** ../node_modules/split-on-first/index.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = (string, separator) => {
	if (!(typeof string === 'string' && typeof separator === 'string')) {
		throw new TypeError('Expected the arguments to be of type `string`');
	}

	if (separator === '') {
		return [string];
	}

	const separatorIndex = string.indexOf(separator);

	if (separatorIndex === -1) {
		return [string];
	}

	return [
		string.slice(0, separatorIndex),
		string.slice(separatorIndex + separator.length)
	];
};


/***/ }),

/***/ "../node_modules/strict-uri-encode/index.js":
/*!**************************************************!*\
  !*** ../node_modules/strict-uri-encode/index.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

module.exports = str => encodeURIComponent(str).replace(/[!'()*]/g, x => `%${x.charCodeAt(0).toString(16).toUpperCase()}`);


/***/ }),

/***/ "../node_modules/style-loader/lib/addStyles.js":
/*!*****************************************************!*\
  !*** ../node_modules/style-loader/lib/addStyles.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/*
	MIT License http://www.opensource.org/licenses/mit-license.php
	Author Tobias Koppers @sokra
*/

var stylesInDom = {};

var	memoize = function (fn) {
	var memo;

	return function () {
		if (typeof memo === "undefined") memo = fn.apply(this, arguments);
		return memo;
	};
};

var isOldIE = memoize(function () {
	// Test for IE <= 9 as proposed by Browserhacks
	// @see http://browserhacks.com/#hack-e71d8692f65334173fee715c222cb805
	// Tests for existence of standard globals is to allow style-loader
	// to operate correctly into non-standard environments
	// @see https://github.com/webpack-contrib/style-loader/issues/177
	return window && document && document.all && !window.atob;
});

var getTarget = function (target, parent) {
  if (parent){
    return parent.querySelector(target);
  }
  return document.querySelector(target);
};

var getElement = (function (fn) {
	var memo = {};

	return function(target, parent) {
                // If passing function in options, then use it for resolve "head" element.
                // Useful for Shadow Root style i.e
                // {
                //   insertInto: function () { return document.querySelector("#foo").shadowRoot }
                // }
                if (typeof target === 'function') {
                        return target();
                }
                if (typeof memo[target] === "undefined") {
			var styleTarget = getTarget.call(this, target, parent);
			// Special case to return head of iframe instead of iframe itself
			if (window.HTMLIFrameElement && styleTarget instanceof window.HTMLIFrameElement) {
				try {
					// This will throw an exception if access to iframe is blocked
					// due to cross-origin restrictions
					styleTarget = styleTarget.contentDocument.head;
				} catch(e) {
					styleTarget = null;
				}
			}
			memo[target] = styleTarget;
		}
		return memo[target]
	};
})();

var singleton = null;
var	singletonCounter = 0;
var	stylesInsertedAtTop = [];

var	fixUrls = __webpack_require__(/*! ./urls */ "../node_modules/style-loader/lib/urls.js");

module.exports = function(list, options) {
	if (typeof DEBUG !== "undefined" && DEBUG) {
		if (typeof document !== "object") throw new Error("The style-loader cannot be used in a non-browser environment");
	}

	options = options || {};

	options.attrs = typeof options.attrs === "object" ? options.attrs : {};

	// Force single-tag solution on IE6-9, which has a hard limit on the # of <style>
	// tags it will allow on a page
	if (!options.singleton && typeof options.singleton !== "boolean") options.singleton = isOldIE();

	// By default, add <style> tags to the <head> element
        if (!options.insertInto) options.insertInto = "head";

	// By default, add <style> tags to the bottom of the target
	if (!options.insertAt) options.insertAt = "bottom";

	var styles = listToStyles(list, options);

	addStylesToDom(styles, options);

	return function update (newList) {
		var mayRemove = [];

		for (var i = 0; i < styles.length; i++) {
			var item = styles[i];
			var domStyle = stylesInDom[item.id];

			domStyle.refs--;
			mayRemove.push(domStyle);
		}

		if(newList) {
			var newStyles = listToStyles(newList, options);
			addStylesToDom(newStyles, options);
		}

		for (var i = 0; i < mayRemove.length; i++) {
			var domStyle = mayRemove[i];

			if(domStyle.refs === 0) {
				for (var j = 0; j < domStyle.parts.length; j++) domStyle.parts[j]();

				delete stylesInDom[domStyle.id];
			}
		}
	};
};

function addStylesToDom (styles, options) {
	for (var i = 0; i < styles.length; i++) {
		var item = styles[i];
		var domStyle = stylesInDom[item.id];

		if(domStyle) {
			domStyle.refs++;

			for(var j = 0; j < domStyle.parts.length; j++) {
				domStyle.parts[j](item.parts[j]);
			}

			for(; j < item.parts.length; j++) {
				domStyle.parts.push(addStyle(item.parts[j], options));
			}
		} else {
			var parts = [];

			for(var j = 0; j < item.parts.length; j++) {
				parts.push(addStyle(item.parts[j], options));
			}

			stylesInDom[item.id] = {id: item.id, refs: 1, parts: parts};
		}
	}
}

function listToStyles (list, options) {
	var styles = [];
	var newStyles = {};

	for (var i = 0; i < list.length; i++) {
		var item = list[i];
		var id = options.base ? item[0] + options.base : item[0];
		var css = item[1];
		var media = item[2];
		var sourceMap = item[3];
		var part = {css: css, media: media, sourceMap: sourceMap};

		if(!newStyles[id]) styles.push(newStyles[id] = {id: id, parts: [part]});
		else newStyles[id].parts.push(part);
	}

	return styles;
}

function insertStyleElement (options, style) {
	var target = getElement(options.insertInto)

	if (!target) {
		throw new Error("Couldn't find a style target. This probably means that the value for the 'insertInto' parameter is invalid.");
	}

	var lastStyleElementInsertedAtTop = stylesInsertedAtTop[stylesInsertedAtTop.length - 1];

	if (options.insertAt === "top") {
		if (!lastStyleElementInsertedAtTop) {
			target.insertBefore(style, target.firstChild);
		} else if (lastStyleElementInsertedAtTop.nextSibling) {
			target.insertBefore(style, lastStyleElementInsertedAtTop.nextSibling);
		} else {
			target.appendChild(style);
		}
		stylesInsertedAtTop.push(style);
	} else if (options.insertAt === "bottom") {
		target.appendChild(style);
	} else if (typeof options.insertAt === "object" && options.insertAt.before) {
		var nextSibling = getElement(options.insertAt.before, target);
		target.insertBefore(style, nextSibling);
	} else {
		throw new Error("[Style Loader]\n\n Invalid value for parameter 'insertAt' ('options.insertAt') found.\n Must be 'top', 'bottom', or Object.\n (https://github.com/webpack-contrib/style-loader#insertat)\n");
	}
}

function removeStyleElement (style) {
	if (style.parentNode === null) return false;
	style.parentNode.removeChild(style);

	var idx = stylesInsertedAtTop.indexOf(style);
	if(idx >= 0) {
		stylesInsertedAtTop.splice(idx, 1);
	}
}

function createStyleElement (options) {
	var style = document.createElement("style");

	if(options.attrs.type === undefined) {
		options.attrs.type = "text/css";
	}

	if(options.attrs.nonce === undefined) {
		var nonce = getNonce();
		if (nonce) {
			options.attrs.nonce = nonce;
		}
	}

	addAttrs(style, options.attrs);
	insertStyleElement(options, style);

	return style;
}

function createLinkElement (options) {
	var link = document.createElement("link");

	if(options.attrs.type === undefined) {
		options.attrs.type = "text/css";
	}
	options.attrs.rel = "stylesheet";

	addAttrs(link, options.attrs);
	insertStyleElement(options, link);

	return link;
}

function addAttrs (el, attrs) {
	Object.keys(attrs).forEach(function (key) {
		el.setAttribute(key, attrs[key]);
	});
}

function getNonce() {
	if (false) {}

	return __webpack_require__.nc;
}

function addStyle (obj, options) {
	var style, update, remove, result;

	// If a transform function was defined, run it on the css
	if (options.transform && obj.css) {
	    result = typeof options.transform === 'function'
		 ? options.transform(obj.css) 
		 : options.transform.default(obj.css);

	    if (result) {
	    	// If transform returns a value, use that instead of the original css.
	    	// This allows running runtime transformations on the css.
	    	obj.css = result;
	    } else {
	    	// If the transform function returns a falsy value, don't add this css.
	    	// This allows conditional loading of css
	    	return function() {
	    		// noop
	    	};
	    }
	}

	if (options.singleton) {
		var styleIndex = singletonCounter++;

		style = singleton || (singleton = createStyleElement(options));

		update = applyToSingletonTag.bind(null, style, styleIndex, false);
		remove = applyToSingletonTag.bind(null, style, styleIndex, true);

	} else if (
		obj.sourceMap &&
		typeof URL === "function" &&
		typeof URL.createObjectURL === "function" &&
		typeof URL.revokeObjectURL === "function" &&
		typeof Blob === "function" &&
		typeof btoa === "function"
	) {
		style = createLinkElement(options);
		update = updateLink.bind(null, style, options);
		remove = function () {
			removeStyleElement(style);

			if(style.href) URL.revokeObjectURL(style.href);
		};
	} else {
		style = createStyleElement(options);
		update = applyToTag.bind(null, style);
		remove = function () {
			removeStyleElement(style);
		};
	}

	update(obj);

	return function updateStyle (newObj) {
		if (newObj) {
			if (
				newObj.css === obj.css &&
				newObj.media === obj.media &&
				newObj.sourceMap === obj.sourceMap
			) {
				return;
			}

			update(obj = newObj);
		} else {
			remove();
		}
	};
}

var replaceText = (function () {
	var textStore = [];

	return function (index, replacement) {
		textStore[index] = replacement;

		return textStore.filter(Boolean).join('\n');
	};
})();

function applyToSingletonTag (style, index, remove, obj) {
	var css = remove ? "" : obj.css;

	if (style.styleSheet) {
		style.styleSheet.cssText = replaceText(index, css);
	} else {
		var cssNode = document.createTextNode(css);
		var childNodes = style.childNodes;

		if (childNodes[index]) style.removeChild(childNodes[index]);

		if (childNodes.length) {
			style.insertBefore(cssNode, childNodes[index]);
		} else {
			style.appendChild(cssNode);
		}
	}
}

function applyToTag (style, obj) {
	var css = obj.css;
	var media = obj.media;

	if(media) {
		style.setAttribute("media", media)
	}

	if(style.styleSheet) {
		style.styleSheet.cssText = css;
	} else {
		while(style.firstChild) {
			style.removeChild(style.firstChild);
		}

		style.appendChild(document.createTextNode(css));
	}
}

function updateLink (link, options, obj) {
	var css = obj.css;
	var sourceMap = obj.sourceMap;

	/*
		If convertToAbsoluteUrls isn't defined, but sourcemaps are enabled
		and there is no publicPath defined then lets turn convertToAbsoluteUrls
		on by default.  Otherwise default to the convertToAbsoluteUrls option
		directly
	*/
	var autoFixUrls = options.convertToAbsoluteUrls === undefined && sourceMap;

	if (options.convertToAbsoluteUrls || autoFixUrls) {
		css = fixUrls(css);
	}

	if (sourceMap) {
		// http://stackoverflow.com/a/26603875
		css += "\n/*# sourceMappingURL=data:application/json;base64," + btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))) + " */";
	}

	var blob = new Blob([css], { type: "text/css" });

	var oldSrc = link.href;

	link.href = URL.createObjectURL(blob);

	if(oldSrc) URL.revokeObjectURL(oldSrc);
}


/***/ }),

/***/ "../node_modules/style-loader/lib/urls.js":
/*!************************************************!*\
  !*** ../node_modules/style-loader/lib/urls.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {


/**
 * When source maps are enabled, `style-loader` uses a link element with a data-uri to
 * embed the css on the page. This breaks all relative urls because now they are relative to a
 * bundle instead of the current page.
 *
 * One solution is to only use full urls, but that may be impossible.
 *
 * Instead, this function "fixes" the relative urls to be absolute according to the current page location.
 *
 * A rudimentary test suite is located at `test/fixUrls.js` and can be run via the `npm test` command.
 *
 */

module.exports = function (css) {
  // get current location
  var location = typeof window !== "undefined" && window.location;

  if (!location) {
    throw new Error("fixUrls requires window.location");
  }

	// blank or null?
	if (!css || typeof css !== "string") {
	  return css;
  }

  var baseUrl = location.protocol + "//" + location.host;
  var currentDir = baseUrl + location.pathname.replace(/\/[^\/]*$/, "/");

	// convert each url(...)
	/*
	This regular expression is just a way to recursively match brackets within
	a string.

	 /url\s*\(  = Match on the word "url" with any whitespace after it and then a parens
	   (  = Start a capturing group
	     (?:  = Start a non-capturing group
	         [^)(]  = Match anything that isn't a parentheses
	         |  = OR
	         \(  = Match a start parentheses
	             (?:  = Start another non-capturing groups
	                 [^)(]+  = Match anything that isn't a parentheses
	                 |  = OR
	                 \(  = Match a start parentheses
	                     [^)(]*  = Match anything that isn't a parentheses
	                 \)  = Match a end parentheses
	             )  = End Group
              *\) = Match anything and then a close parens
          )  = Close non-capturing group
          *  = Match anything
       )  = Close capturing group
	 \)  = Match a close parens

	 /gi  = Get all matches, not the first.  Be case insensitive.
	 */
	var fixedCss = css.replace(/url\s*\(((?:[^)(]|\((?:[^)(]+|\([^)(]*\))*\))*)\)/gi, function(fullMatch, origUrl) {
		// strip quotes (if they exist)
		var unquotedOrigUrl = origUrl
			.trim()
			.replace(/^"(.*)"$/, function(o, $1){ return $1; })
			.replace(/^'(.*)'$/, function(o, $1){ return $1; });

		// already a full url? no change
		if (/^(#|data:|http:\/\/|https:\/\/|file:\/\/\/|\s*$)/i.test(unquotedOrigUrl)) {
		  return fullMatch;
		}

		// convert the url to a full url
		var newUrl;

		if (unquotedOrigUrl.indexOf("//") === 0) {
		  	//TODO: should we add protocol?
			newUrl = unquotedOrigUrl;
		} else if (unquotedOrigUrl.indexOf("/") === 0) {
			// path should be relative to the base url
			newUrl = baseUrl + unquotedOrigUrl; // already starts with '/'
		} else {
			// path should be relative to current directory
			newUrl = currentDir + unquotedOrigUrl.replace(/^\.\//, ""); // Strip leading './'
		}

		// send back the fixed url(...)
		return "url(" + JSON.stringify(newUrl) + ")";
	});

	// send back the fixed css
	return fixedCss;
};


/***/ }),

/***/ "../node_modules/tslib/tslib.es6.js":
/*!******************************************!*\
  !*** ../node_modules/tslib/tslib.es6.js ***!
  \******************************************/
/*! exports provided: __extends, __assign, __rest, __decorate, __param, __metadata, __awaiter, __generator, __createBinding, __exportStar, __values, __read, __spread, __spreadArrays, __spreadArray, __await, __asyncGenerator, __asyncDelegator, __asyncValues, __makeTemplateObject, __importStar, __importDefault, __classPrivateFieldGet, __classPrivateFieldSet */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__extends", function() { return __extends; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__assign", function() { return __assign; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__rest", function() { return __rest; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__decorate", function() { return __decorate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__param", function() { return __param; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__metadata", function() { return __metadata; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__awaiter", function() { return __awaiter; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__generator", function() { return __generator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__createBinding", function() { return __createBinding; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__exportStar", function() { return __exportStar; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__values", function() { return __values; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__read", function() { return __read; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__spread", function() { return __spread; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__spreadArrays", function() { return __spreadArrays; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__spreadArray", function() { return __spreadArray; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__await", function() { return __await; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncGenerator", function() { return __asyncGenerator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncDelegator", function() { return __asyncDelegator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncValues", function() { return __asyncValues; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__makeTemplateObject", function() { return __makeTemplateObject; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__importStar", function() { return __importStar; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__importDefault", function() { return __importDefault; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__classPrivateFieldGet", function() { return __classPrivateFieldGet; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__classPrivateFieldSet", function() { return __classPrivateFieldSet; });
/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
/* global Reflect, Promise */

var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
    return extendStatics(d, b);
};

function __extends(d, b) {
    if (typeof b !== "function" && b !== null)
        throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}

var __assign = function() {
    __assign = Object.assign || function __assign(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    }
    return __assign.apply(this, arguments);
}

function __rest(s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
}

function __decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}

function __param(paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
}

function __metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
}

function __awaiter(thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
}

function __generator(thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
}

var __createBinding = Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});

function __exportStar(m, o) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(o, p)) __createBinding(o, m, p);
}

function __values(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
}

function __read(o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
}

/** @deprecated */
function __spread() {
    for (var ar = [], i = 0; i < arguments.length; i++)
        ar = ar.concat(__read(arguments[i]));
    return ar;
}

/** @deprecated */
function __spreadArrays() {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
    for (var r = Array(s), k = 0, i = 0; i < il; i++)
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
            r[k] = a[j];
    return r;
}

function __spreadArray(to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
}

function __await(v) {
    return this instanceof __await ? (this.v = v, this) : new __await(v);
}

function __asyncGenerator(thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
    function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
    function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
    function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
    function fulfill(value) { resume("next", value); }
    function reject(value) { resume("throw", value); }
    function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
}

function __asyncDelegator(o) {
    var i, p;
    return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
    function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
}

function __asyncValues(o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
}

function __makeTemplateObject(cooked, raw) {
    if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
    return cooked;
};

var __setModuleDefault = Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
};

function __importStar(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
}

function __importDefault(mod) {
    return (mod && mod.__esModule) ? mod : { default: mod };
}

function __classPrivateFieldGet(receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
}

function __classPrivateFieldSet(receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
}


/***/ }),

/***/ "./annotationCtrl.ts":
/*!***************************!*\
  !*** ./annotationCtrl.ts ***!
  \***************************/
/*! exports provided: CogniteAnnotationsQueryCtrl */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CogniteAnnotationsQueryCtrl", function() { return CogniteAnnotationsQueryCtrl; });
/* harmony import */ var _parser_events_assets__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./parser/events-assets */ "./parser/events-assets/index.ts");
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }


var CogniteAnnotationsQueryCtrl = /*#__PURE__*/function () {
  function CogniteAnnotationsQueryCtrl() {
    _classCallCheck(this, CogniteAnnotationsQueryCtrl);
  }

  _createClass(CogniteAnnotationsQueryCtrl, [{
    key: "onBlur",
    value: function onBlur() {
      this.annotation.error = '';

      try {
        var withReplacedVariable = this.datasource.replaceVariable(this.annotation.query);
        Object(_parser_events_assets__WEBPACK_IMPORTED_MODULE_0__["parse"])(withReplacedVariable);
      } catch (_ref) {
        var message = _ref.message;
        this.annotation.error = message;
      }
    }
  }]);

  return CogniteAnnotationsQueryCtrl;
}();
CogniteAnnotationsQueryCtrl.templateUrl = 'partials/annotations.editor.html';

/***/ }),

/***/ "./cdf/client.ts":
/*!***********************!*\
  !*** ./cdf/client.ts ***!
  \***********************/
/*! exports provided: formQueryForItems, formQueriesForTargets, getLabelsForTarget, getLabelWithInjectedProps, labelContainsVariableProps, getTimeseries, fetchSingleTimeseries, fetchSingleExtractor, fetchSingleAsset, stringifyError, reduceTimeseries, datapoints2Tuples, concurrent, getLimitsWarnings, getCalculationWarnings, datapointsPath, targetToIdEither, convertItemsToTable, fetchTemplateName, fetchTemplateVersion, fetchTemplateForTargets, fetchRelationshipsList */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "formQueryForItems", function() { return formQueryForItems; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "formQueriesForTargets", function() { return formQueriesForTargets; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLabelsForTarget", function() { return getLabelsForTarget; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLabelWithInjectedProps", function() { return getLabelWithInjectedProps; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "labelContainsVariableProps", function() { return labelContainsVariableProps; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getTimeseries", function() { return getTimeseries; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchSingleTimeseries", function() { return fetchSingleTimeseries; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchSingleExtractor", function() { return fetchSingleExtractor; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchSingleAsset", function() { return fetchSingleAsset; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "stringifyError", function() { return stringifyError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "reduceTimeseries", function() { return reduceTimeseries; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "datapoints2Tuples", function() { return datapoints2Tuples; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "concurrent", function() { return concurrent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLimitsWarnings", function() { return getLimitsWarnings; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCalculationWarnings", function() { return getCalculationWarnings; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "datapointsPath", function() { return datapointsPath; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "targetToIdEither", function() { return targetToIdEither; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "convertItemsToTable", function() { return convertItemsToTable; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchTemplateName", function() { return fetchTemplateName; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchTemplateVersion", function() { return fetchTemplateVersion; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchTemplateForTargets", function() { return fetchTemplateForTargets; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchRelationshipsList", function() { return fetchRelationshipsList; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "../node_modules/tslib/tslib.es6.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash */ "lodash");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../types */ "./types.ts");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../utils */ "./utils.ts");
/* harmony import */ var _parser_ts__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../parser/ts */ "./parser/ts/index.ts");
/* harmony import */ var _datasource__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../datasource */ "./datasource.ts");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../constants */ "./constants.ts");
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }








var Asset = _types__WEBPACK_IMPORTED_MODULE_2__["Tab"].Asset,
    Custom = _types__WEBPACK_IMPORTED_MODULE_2__["Tab"].Custom,
    Timeseries = _types__WEBPACK_IMPORTED_MODULE_2__["Tab"].Timeseries;
var variableLabelRegex = /{{([^{}]+)}}/g;
function formQueryForItems(_ref, _ref2) {
  var items = _ref.items,
      type = _ref.type,
      target = _ref.target;
  var range = _ref2.range,
      intervalMs = _ref2.intervalMs;
  var aggregation = target.aggregation,
      granularity = target.granularity;

  var _getRange = Object(_datasource__WEBPACK_IMPORTED_MODULE_5__["getRange"])(range),
      _getRange2 = _slicedToArray(_getRange, 2),
      start = _getRange2[0],
      end = _getRange2[1];

  switch (type) {
    case 'synthetic':
      {
        var limit = calculateDPLimitPerQuery(items.length);
        return {
          items: items.map(function (_ref3) {
            var expression = _ref3.expression;
            return {
              expression: expression,
              start: start,
              end: end,
              limit: limit
            };
          })
        };
      }

    case 'latest':
      {
        return {
          items: items.map(function (item) {
            return Object.assign(Object.assign({}, item), {
              before: end
            });
          })
        };
      }

    default:
      {
        var aggregations = null;
        var isAggregated = aggregation && aggregation !== 'none';

        if (isAggregated) {
          aggregations = {
            aggregates: [aggregation],
            granularity: granularity || Object(_utils__WEBPACK_IMPORTED_MODULE_3__["toGranularityWithLowerBound"])(intervalMs)
          };
        }

        var _limit = calculateDPLimitPerQuery(items.length, isAggregated);

        return Object.assign(Object.assign({}, aggregations), {
          end: end,
          start: start,
          items: items,
          limit: _limit
        });
      }
  }
}

function calculateDPLimitPerQuery(queriesNumber) {
  var hasAggregates = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
  return Math.floor((hasAggregates ? 10000 : 100000) / Math.min(queriesNumber, 100));
}

function formQueriesForTargets(queriesData, options) {
  return queriesData.map(function (itemsData) {
    return formQueryForItems(itemsData, options);
  });
}
function getLabelsForTarget(target, queryList, connector) {
  return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
    var labelSrc, tsIds, timeseries, expressions;
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            labelSrc = target.label || '';
            _context.t0 = target.tab;
            _context.next = _context.t0 === Timeseries ? 4 : _context.t0 === Asset ? 8 : _context.t0 === Custom ? 13 : 4;
            break;

          case 4:
            _context.next = 6;
            return getTimeseriesLabel(labelSrc, targetToIdEither(target), connector);

          case 6:
            _context.t1 = _context.sent;
            return _context.abrupt("return", [_context.t1]);

          case 8:
            tsIds = queryList.map(function (_ref4) {
              var id = _ref4.id;
              return {
                id: id
              };
            });
            /**
             * TODO: While this is ok perfomence-wise as we have caching, it is not very nice code here.
             * We should refactor labels logic someday
             */

            _context.next = 11;
            return getTimeseries({
              items: tsIds
            }, connector, false);

          case 11:
            timeseries = _context.sent;
            return _context.abrupt("return", timeseries.map(function (ts) {
              return getLabelWithInjectedProps(labelSrc, ts);
            }));

          case 13:
            if (!(!labelSrc || labelContainsVariableProps(labelSrc))) {
              _context.next = 16;
              break;
            }

            expressions = queryList.map(function (_ref5) {
              var expression = _ref5.expression;
              return expression;
            });
            return _context.abrupt("return", Object(_parser_ts__WEBPACK_IMPORTED_MODULE_4__["getLabelsForExpression"])(expressions, labelSrc, connector));

          case 16:
            return _context.abrupt("return", queryList.map(function () {
              return labelSrc;
            }));

          case 17:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));
}

function getTimeseriesLabel(label, id, connector) {
  return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
    var resLabel, _yield$getTimeseries, _yield$getTimeseries2, ts;

    return regeneratorRuntime.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            resLabel = label;

            if (!(label && labelContainsVariableProps(label))) {
              _context2.next = 8;
              break;
            }

            _context2.next = 4;
            return getTimeseries({
              items: [id]
            }, connector);

          case 4:
            _yield$getTimeseries = _context2.sent;
            _yield$getTimeseries2 = _slicedToArray(_yield$getTimeseries, 1);
            ts = _yield$getTimeseries2[0];
            resLabel = getLabelWithInjectedProps(label, ts);

          case 8:
            return _context2.abrupt("return", resLabel);

          case 9:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));
} // injects prop values to ts label, ex. `{{description}} {{metadata.key1}}` -> 'tsDescription tsMetadataKey1Value'


function getLabelWithInjectedProps(label, timeseries) {
  // matches with any text within {{ }}
  return label.replace(variableLabelRegex, function (full, group) {
    return Object(lodash__WEBPACK_IMPORTED_MODULE_1__["get"])(timeseries, group, full);
  });
}
function labelContainsVariableProps(label) {
  return label && !!label.match(variableLabelRegex);
}
function getTimeseries(data, connector) {
  var filterIsString = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : true;
  return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
    var method, items;
    return regeneratorRuntime.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            method = _types__WEBPACK_IMPORTED_MODULE_2__["HttpMethod"].POST;

            if (!('items' in data)) {
              _context3.next = 7;
              break;
            }

            _context3.next = 4;
            return connector.fetchItems({
              data: data,
              method: method,
              path: "/timeseries/byids",
              cacheTime: _constants__WEBPACK_IMPORTED_MODULE_6__["CacheTime"].ResourceByIds
            });

          case 4:
            items = _context3.sent;
            _context3.next = 10;
            break;

          case 7:
            _context3.next = 9;
            return connector.fetchAndPaginate({
              data: data,
              method: method,
              path: "/timeseries/list",
              cacheTime: _constants__WEBPACK_IMPORTED_MODULE_6__["CacheTime"].TimeseriesList
            });

          case 9:
            items = _context3.sent;

          case 10:
            return _context3.abrupt("return", Object(lodash__WEBPACK_IMPORTED_MODULE_1__["cloneDeep"])(filterIsString ? items.filter(function (ts) {
              return !ts.isString;
            }) : items));

          case 11:
          case "end":
            return _context3.stop();
        }
      }
    }, _callee3);
  }));
}
function fetchSingleTimeseries(id, connector) {
  return connector.fetchItems({
    data: {
      items: [id]
    },
    path: "/timeseries/byids",
    method: _types__WEBPACK_IMPORTED_MODULE_2__["HttpMethod"].POST,
    cacheTime: _constants__WEBPACK_IMPORTED_MODULE_6__["CacheTime"].ResourceByIds
  });
}
function fetchSingleExtractor(id, connector) {
  return connector.fetchItems({
    data: {},
    path: "/extpipes/list",
    method: _types__WEBPACK_IMPORTED_MODULE_2__["HttpMethod"].POST,
    cacheTime: _constants__WEBPACK_IMPORTED_MODULE_6__["CacheTime"].ResourceByIds
  });
}
function fetchSingleAsset(id, connector) {
  return connector.fetchItems({
    data: {
      items: [id]
    },
    path: "/assets/byids",
    method: _types__WEBPACK_IMPORTED_MODULE_2__["HttpMethod"].POST,
    cacheTime: _constants__WEBPACK_IMPORTED_MODULE_6__["CacheTime"].ResourceByIds
  });
}
function stringifyError(error) {
  var _a, _b, _c;

  var data = error.data,
      status = error.status;
  var errorMessage = ((_a = data === null || data === void 0 ? void 0 : data.error) === null || _a === void 0 ? void 0 : _a.message) || error.message;
  var missing = ((_b = data === null || data === void 0 ? void 0 : data.error) === null || _b === void 0 ? void 0 : _b.missing) && ((_c = data === null || data === void 0 ? void 0 : data.error) === null || _c === void 0 ? void 0 : _c.missing.map(JSON.stringify));
  var missingStr = missing ? "\nMissing: ".concat(missing) : '';
  var errorCode = status ? "".concat(status, " ") : '';
  return errorMessage ? "[".concat(errorCode, "ERROR] ").concat(errorMessage).concat(missingStr) : "Unknown error";
}

function filterDpsOutOfRange(datapoints, start, end) {
  return datapoints.filter(function (_ref6) {
    var timestamp = _ref6.timestamp;
    return timestamp >= start && timestamp <= end;
  });
}

function generateTargetTsLabel(id, aggregates, type, externalId) {
  var idEither = "".concat(externalId || id);
  var aggregateStr = aggregates ? "".concat(aggregates, " ") : '';
  return type === 'latest' ? idEither : "".concat(aggregateStr).concat(idEither);
}

function reduceTimeseries(metaResponses, _ref7) {
  var _ref8 = _slicedToArray(_ref7, 2),
      start = _ref8[0],
      end = _ref8[1];

  var responseTimeseries = [];
  metaResponses.forEach(function (_ref9) {
    var result = _ref9.result,
        metadata = _ref9.metadata;
    var labels = metadata.labels,
        type = metadata.type;
    var aggregates = result.config.data.aggregates;
    var items = result.data.items;
    var series = items.map(function (_ref10, i) {
      var datapoints = _ref10.datapoints,
          externalId = _ref10.externalId,
          id = _ref10.id;
      var label = labels && labels[i];
      var resTarget = label || generateTargetTsLabel(id, aggregates, type, externalId);
      var dpsInRange = type === 'latest' ? datapoints : filterDpsOutOfRange(datapoints, start, end);
      var rawDatapoints = datapoints2Tuples(dpsInRange, aggregates);
      return {
        target: resTarget,
        datapoints: rawDatapoints
      };
    });
    responseTimeseries.push.apply(responseTimeseries, _toConsumableArray(series));
  });
  return responseTimeseries;
}
function datapoints2Tuples(datapoints, aggregate) {
  return datapoints.map(function (d) {
    return datapoint2Tuple(d, aggregate);
  });
}

function datapoint2Tuple(dp, aggregateProp) {
  var value = aggregateProp in dp ? dp[aggregateProp] : dp.value;
  return [value, dp.timestamp];
}

function concurrent(queries, queryProxy) {
  return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
    var later, results, failed, succeded;
    return regeneratorRuntime.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            later = queries.map(queryProxy);
            _context4.next = 3;
            return Promise.all(later);

          case 3:
            results = _context4.sent;
            failed = results.filter(function (res) {
              return res.isErr;
            }).map(function (err) {
              return err.error;
            });
            succeded = results.filter(function (res) {
              return res.isOk;
            }).map(function (ok) {
              return ok.value;
            });
            return _context4.abrupt("return", {
              succeded: succeded,
              failed: failed
            });

          case 7:
          case "end":
            return _context4.stop();
        }
      }
    }, _callee4);
  }));
}
function getLimitsWarnings(items, limit) {
  var hasMorePoints = items.some(function (_ref11) {
    var datapoints = _ref11.datapoints;
    return datapoints.length >= limit;
  });
  return hasMorePoints ? _constants__WEBPACK_IMPORTED_MODULE_6__["DATAPOINTS_LIMIT_WARNING"] : '';
}
function getCalculationWarnings(items) {
  var datapointsErrors = new Set();
  items.forEach(function (_ref12) {
    var datapoints = _ref12.datapoints;
    datapoints.map(function (_ref13) {
      var error = _ref13.error;
      return error;
    }).filter(Boolean).forEach(function (error) {
      datapointsErrors.add(error);
    });
  });
  return Array.from(datapointsErrors).join('\n');
}
function datapointsPath(type) {
  var paths = {
    synthetic: 'synthetic/query',
    latest: 'data/latest',
    data: 'data/list'
  };
  return "/timeseries/".concat(paths[type]);
}
var targetToIdEither = function targetToIdEither(obj) {
  return obj.targetRefType === 'externalId' ? {
    externalId: obj.target
  } : {
    id: obj.target
  };
};
var convertItemsToTable = function convertItemsToTable(items, columns) {
  var rows = items.map(function (item) {
    return columns.map(function (field) {
      var res = Object(lodash__WEBPACK_IMPORTED_MODULE_1__["get"])(item, field);
      var isDate = res !== undefined && res !== null && _constants__WEBPACK_IMPORTED_MODULE_6__["DateFields"].includes(field);
      return isDate ? new Date(res) : res;
    });
  });
  return {
    rows: rows,
    type: 'table',
    columns: columns.map(function (text) {
      return {
        text: text
      };
    })
  };
};
var fetchTemplateName = function fetchTemplateName(connector) {
  return connector.fetchTemplateQuery({
    method: _types__WEBPACK_IMPORTED_MODULE_2__["HttpMethod"].POST,
    path: '/templategroups/list',
    data: {}
  });
};
var fetchTemplateVersion = function fetchTemplateVersion(domain, connector) {
  return connector.fetchTemplateQuery({
    path: "/templategroups/".concat(domain, "/versions/list"),
    method: _types__WEBPACK_IMPORTED_MODULE_2__["HttpMethod"].POST,
    data: {}
  });
};
var fetchTemplateForTargets = function fetchTemplateForTargets(params, connector) {
  var domain = params.domain,
      domainVersion = params.domainVersion,
      expr = params.expr;
  return connector.fetchTemplateQuery({
    path: "/templategroups/".concat(domain, "/versions/").concat(domainVersion, "/graphql"),
    method: _types__WEBPACK_IMPORTED_MODULE_2__["HttpMethod"].POST,
    data: {
      query: expr
    }
  });
}; // Relationsships

var fetchRelationshipsList = function fetchRelationshipsList(params, connector) {
  var filter = params.filter,
      limit = params.limit,
      cursor = params.cursor,
      _params$fetchResource = params.fetchResources,
      fetchResources = _params$fetchResource === void 0 ? true : _params$fetchResource,
      partition = params.partition; // doc https://docs.cognite.com/api/v1/#operation/listRelationships

  return connector.fetchItems({
    method: _types__WEBPACK_IMPORTED_MODULE_2__["HttpMethod"].POST,
    path: '/relationships/list',
    data: {
      filter: filter,
      limit: limit,
      cursor: cursor,
      fetchResources: fetchResources,
      partition: partition
    }
  });
};

/***/ }),

/***/ "./components/RelationshipsListTab.tsx":
/*!*********************************************!*\
  !*** ./components/RelationshipsListTab.tsx ***!
  \*********************************************/
/*! exports provided: RelationshipsListTab */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RelationshipsListTab", function() { return RelationshipsListTab; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "../node_modules/tslib/tslib.es6.js");
/* harmony import */ var _grafana_ui__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @grafana/ui */ "@grafana/ui");
/* harmony import */ var _grafana_ui__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_grafana_ui__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lodash */ "lodash");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }





var selectors = ['dataSetId', 'externalId', 'labels', 'sourceExternalId', 'sourceType', 'targetExternalId', 'targetType'];
var RelationshipsListTab = function RelationshipsListTab(_ref) {
  var query = _ref.query,
      onQueryChange = _ref.onQueryChange,
      datasource = _ref.datasource;
  var relationsShipsQuery = query.relationsShipsQuery;

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(Object(lodash__WEBPACK_IMPORTED_MODULE_2__["reduce"])(selectors, function (result, value) {
    Object(lodash__WEBPACK_IMPORTED_MODULE_2__["set"])(result, [value], []);
    return result;
  }, {})),
      _useState2 = _slicedToArray(_useState, 2),
      configs = _useState2[0],
      setConfigs = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])([]),
      _useState4 = _slicedToArray(_useState3, 2),
      selectedDataSetId = _useState4[0],
      setSelectedDataSetId = _useState4[1];

  var _useState5 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(''),
      _useState6 = _slicedToArray(_useState5, 2),
      selectedSearchKey = _useState6[0],
      setSelectedSearchKey = _useState6[1];

  var _useState7 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])([]),
      _useState8 = _slicedToArray(_useState7, 2),
      selectedLabel = _useState8[0],
      setSelectedLabel = _useState8[1];

  var _useState9 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])([]),
      _useState10 = _slicedToArray(_useState9, 2),
      customSearchValue = _useState10[0],
      setCustomSearchValue = _useState10[1];

  var handleChange = function handleChange(value, selector) {// onQueryChange({}, false);
  }; // console.log(query);


  var getList = function getList() {
    return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(void 0, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
      var _yield$datasource$cre, settings;

      return regeneratorRuntime.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return datasource.createRelationshipsNode();

            case 2:
              _yield$datasource$cre = _context.sent;
              settings = _yield$datasource$cre.settings;
              setConfigs(settings);

            case 5:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));
  };

  var mappedLabes = Object(lodash__WEBPACK_IMPORTED_MODULE_2__["flatMapDeep"])(Object(lodash__WEBPACK_IMPORTED_MODULE_2__["get"])(configs, 'labels'), function (_) {
    return Object(lodash__WEBPACK_IMPORTED_MODULE_2__["map"])(_, function (_ref2) {
      var externalId = _ref2.externalId;
      return {
        label: Object(lodash__WEBPACK_IMPORTED_MODULE_2__["upperFirst"])(externalId),
        value: externalId
      };
    });
  });

  var mappedOptions = function mappedOptions(selector) {
    return Object(lodash__WEBPACK_IMPORTED_MODULE_2__["isEqual"])(selector, 'labels') ? mappedLabes : Object(lodash__WEBPACK_IMPORTED_MODULE_2__["map"])(Object(lodash__WEBPACK_IMPORTED_MODULE_2__["get"])(configs, selector), function (value) {
      return {
        label: Object(lodash__WEBPACK_IMPORTED_MODULE_2__["upperFirst"])(value),
        value: value
      };
    });
  };

  Object(react__WEBPACK_IMPORTED_MODULE_3__["useEffect"])(function () {
    getList();
  }, []);
  return react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement("div", {
    className: "templateRow"
  }, react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_1__["MultiSelect"], {
    options: mappedOptions('dataSetId'),
    value: selectedDataSetId,
    allowCustomValue: true,
    onChange: function onChange(value) {
      return handleChange(value, 'dataSetId');
    },
    className: "cognite-dropdown",
    placeholder: "Search relations by dataSetId",
    maxMenuHeight: 150
  }), react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_1__["MultiSelect"], {
    options: mappedLabes,
    value: selectedLabel,
    allowCustomValue: true,
    onChange: setSelectedLabel,
    className: "cognite-dropdown",
    placeholder: "Search relations by Labale",
    maxMenuHeight: 150
  })), react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement("div", {
    className: "templateRow"
  }, react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_1__["Select"], {
    prefix: "Select key for search: ",
    options: Object(lodash__WEBPACK_IMPORTED_MODULE_2__["map"])(selectors, function (value) {
      return {
        value: value,
        label: Object(lodash__WEBPACK_IMPORTED_MODULE_2__["upperFirst"])(value)
      };
    }),
    onChange: function onChange(_ref3) {
      var value = _ref3.value;
      setSelectedSearchKey(value);
    },
    className: "width-20",
    value: selectedSearchKey,
    maxMenuHeight: 150
  }), react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_1__["MultiSelect"], {
    options: mappedOptions(selectedSearchKey),
    value: customSearchValue,
    placeholder: "Search value",
    className: "cognite-dropdown",
    allowCustomValue: true,
    onChange: setCustomSearchValue,
    maxMenuHeight: 150
  })));
};

/***/ }),

/***/ "./components/configEditor.tsx":
/*!*************************************!*\
  !*** ./components/configEditor.tsx ***!
  \*************************************/
/*! exports provided: ConfigEditor */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ConfigEditor", function() { return ConfigEditor; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _grafana_ui__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @grafana/ui */ "@grafana/ui");
/* harmony import */ var _grafana_ui__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_grafana_ui__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _css_common_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../css/common.css */ "./css/common.css");
/* harmony import */ var _css_common_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_css_common_css__WEBPACK_IMPORTED_MODULE_2__);
function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }




var SecretFormField = _grafana_ui__WEBPACK_IMPORTED_MODULE_1__["LegacyForms"].SecretFormField,
    FormField = _grafana_ui__WEBPACK_IMPORTED_MODULE_1__["LegacyForms"].FormField,
    Switch = _grafana_ui__WEBPACK_IMPORTED_MODULE_1__["LegacyForms"].Switch;
var apiUrlTooltip = "This is the URL used to reach the API.\nIf the project is deployed on the default multi-tenant installation (most are),\nthen keep the default value and do not change the URL.\nIf the project is deployed on a separate custom cluster,\nthen change the URL to point at the API server for that cluster.\nIf unsure, leave the URL as default.";
var oAuthPassThruTooltip = "Forward the user's upstream OAuth identity to the data source\n(Their access token gets passed along).";
var oAuthClientCredsTooltip = "The OAuth 2.0 client credentials grant flow permits this data source to use its own credentials, instead of impersonating a user, to authenticate when calling CDF.";
var oAuthTokenUrlTooltip = "OAuth 2.0 token endpoint (v2). E.g. https://login.microsoftonline.com/your-tenant/oauth2/v2.0/token";
var oAuthClientSecretTooltip = "A secret string that the application uses to prove its identity when requesting a token. Also can be referred to as application password.";
var oAuthScopeTooltip = "The value passed for the scope parameter should be the resource identifier (application ID URI) of the resource you want, affixed with the .default suffix. E.g. https://api.cognitedata.com/.default.";
function ConfigEditor(props) {
  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false),
      _useState2 = _slicedToArray(_useState, 2),
      showHelp = _useState2[0],
      setShowHelp = _useState2[1];

  var onOptionsChange = props.onOptionsChange,
      options = props.options;
  var _options$secureJsonDa = options.secureJsonData,
      secureJsonData = _options$secureJsonDa === void 0 ? {} : _options$secureJsonDa,
      jsonData = options.jsonData,
      secureJsonFields = options.secureJsonFields;
  var _secureJsonData$cogni = secureJsonData.cogniteDataPlatformApiKey,
      cogniteDataPlatformApiKey = _secureJsonData$cogni === void 0 ? '' : _secureJsonData$cogni,
      _secureJsonData$oauth = secureJsonData.oauthClientSecret,
      oauthClientSecret = _secureJsonData$oauth === void 0 ? '' : _secureJsonData$oauth;
  var _jsonData$cogniteProj = jsonData.cogniteProject,
      cogniteProject = _jsonData$cogniteProj === void 0 ? '' : _jsonData$cogniteProj,
      _jsonData$cogniteApiU = jsonData.cogniteApiUrl,
      cogniteApiUrl = _jsonData$cogniteApiU === void 0 ? '' : _jsonData$cogniteApiU,
      oauthPassThru = jsonData.oauthPassThru,
      oauthClientCreds = jsonData.oauthClientCreds,
      oauthClientId = jsonData.oauthClientId,
      oauthTokenUrl = jsonData.oauthTokenUrl,
      oauthScope = jsonData.oauthScope;

  var onJsonDataChange = function onJsonDataChange(patch) {
    onOptionsChange(Object.assign(Object.assign({}, options), {
      jsonData: Object.assign(Object.assign({}, jsonData), patch)
    }));
  };

  var onJsonStringValueChange = function onJsonStringValueChange(key) {
    return function (event) {
      return onJsonDataChange(_defineProperty({}, key, event.target.value));
    };
  };

  var onJsonBoolValueChange = function onJsonBoolValueChange(key) {
    return function (event) {
      return onJsonDataChange(_defineProperty({}, key, event.currentTarget.checked));
    };
  }; // Secure field (only sent to the backend)


  var onChangeSecretValue = function onChangeSecretValue(secretKey) {
    return function (event) {
      return onOptionsChange(Object.assign(Object.assign({}, options), {
        secureJsonData: _defineProperty({}, secretKey, event.target.value)
      }));
    };
  };

  var onResetSecretValue = function onResetSecretValue(secretKey) {
    return function () {
      return onOptionsChange(Object.assign(Object.assign({}, options), {
        secureJsonFields: Object.assign(Object.assign({}, options.secureJsonFields), _defineProperty({}, secretKey, false)),
        secureJsonData: Object.assign(Object.assign({}, options.secureJsonData), _defineProperty({}, secretKey, ''))
      }));
    };
  };

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "gf-form-group"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("h3", {
    className: "page-heading"
  }, "HTTP"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "gf-form gf-form-inline"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(FormField, {
    label: "Project",
    labelWidth: 10,
    inputWidth: 21,
    onChange: onJsonStringValueChange('cogniteProject'),
    value: cogniteProject,
    placeholder: "Cognite Data Fusion project",
    tooltip: "Cognite Data Fusion project name."
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "gf-form gf-form-inline"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(FormField, {
    label: "API URL",
    labelWidth: 10,
    inputWidth: 21,
    onChange: onJsonStringValueChange('cogniteApiUrl'),
    value: cogniteApiUrl,
    placeholder: "api.cognitedata.com",
    tooltip: apiUrlTooltip
  }))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "gf-form-group"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("h3", {
    className: "page-heading"
  }, "Auth ", react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_1__["Icon"], {
    name: "question-circle",
    onClick: function onClick() {
      return setShowHelp(!showHelp);
    }
  })), showHelp && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("pre", null, "Find out more about authentication at", ' ', react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("a", {
    href: "https://docs.cognite.com/cdf/dashboards/guides/grafana/admin.html#step-3-configure-the-cognite-data-source-for-grafana"
  }, "docs.cognite.com/cdf/dashboards/guides/grafana/admin.html")), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "gf-form-inline"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Switch, {
    label: "Forward OAuth Identity",
    labelClass: "width-11",
    checked: oauthPassThru,
    onChange: onJsonBoolValueChange('oauthPassThru'),
    tooltip: oAuthPassThruTooltip
  })), !oauthPassThru && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "gf-form"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Switch, {
    label: "OAuth2 client credentials",
    labelClass: "width-11",
    checked: oauthClientCreds,
    onChange: onJsonBoolValueChange('oauthClientCreds'),
    tooltip: oAuthClientCredsTooltip
  })), !oauthPassThru && oauthClientCreds && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "gf-form"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(FormField, {
    label: "Token URL",
    labelWidth: 11,
    inputWidth: 21,
    onChange: onJsonStringValueChange('oauthTokenUrl'),
    value: oauthTokenUrl,
    placeholder: "https://login.example.com/.../oauth2/v2.0/token",
    tooltip: oAuthTokenUrlTooltip
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "gf-form"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(FormField, {
    label: "Client Id",
    labelWidth: 11,
    inputWidth: 21,
    onChange: onJsonStringValueChange('oauthClientId'),
    value: oauthClientId,
    placeholder: "Your Application (client) ID"
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "gf-form"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(SecretFormField, {
    isConfigured: secureJsonFields.oauthClientSecret,
    value: oauthClientSecret,
    label: "Client secret",
    tooltip: oAuthClientSecretTooltip,
    labelWidth: 11,
    inputWidth: 21,
    placeholder: "******",
    onReset: onResetSecretValue('oauthClientSecret'),
    onChange: onChangeSecretValue('oauthClientSecret')
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "gf-form"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(FormField, {
    label: "Scope",
    labelWidth: 11,
    inputWidth: 21,
    onChange: onJsonStringValueChange('oauthScope'),
    value: oauthScope,
    tooltip: oAuthScopeTooltip,
    placeholder: "E.g. https://api.cognitedata.com/.default"
  }))), !(oauthPassThru || oauthClientCreds) && react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "gf-form-inline"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "gf-form"
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(SecretFormField, {
    isConfigured: secureJsonFields.cogniteDataPlatformApiKey,
    value: cogniteDataPlatformApiKey,
    label: "API Key",
    placeholder: "Cognite Data Fusion API key",
    tooltip: "Cognite Data Fusion API key.",
    labelWidth: 11,
    inputWidth: 20,
    onReset: onResetSecretValue('cogniteDataPlatformApiKey'),
    onChange: onChangeSecretValue('cogniteDataPlatformApiKey')
  })))));
}

/***/ }),

/***/ "./components/queryEditor.tsx":
/*!************************************!*\
  !*** ./components/queryEditor.tsx ***!
  \************************************/
/*! exports provided: QueryEditor */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QueryEditor", function() { return QueryEditor; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "../node_modules/tslib/tslib.es6.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash */ "lodash");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _grafana_ui__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @grafana/ui */ "@grafana/ui");
/* harmony import */ var _grafana_ui__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_grafana_ui__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _grafana_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @grafana/runtime */ "@grafana/runtime");
/* harmony import */ var _grafana_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_grafana_runtime__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _queryHelp__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./queryHelp */ "./components/queryHelp.tsx");
/* harmony import */ var _datasource__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../datasource */ "./datasource.ts");
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../types */ "./types.ts");
/* harmony import */ var _RelationshipsListTab__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./RelationshipsListTab */ "./components/RelationshipsListTab.tsx");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../constants */ "./constants.ts");
/* harmony import */ var _css_query_editor_css__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../css/query_editor.css */ "./css/query_editor.css");
/* harmony import */ var _css_query_editor_css__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_css_query_editor_css__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _resourceSelect__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./resourceSelect */ "./components/resourceSelect.tsx");
/* harmony import */ var _css_common_css__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../css/common.css */ "./css/common.css");
/* harmony import */ var _css_common_css__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_css_common_css__WEBPACK_IMPORTED_MODULE_12__);
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }














var FormField = _grafana_ui__WEBPACK_IMPORTED_MODULE_3__["LegacyForms"].FormField;
var appEventsLoader = _grafana_runtime__WEBPACK_IMPORTED_MODULE_4__["SystemJS"].load('app/core/app_events');
var aggregateOptions = [{
  value: 'none',
  label: 'None'
}, {
  value: 'average',
  label: 'Average'
}, {
  value: 'max',
  label: 'Max'
}, {
  value: 'min',
  label: 'Min'
}, {
  value: 'count',
  label: 'Count'
}, {
  value: 'sum',
  label: 'Sum'
}, {
  value: 'interpolation',
  label: 'Interpolation'
}, {
  value: 'stepInterpolation',
  label: 'Step Interpolation'
}, {
  value: 'continuousVariance',
  label: 'Continuous Variance'
}, {
  value: 'discreteVariance',
  label: 'Discrete Variance'
}, {
  value: 'totalVariation',
  label: 'Total Variation'
}];

var GranularityEditor = function GranularityEditor(props) {
  var query = props.query,
      onQueryChange = props.onQueryChange;
  return query.aggregation && query.aggregation !== 'none' && react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
    className: "gf-form"
  }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(FormField, {
    label: "Granularity",
    labelWidth: 6,
    inputWidth: 10,
    onChange: function onChange(_ref) {
      var target = _ref.target;
      return onQueryChange({
        granularity: target.value
      });
    },
    value: query.granularity,
    placeholder: "default",
    tooltip: "The granularity of the aggregate values. Valid entries are: 'day' (or 'd'), 'hour' (or 'h'), 'minute' (or 'm'), 'second' (or 's'). Example: 12h."
  }));
};

var AggregationEditor = function AggregationEditor(props) {
  var query = props.query,
      onQueryChange = props.onQueryChange;
  return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
    className: "gf-form"
  }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_3__["InlineFormLabel"], {
    width: 6
  }, "Aggregation"), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_3__["Select"], {
    onChange: function onChange(_ref2) {
      var value = _ref2.value;
      return onQueryChange({
        aggregation: value
      });
    },
    options: aggregateOptions,
    menuPosition: "fixed",
    value: query.aggregation,
    className: "cognite-dropdown width-10"
  }));
};

var LabelEditor = function LabelEditor(props) {
  var query = props.query,
      onQueryChange = props.onQueryChange;
  return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
    className: "gf-form gf-form--grow"
  }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(FormField, {
    label: "Label",
    labelWidth: 6,
    inputWidth: 10,
    onChange: function onChange(_ref3) {
      var target = _ref3.target;
      return onQueryChange({
        label: target.value
      });
    },
    value: query.label,
    placeholder: "default",
    tooltip: "Set the label for each time series. Can also access time series properties via {{property}}. Eg: {{description}}-{{metadata.key}}"
  }));
};

var LatestValueCheckbox = function LatestValueCheckbox(props) {
  var query = props.query,
      onQueryChange = props.onQueryChange;
  return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
    className: "gf-form gf-form-inline"
  }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_3__["InlineFormLabel"], {
    tooltip: "Fetch the latest data point in the provided time range",
    width: 7
  }, "Latest value"), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
    className: "gf-form-switch"
  }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_3__["Switch"], {
    value: query.latestValue,
    onChange: function onChange(_ref4) {
      var currentTarget = _ref4.currentTarget;
      return onQueryChange({
        latestValue: currentTarget.checked
      });
    }
  })));
};

var ActiveAtTimeRangeCheckbox = function ActiveAtTimeRangeCheckbox(props) {
  var query = props.query,
      onQueryChange = props.onQueryChange;
  return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
    className: "gf-form gf-form-inline"
  }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_3__["InlineFormLabel"], {
    tooltip: "Fetch active events in the provided time range. This is essentially the same as writing the following query: events{activeAtTime={min=$__from, max=$__to}} ",
    width: 7
  }, "Active only"), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
    className: "gf-form-switch"
  }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_3__["Switch"], {
    value: query.eventQuery.activeAtTimeRange,
    onChange: function onChange(_ref5) {
      var currentTarget = _ref5.currentTarget;
      return onQueryChange({
        eventQuery: Object.assign(Object.assign({}, query.eventQuery), {
          activeAtTimeRange: currentTarget.checked
        })
      });
    }
  })));
};

var CommonEditors = function CommonEditors(_ref6) {
  var onQueryChange = _ref6.onQueryChange,
      query = _ref6.query;
  return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
    className: "gf-form-inline"
  }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(AggregationEditor, Object.assign({}, {
    onQueryChange: onQueryChange,
    query: query
  })), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(GranularityEditor, Object.assign({}, {
    onQueryChange: onQueryChange,
    query: query
  })), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(LabelEditor, Object.assign({}, {
    onQueryChange: onQueryChange,
    query: query
  })));
};

var IncludeSubAssetsCheckbox = function IncludeSubAssetsCheckbox(props) {
  var query = props.query,
      onQueryChange = props.onQueryChange;
  var includeSubtrees = query.assetQuery.includeSubtrees;

  var onIncludeSubtreesChange = function onIncludeSubtreesChange(checked) {
    onQueryChange({
      assetQuery: Object.assign(Object.assign({}, query.assetQuery), {
        includeSubtrees: checked
      })
    });
  };

  return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
    className: "gf-form"
  }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_3__["InlineFormLabel"], {
    width: 9
  }, "Include sub-assets"), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
    className: "gf-form-switch"
  }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_3__["Switch"], {
    value: includeSubtrees,
    onChange: function onChange(_ref7) {
      var currentTarget = _ref7.currentTarget;
      return onIncludeSubtreesChange(currentTarget.checked);
    }
  })));
};

function AssetTab(props) {
  var _this = this;

  var query = props.query,
      datasource = props.datasource,
      onQueryChange = props.onQueryChange;

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])({
    value: query.assetQuery.target
  }),
      _useState2 = _slicedToArray(_useState, 2),
      current = _useState2[0],
      setCurrent = _useState2[1];

  var fetchAndSetDropdownLabel = function fetchAndSetDropdownLabel(idInput) {
    return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
      var id, _yield$datasource$fet, _yield$datasource$fet2, res;

      return regeneratorRuntime.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              id = Number(idInput);

              if (!Number.isNaN(id)) {
                _context.next = 5;
                break;
              }

              setCurrent({
                label: idInput,
                value: idInput
              });
              _context.next = 11;
              break;

            case 5:
              _context.next = 7;
              return datasource.fetchSingleAsset({
                id: id
              });

            case 7:
              _yield$datasource$fet = _context.sent;
              _yield$datasource$fet2 = _slicedToArray(_yield$datasource$fet, 1);
              res = _yield$datasource$fet2[0];
              setCurrent(Object(_datasource__WEBPACK_IMPORTED_MODULE_6__["resource2DropdownOption"])(res));

            case 11:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));
  };

  Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(function () {
    onQueryChange({
      assetQuery: Object.assign(Object.assign({}, query.assetQuery), {
        target: current.value
      })
    });
  }, [current.value]);
  Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(function () {
    if (current.value && !current.label) {
      fetchAndSetDropdownLabel(current.value);
    }
  }, [current.value]);
  return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
    className: "gf-form-inline"
  }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
    className: "gf-form"
  }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_3__["InlineFormLabel"], {
    width: 6
  }, "Asset Tag"), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_3__["AsyncSelect"], {
    loadOptions: function loadOptions(query) {
      return datasource.getOptionsForDropdown(query, 'Asset');
    },
    value: current,
    defaultOptions: true,
    placeholder: "Search asset by name/description",
    className: "cognite-dropdown width-20",
    allowCustomValue: true,
    onChange: setCurrent
  })), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(IncludeSubAssetsCheckbox, Object.assign({}, {
    onQueryChange: onQueryChange,
    query: query
  })), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(LatestValueCheckbox, Object.assign({}, {
    query: query,
    onQueryChange: onQueryChange
  })), query.latestValue ? react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(LabelEditor, Object.assign({}, {
    onQueryChange: onQueryChange,
    query: query
  })) : react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(CommonEditors, Object.assign({}, {
    query: query,
    onQueryChange: onQueryChange
  })));
}

function TimeseriesTab(props) {
  var query = props.query,
      datasource = props.datasource,
      onQueryChange = props.onQueryChange;
  return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_resourceSelect__WEBPACK_IMPORTED_MODULE_11__["ResourceSelect"], Object.assign({}, {
    query: query,
    onTargetQueryChange: onQueryChange,
    resourceType: _types__WEBPACK_IMPORTED_MODULE_7__["Tab"].Timeseries,
    fetchSingleResource: datasource.fetchSingleTimeseries,
    searchResource: function searchResource(query) {
      return datasource.getOptionsForDropdown(query, _types__WEBPACK_IMPORTED_MODULE_7__["Tab"].Timeseries);
    }
  })), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(LatestValueCheckbox, Object.assign({}, {
    query: query,
    onQueryChange: onQueryChange
  })), query.latestValue ? react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(LabelEditor, Object.assign({}, {
    onQueryChange: onQueryChange,
    query: query
  })) : react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(CommonEditors, Object.assign({}, {
    query: query,
    onQueryChange: onQueryChange
  })));
}

function CustomTab(props) {
  var query = props.query,
      onQueryChange = props.onQueryChange;

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(false),
      _useState4 = _slicedToArray(_useState3, 2),
      showHelp = _useState4[0],
      setShowHelp = _useState4[1];

  var _useState5 = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(query.expr),
      _useState6 = _slicedToArray(_useState5, 2),
      value = _useState6[0],
      setValue = _useState6[1];

  return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_2___default.a.Fragment, null, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
    className: "gf-form"
  }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(FormField, {
    label: "Query",
    labelWidth: 6,
    inputWidth: 30,
    className: "custom-query",
    placeholder: "ts{externalIdPrefix='PT_123'}",
    onChange: function onChange(_ref8) {
      var target = _ref8.target;
      return setValue(target.value);
    },
    onBlur: function onBlur() {
      return onQueryChange({
        expr: value
      });
    },
    value: value,
    tooltip: "Click [?] button for help."
  }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_3__["Button"], {
    variant: "secondary",
    icon: "question-circle",
    onClick: function onClick() {
      return setShowHelp(!showHelp);
    }
  })), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(CommonEditors, Object.assign({}, {
    onQueryChange: onQueryChange,
    query: query
  })), showHelp && react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_queryHelp__WEBPACK_IMPORTED_MODULE_5__["CustomQueryHelp"], {
    onDismiss: function onDismiss() {
      return setShowHelp(false);
    }
  }));
}

function EventsTab(props) {
  var query = props.query,
      onQueryChange = props.onQueryChange;

  var _useState7 = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(false),
      _useState8 = _slicedToArray(_useState7, 2),
      showHelp = _useState8[0],
      setShowHelp = _useState8[1];

  var _useState9 = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(query.eventQuery.expr),
      _useState10 = _slicedToArray(_useState9, 2),
      value = _useState10[0],
      setValue = _useState10[1];

  return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_2___default.a.Fragment, null, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
    className: "gf-form"
  }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(FormField, {
    label: "Query",
    labelWidth: 7,
    inputWidth: 30,
    className: "custom-query",
    onChange: function onChange(_ref9) {
      var target = _ref9.target;
      return setValue(target.value);
    },
    placeholder: "events{}",
    onBlur: function onBlur() {
      return onQueryChange({
        eventQuery: Object.assign(Object.assign({}, query.eventQuery), {
          expr: value
        })
      });
    },
    value: value,
    tooltip: "Click [?] button for help."
  }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_3__["Button"], {
    variant: "secondary",
    icon: "question-circle",
    onClick: function onClick() {
      return setShowHelp(!showHelp);
    }
  })), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(ActiveAtTimeRangeCheckbox, Object.assign({}, {
    query: query,
    onQueryChange: onQueryChange
  })), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(ColumnsPicker, Object.assign({}, {
    query: query,
    onQueryChange: onQueryChange
  })), showHelp && react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_queryHelp__WEBPACK_IMPORTED_MODULE_5__["EventQueryHelp"], {
    onDismiss: function onDismiss() {
      return setShowHelp(false);
    }
  }));
}

function ExtractorTab(props) {
  var query = props.query,
      onQueryChange = props.onQueryChange;

  var _useState11 = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(false),
      _useState12 = _slicedToArray(_useState11, 2),
      showHelp = _useState12[0],
      setShowHelp = _useState12[1];

  var _useState13 = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(query.extractorQuery.expr),
      _useState14 = _slicedToArray(_useState13, 2),
      value = _useState14[0],
      setValue = _useState14[1];

  return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_2___default.a.Fragment, null, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
    className: "gf-form"
  }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(ExtractorColumnsPicker, Object.assign({}, {
    query: query,
    onQueryChange: onQueryChange
  })), showHelp && react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_queryHelp__WEBPACK_IMPORTED_MODULE_5__["EventQueryHelp"], {
    onDismiss: function onDismiss() {
      return setShowHelp(false);
    }
  }));
}

var InlineButton = function InlineButton(_ref10) {
  var onClick = _ref10.onClick,
      iconName = _ref10.iconName;
  return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
    role: "button",
    className: "gf-form-label query-part",
    onClick: onClick,
    onKeyPress: onClick,
    tabIndex: 0
  }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_3__["Icon"], {
    name: iconName
  }));
};

var ColumnsPicker = function ColumnsPicker(_ref11) {
  var query = _ref11.query,
      onQueryChange = _ref11.onQueryChange;
  var options = _constants__WEBPACK_IMPORTED_MODULE_9__["EventFields"].map(function (value) {
    return {
      value: value,
      label: value
    };
  });
  var columns = query.eventQuery.columns;

  var onEventQueryChange = function onEventQueryChange(e) {
    onQueryChange({
      eventQuery: Object.assign(Object.assign({}, query.eventQuery), e)
    });
  };

  return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
    className: "gf-form"
  }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_3__["InlineFormLabel"], {
    tooltip: "Choose which columns to display. To access metadata property, use 'metadata.propertyName'",
    width: 7
  }, "Columns"), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
    className: "gf-form",
    style: {
      flexWrap: 'wrap'
    }
  }, columns.map(function (val, key) {
    return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_2___default.a.Fragment, null, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_3__["Segment"], {
      value: val,
      options: options,
      onChange: function onChange(_ref12) {
        var value = _ref12.value;
        onEventQueryChange({
          columns: columns.map(function (old, i) {
            return i === key ? value : old;
          })
        });
      },
      allowCustomValue: true
    }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(InlineButton, {
      onClick: function onClick() {
        onEventQueryChange({
          columns: columns.filter(function (_, i) {
            return i !== key;
          })
        });
      },
      iconName: "times"
    }));
  }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(InlineButton, {
    onClick: function onClick() {
      onEventQueryChange({
        columns: [].concat(_toConsumableArray(columns), ["column".concat(columns.length)])
      });
    },
    iconName: "plus-circle"
  })));
};

var ExtractorColumnsPicker = function ExtractorColumnsPicker(_ref13) {
  var query = _ref13.query,
      onQueryChange = _ref13.onQueryChange;
  var options = _constants__WEBPACK_IMPORTED_MODULE_9__["ExtractorFields"].map(function (value) {
    return {
      value: value,
      label: value
    };
  });
  var columns = query.extractorQuery.columns; // const {columns} = ['id','name','externalId','description','schedule','source','documentation','lastSuccess','lastFailure','lastSeen','createdTime'];

  var onEventQueryChange = function onEventQueryChange(e) {
    onQueryChange({
      extractorQuery: Object.assign(Object.assign({}, query.extractorQuery), e)
    });
  };

  return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
    className: "gf-form"
  }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_3__["InlineFormLabel"], {
    tooltip: "Choose which columns to display. To access metadata property, use 'metadata.propertyName'",
    width: 7
  }, "Columns"), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
    className: "gf-form",
    style: {
      flexWrap: 'wrap'
    }
  }, columns.map(function (val, key) {
    return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_2___default.a.Fragment, null, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_3__["Segment"], {
      value: val,
      options: options,
      onChange: function onChange(_ref14) {
        var value = _ref14.value;
        onEventQueryChange({
          columns: columns.map(function (old, i) {
            return i === key ? value : old;
          })
        });
      },
      allowCustomValue: true
    }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(InlineButton, {
      onClick: function onClick() {
        onEventQueryChange({
          columns: columns.filter(function (_, i) {
            return i !== key;
          })
        });
      },
      iconName: "times"
    }));
  }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(InlineButton, {
    onClick: function onClick() {
      onEventQueryChange({
        columns: [].concat(_toConsumableArray(columns), ["column".concat(columns.length)])
      });
    },
    iconName: "plus-circle"
  })));
};

function QueryEditor(props) {
  var _this2 = this;

  var queryWithoutDefaults = props.query,
      onChange = props.onChange,
      onRunQuery = props.onRunQuery,
      datasource = props.datasource;
  var query = Object(lodash__WEBPACK_IMPORTED_MODULE_1__["defaults"])(queryWithoutDefaults, _types__WEBPACK_IMPORTED_MODULE_7__["defaultQuery"]);
  var thisRefId = query.refId,
      tab = query.tab;

  var _useState15 = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(''),
      _useState16 = _slicedToArray(_useState15, 2),
      errorMessage = _useState16[0],
      setErrorMessage = _useState16[1];

  var _useState17 = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(''),
      _useState18 = _slicedToArray(_useState17, 2),
      warningMessage = _useState18[0],
      setWarningMessage = _useState18[1];

  var onQueryChange = function onQueryChange(patch) {
    var shouldRunQuery = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
    onChange(Object.assign(Object.assign({}, query), patch));

    if (shouldRunQuery) {
      setErrorMessage('');
      setWarningMessage('');
      onRunQuery();
    }
  };

  var onSelectTab = function onSelectTab(tab) {
    return function () {
      onQueryChange({
        tab: tab
      });
    };
  };

  var handleError = function handleError(_ref15) {
    var refId = _ref15.refId,
        error = _ref15.error;

    if (thisRefId === refId) {
      setErrorMessage(error);
    }
  };

  var handleWarning = function handleWarning(_ref16) {
    var refId = _ref16.refId,
        warning = _ref16.warning;

    if (thisRefId === refId) {
      setWarningMessage(warning);
    }
  };

  var eventsSubscribe = function eventsSubscribe() {
    return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this2, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
      var appEvents;
      return regeneratorRuntime.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              _context2.next = 2;
              return appEventsLoader;

            case 2:
              appEvents = _context2.sent;
              appEvents.on(_constants__WEBPACK_IMPORTED_MODULE_9__["failedResponseEvent"], handleError);
              appEvents.on(_constants__WEBPACK_IMPORTED_MODULE_9__["responseWarningEvent"], handleWarning);

            case 5:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2);
    }));
  };

  var eventsUnsubscribe = function eventsUnsubscribe() {
    return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this2, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
      var appEvents;
      return regeneratorRuntime.wrap(function _callee3$(_context3) {
        while (1) {
          switch (_context3.prev = _context3.next) {
            case 0:
              _context3.next = 2;
              return appEventsLoader;

            case 2:
              appEvents = _context3.sent;
              appEvents.off(_constants__WEBPACK_IMPORTED_MODULE_9__["failedResponseEvent"], handleError);
              appEvents.on(_constants__WEBPACK_IMPORTED_MODULE_9__["responseWarningEvent"], handleWarning);

            case 5:
            case "end":
              return _context3.stop();
          }
        }
      }, _callee3);
    }));
  };

  Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(function () {
    eventsSubscribe();
    return function () {
      eventsUnsubscribe();
    };
  }, [tab]);
  return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_3__["TabsBar"], null, Object.values(_types__WEBPACK_IMPORTED_MODULE_7__["Tab"]).map(function (t) {
    return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_3__["Tab"], {
      label: _types__WEBPACK_IMPORTED_MODULE_7__["TabTitles"][t],
      key: t,
      active: tab === t,
      onChangeTab: onSelectTab(t)
    });
  })), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_3__["TabContent"], null, tab === _types__WEBPACK_IMPORTED_MODULE_7__["Tab"].Asset && react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(AssetTab, Object.assign({}, {
    onQueryChange: onQueryChange,
    query: query,
    datasource: datasource
  })), tab === _types__WEBPACK_IMPORTED_MODULE_7__["Tab"].Timeseries && react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(TimeseriesTab, Object.assign({}, {
    onQueryChange: onQueryChange,
    query: query,
    datasource: datasource
  })), tab === _types__WEBPACK_IMPORTED_MODULE_7__["Tab"].Custom && react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(CustomTab, Object.assign({}, {
    onQueryChange: onQueryChange,
    query: query,
    onRunQuery: onRunQuery
  })), tab === _types__WEBPACK_IMPORTED_MODULE_7__["Tab"].Event && react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(EventsTab, Object.assign({}, {
    onQueryChange: onQueryChange,
    query: query,
    onRunQuery: onRunQuery
  })), tab === _types__WEBPACK_IMPORTED_MODULE_7__["Tab"].Relationships && react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_RelationshipsListTab__WEBPACK_IMPORTED_MODULE_8__["RelationshipsListTab"], Object.assign({}, {
    onQueryChange: onQueryChange,
    query: query,
    onRunQuery: onRunQuery,
    datasource: datasource
  }))), errorMessage && react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("pre", {
    className: "gf-formatted-error"
  }, errorMessage), warningMessage && react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("pre", {
    className: "gf-formatted-warning"
  }, warningMessage));
}

/***/ }),

/***/ "./components/queryHelp.tsx":
/*!**********************************!*\
  !*** ./components/queryHelp.tsx ***!
  \**********************************/
/*! exports provided: CustomQueryHelp, EventQueryHelp */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomQueryHelp", function() { return CustomQueryHelp; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EventQueryHelp", function() { return EventQueryHelp; });
/* harmony import */ var _grafana_ui__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @grafana/ui */ "@grafana/ui");
/* harmony import */ var _grafana_ui__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_grafana_ui__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../constants */ "./constants.ts");
/* eslint-disable no-template-curly-in-string */




var Code = function Code(_ref) {
  var children = _ref.children;
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("code", {
    className: "query-keyword"
  }, children);
};

var HelpPanel = function HelpPanel(_ref2) {
  var onDismiss = _ref2.onDismiss,
      title = _ref2.title,
      children = _ref2.children;
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_0__["InfoBox"], {
    style: {
      marginTop: '10px'
    },
    title: title,
    severity: "info",
    url: _constants__WEBPACK_IMPORTED_MODULE_2__["DOCS_URL"],
    onDismiss: onDismiss
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "gf-form--grow help-panel"
  }, children));
};

var CustomQueryHelp = function CustomQueryHelp(_ref3) {
  var onDismiss = _ref3.onDismiss;
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(HelpPanel, {
    title: "Custom query syntax help",
    onDismiss: onDismiss
  }, "Format: ", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "ts{options}"), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), "Options are of the form: ", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "PROPERTY COMPARATOR VALUE"), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), "Comparator can be either:", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "="), " (strict equality),", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "!="), " (strict inequality),", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "=~"), " (regex equality),", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "!~"), " (regex inequality)", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), "If you want to reference a specific time series, use:", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, 'ts{id=ID}'), ", or", ' ', react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "ts{externalId='EXTERNAL_ID', aggregate='AGGREGATE', granularity='GRANULARITY', alignment=ALIGNMENT}"), ".", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), "Example: ", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "sum(ts{metadata{type=\"TEMP\"}}) - ts{id=12345678}"), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), "Templating is available by using the ", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "$variable_name"), " syntax.", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), "Example:", ' ', react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "ts{assetIds=[$asset], metadata={key1=~'.*test.*'}, isStep=1, granularity='12h', aggregate='average'}"), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), "In case of multi-value variable, return value can be formatted. To format variable value use", ' ', react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, '${variable:[formatter]}'), ".", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), "Example: ", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "ts{assetIds=[${asset:csv}], granularity='12h', aggregate='average'}"), ' ', react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), "Check", ' ', react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("a", {
    className: "query-keyword",
    href: "https://grafana.com/docs/grafana/latest/reference/templating/#advanced-formatting-options"
  }, "Grafana documentation"), ' ', "to get list of available formatters.", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), "Synthetic time series functions can also be applied on one or multiple time series.", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), "Example: ", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "(ts{name=~'.*temp.*', aggregate='average'} - 32) * 5/9"), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "ts{} + sin(ts{granularity='24h', aggregate='average'})"), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), "Variable length functions (sum, max, min, avg) can also be applied to all filtered time series. Examples:", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "sum(ts{metadata={type=\"TEMP\"}})"), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), "\u21AA yields one time series that is the sum of all temperature time series", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "max(ts{aggregate='average'}) - min(ts{aggregate='average'})"), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), "\u21AA yields the range of the time series aggregated by averages", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, 'pow(ts{} - avg(ts{}), 2)'), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), "\u21AA yields the squared deviation of each time series from the average ", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), "There is a support for some advanced functions, like ", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "round"), ", ", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "on_error"), ' ', "and ", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "map"), ".", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), "The documentation on how to use them can be found on", ' ', react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("a", {
    className: "query-keyword",
    href: "https://docs.cognite.com/dev/concepts/resource_types/timeseries.html#synthetic-time-series"
  }, "docs.cognite.com/dev"), ".");
};
var EventQueryHelp = function EventQueryHelp(_ref4) {
  var onDismiss = _ref4.onDismiss;
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(HelpPanel, {
    title: "Event query syntax help",
    onDismiss: onDismiss
  }, "Event queries use the", ' ', react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("a", {
    className: "query-keyword",
    href: "https://docs.cognite.com/api/v1/#operation/advancedListEvents",
    target: "_blank",
    rel: "noreferrer"
  }, "events/list"), ' ', "endpoint to retrieve data.", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), "Format: ", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, 'events{someFilter=number, otherFilter="string"}'), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), "Example:", ' ', react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "events{externalIdPrefix='WORKORDER', assetSubtreeIds=[{id=12}, {externalId='ext_id'}]}"), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), "You can filter on these properties:", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "externalIdPrefix"), ", ", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "metadata"), ", ", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "assetIds"), ",", ' ', react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "assetExternalIds"), ", ", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "rootAssetIds"), ", ", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "assetSubtreeIds"), ",", ' ', react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "dataSetIds"), ", ", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "source"), ", ", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "type"), ", ", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "subtype"), ".", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), "By default, the query returns events that are active in the time range. You can customize this with the additional time filters ", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "startTime"), ", ", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "endTime"), ",", ' ', react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "activeAtTime"), ", ", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "createdTime"), ", ", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "lastUpdatedTime"), ".", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), "This example shows how to get all finished events that started in the current time range:", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "events{startTime={min=$__from}, endTime={isNull=false}}"), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), "You can specify additional client-side filtering with the ", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "=~"), ", ", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "!~"), " and", ' ', react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "!="), " operators. Comma between multiple filters acts as logic ", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "AND"), ".", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), "Format:", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "=~"), " \u2013 regex equality, returns results satisfying the regular expression.", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "!~"), " \u2013 regex inequality, excludes results satisfying the regular expression.", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "!="), " \u2013 strict inequality, returns items where a property doesn't equal a given value.", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), "Example: ", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "events{type='WORKORDER', subtype=~'SUB.*'}"), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", {
    className: "gf-formatted-warning"
  }, "Note: Do not use client-side filters as the primary filtering method.", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), "The filters are applied after items have been returned from CDF, and there is a risk that you will not see all data if CDF returned the maximum number of items (1000)."), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), "Templating is available by using the ", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "$variable_name"), " syntax.", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), "Example: ", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Code, null, "{events{type='WORKORDER', subtype=$variable}"));
};

/***/ }),

/***/ "./components/resourceSelect.tsx":
/*!***************************************!*\
  !*** ./components/resourceSelect.tsx ***!
  \***************************************/
/*! exports provided: ResourceSelect */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ResourceSelect", function() { return ResourceSelect; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "../node_modules/tslib/tslib.es6.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _grafana_ui__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @grafana/ui */ "@grafana/ui");
/* harmony import */ var _grafana_ui__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_grafana_ui__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _cdf_client__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../cdf/client */ "./cdf/client.ts");
/* harmony import */ var _datasource__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../datasource */ "./datasource.ts");
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }






var FormField = _grafana_ui__WEBPACK_IMPORTED_MODULE_2__["LegacyForms"].FormField;

var optionalIdsToTargetObj = function optionalIdsToTargetObj(_ref) {
  var id = _ref.id,
      externalId = _ref.externalId;
  return externalId ? {
    target: externalId,
    targetRefType: 'externalId'
  } : {
    target: id,
    targetRefType: 'id'
  };
};

function ResourceSelect(props) {
  var _this = this;

  var query = props.query,
      onTargetQueryChange = props.onTargetQueryChange,
      resourceType = props.resourceType,
      searchResource = props.searchResource,
      fetchSingleResource = props.fetchSingleResource;

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])({}),
      _useState2 = _slicedToArray(_useState, 2),
      current = _useState2[0],
      setCurrent = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(),
      _useState4 = _slicedToArray(_useState3, 2),
      externalIdField = _useState4[0],
      setExternalIdField = _useState4[1];

  var onDropdown = function onDropdown(value) {
    setExternalIdField(value.externalId);
    setCurrent(value);
    onTargetQueryChange(optionalIdsToTargetObj(value));
  };

  var onExternalIdField = function onExternalIdField(externalId) {
    return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
      var resource, currentOption;
      return regeneratorRuntime.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return fetchDropdownResource({
                externalId: externalId
              });

            case 2:
              resource = _context.sent;
              currentOption = resource ? Object(_datasource__WEBPACK_IMPORTED_MODULE_4__["resource2DropdownOption"])(resource) : {};
              setCurrent(currentOption);
              onTargetQueryChange(optionalIdsToTargetObj({
                externalId: externalId
              }));

            case 6:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));
  };

  var fetchDropdownResource = function fetchDropdownResource(id) {
    return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
      var _yield$fetchSingleRes, _yield$fetchSingleRes2, res;

      return regeneratorRuntime.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              _context2.prev = 0;
              _context2.next = 3;
              return fetchSingleResource(id);

            case 3:
              _yield$fetchSingleRes = _context2.sent;
              _yield$fetchSingleRes2 = _slicedToArray(_yield$fetchSingleRes, 1);
              res = _yield$fetchSingleRes2[0];
              return _context2.abrupt("return", res);

            case 9:
              _context2.prev = 9;
              _context2.t0 = _context2["catch"](0);
              return _context2.abrupt("return", null);

            case 12:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2, null, [[0, 9]]);
    }));
  };

  var migrateToExternalIdRefIfNeeded = function migrateToExternalIdRefIfNeeded(resource) {
    if (resource.externalId && query.targetRefType !== 'externalId') {
      onTargetQueryChange(optionalIdsToTargetObj(resource), false);
    }
  };

  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(function () {
    var idEither = Object(_cdf_client__WEBPACK_IMPORTED_MODULE_3__["targetToIdEither"])(query);
    setExternalIdField(idEither.externalId);
    fetchDropdownResource(idEither).then(function (resource) {
      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                if (resource) {
                  setCurrent(Object(_datasource__WEBPACK_IMPORTED_MODULE_4__["resource2DropdownOption"])(resource));
                  migrateToExternalIdRefIfNeeded(resource);
                  setExternalIdField(resource.externalId);
                }

              case 1:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3);
      }));
    });
  }, []);
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    className: "gf-form gf-form-inline"
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_2__["InlineFormLabel"], {
    width: 7,
    tooltip: "".concat(resourceType, " name")
  }, current.value ? 'Name' : 'Search'), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_2__["AsyncSelect"], {
    loadOptions: searchResource,
    defaultOptions: true,
    value: current.value ? current : null,
    placeholder: "Search ".concat(resourceType.toLowerCase(), " by name/description"),
    className: "cognite-dropdown width-20",
    onChange: onDropdown
  }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(FormField, {
    label: "External Id",
    labelWidth: 7,
    inputWidth: 20,
    onBlur: function onBlur(_ref2) {
      var target = _ref2.target;
      return onExternalIdField(target.value);
    },
    onChange: function onChange(_ref3) {
      var target = _ref3.target;
      return setExternalIdField(target.value);
    },
    value: externalIdField || '',
    placeholder: current.value ? 'No external id present' : 'Insert external id',
    tooltip: "".concat(resourceType, " external id")
  }));
}

/***/ }),

/***/ "./components/variableQueryEditor.tsx":
/*!********************************************!*\
  !*** ./components/variableQueryEditor.tsx ***!
  \********************************************/
/*! exports provided: CogniteVariableQueryEditor */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CogniteVariableQueryEditor", function() { return CogniteVariableQueryEditor; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _parser_events_assets__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../parser/events-assets */ "./parser/events-assets/index.ts");
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); Object.defineProperty(subClass, "prototype", { writable: false }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } else if (call !== void 0) { throw new TypeError("Derived constructors may only return object or undefined"); } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }



var help = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("pre", null, "Variable query uses the", ' ', react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("a", {
  className: "query-keyword",
  href: "https://docs.cognite.com/api/v1/#operation/listAssets",
  target: "_blank",
  rel: "noreferrer"
}, "assets/list"), ' ', "endpoint to fetch data. Use ", react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("code", {
  className: "query-keyword"
}, "'='"), " operator to provide parameters for the request.", react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("br", null), "Format: ", react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("code", {
  className: "query-keyword"
}, "assets{param=value,...}"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("br", null), "Example:", ' ', react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("code", {
  className: "query-keyword"
}, "assets{assetSubtreeIds=[{id=123}, {externalId='external'}]}"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("br", null), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("br", null), "You can specify additional client-side filtering with the", ' ', react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("code", {
  className: "query-keyword"
}, "'=~'"), ",", ' ', react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("code", {
  className: "query-keyword"
}, "'!~'"), " and", ' ', react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("code", {
  className: "query-keyword"
}, "'!='"), " operators. Comma between multiple filters acts as logic ", react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("code", {
  className: "query-keyword"
}, "AND"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("br", null), "Format:", react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("br", null), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("code", {
  className: "query-keyword"
}, "'=~'"), " \u2013 regex equality, returns results satisfying the regular expression.", react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("br", null), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("code", {
  className: "query-keyword"
}, "'!~'"), " \u2013 regex inequality, excludes results satisfying the regular expression.", react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("br", null), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("code", {
  className: "query-keyword"
}, "'!='"), " \u2013 strict inequality, returns items where a property doesn't equal a given value.", react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("br", null), "Example:", ' ', react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("code", {
  className: "query-keyword"
}, "assets{metadata={KEY='value', KEY_2=~'value.*'}, assetSubtreeIds=[{id=123}]}"), "To learn more about the querying capabilities of Cognite Data Source for Grafana, please visit our", ' ', react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("a", {
  className: "query-keyword",
  href: "https://docs.cognite.com/cdf/dashboards/guides/grafana/getting_started.html"
}, "documentation"), ".");
var CogniteVariableQueryEditor = /*#__PURE__*/function (_React$PureComponent) {
  _inherits(CogniteVariableQueryEditor, _React$PureComponent);

  var _super = _createSuper(CogniteVariableQueryEditor);

  function CogniteVariableQueryEditor(props) {
    var _this;

    _classCallCheck(this, CogniteVariableQueryEditor);

    _this = _super.call(this, props);
    _this.defaults = {
      query: '',
      error: ''
    };

    _this.handleQueryChange = function (event) {
      _this.setState({
        query: event.target.value,
        error: ''
      });
    };

    _this.handleBlur = function () {
      var _this$props = _this.props,
          onChange = _this$props.onChange,
          datasource = _this$props.datasource;
      var query = _this.state.query;

      try {
        var evaluatedQuery = datasource.replaceVariable(query);
        Object(_parser_events_assets__WEBPACK_IMPORTED_MODULE_1__["parse"])(evaluatedQuery);
        onChange({
          query: query
        }, query);
      } catch (_ref) {
        var message = _ref.message;

        _this.setState({
          error: message
        });

        onChange({
          query: ''
        }, '');
      }
    };

    var query = props.query;
    _this.state = Object.assign(_this.defaults, query);
    return _this;
  }

  _createClass(CogniteVariableQueryEditor, [{
    key: "render",
    value: function render() {
      var _this$state = this.state,
          query = _this$state.query,
          error = _this$state.error;
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "gf-form gf-form--grow"
      }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
        className: "gf-form-label query-keyword fix-query-keyword width-10"
      }, "Query"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("input", {
        type: "text",
        className: "gf-form-input",
        value: query,
        onChange: this.handleQueryChange,
        onBlur: this.handleBlur,
        placeholder: "eg: assets{name='example', assetSubtreeIds=[{id=123456789, externalId='externalId'}]}"
      })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "gf-form--grow"
      }, error ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("pre", {
        className: "gf-formatted-error"
      }, error) : null, help));
    }
  }]);

  return CogniteVariableQueryEditor;
}(react__WEBPACK_IMPORTED_MODULE_0___default.a.PureComponent);

/***/ }),

/***/ "./connector.ts":
/*!**********************!*\
  !*** ./connector.ts ***!
  \**********************/
/*! exports provided: Connector */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Connector", function() { return Connector; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "../node_modules/tslib/tslib.es6.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash */ "lodash");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var ms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ms */ "../node_modules/ms/index.js");
/* harmony import */ var ms__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(ms__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./types */ "./types.ts");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./utils */ "./utils.ts");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./constants */ "./constants.ts");
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }







var Connector = /*#__PURE__*/function () {
  function Connector(project, apiUrl, backendSrv, oauthPassThru, oauthClientCredentials) {
    var _this = this;

    _classCallCheck(this, Connector);

    this.project = project;
    this.apiUrl = apiUrl;
    this.backendSrv = backendSrv;
    this.oauthPassThru = oauthPassThru;
    this.oauthClientCredentials = oauthClientCredentials;
    this.cachedRequests = new Map();

    this.cachedRequest = function (query) {
      var cacheTime = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : _constants__WEBPACK_IMPORTED_MODULE_5__["CacheTime"].Default;
      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
        var _this2 = this;

        var requestId, queryWithoutId, hash, timeout, request;
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                requestId = query.requestId, queryWithoutId = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__rest"])(query, ["requestId"]);
                hash = JSON.stringify(queryWithoutId);
                timeout = ms__WEBPACK_IMPORTED_MODULE_2___default()(cacheTime);

                if (!this.cachedRequests.has(hash)) {
                  _context2.next = 5;
                  break;
                }

                return _context2.abrupt("return", this.cachedRequests.get(hash));

              case 5:
                request = function () {
                  return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this2, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                    var _this3 = this;

                    var res;
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                      while (1) {
                        switch (_context.prev = _context.next) {
                          case 0:
                            _context.prev = 0;
                            _context.next = 3;
                            return this.backendSrv.datasourceRequest(query);

                          case 3:
                            res = _context.sent;

                            if (!Object(_types__WEBPACK_IMPORTED_MODULE_3__["isError"])(res)) {
                              _context.next = 6;
                              break;
                            }

                            throw res;

                          case 6:
                            setTimeout(function () {
                              return _this3.cachedRequests["delete"](hash);
                            }, timeout);
                            return _context.abrupt("return", res);

                          case 10:
                            _context.prev = 10;
                            _context.t0 = _context["catch"](0);
                            this.cachedRequests["delete"](hash);
                            throw _context.t0;

                          case 14:
                          case "end":
                            return _context.stop();
                        }
                      }
                    }, _callee, this, [[0, 10]]);
                  }));
                }();

                this.cachedRequests.set(hash, request);
                return _context2.abrupt("return", request);

              case 8:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));
    };

    var def = [];
  }

  _createClass(Connector, [{
    key: "fetchData",
    value: function fetchData(request) {
      var path = request.path,
          data = request.data,
          method = request.method,
          params = request.params,
          requestId = request.requestId,
          cacheTime = request.cacheTime;
      var queryString = params ? "?".concat(Object(_utils__WEBPACK_IMPORTED_MODULE_4__["getQueryString"])(params)) : '';
      var url = "".concat(this.apiUrlAuth, "/").concat(_constants__WEBPACK_IMPORTED_MODULE_5__["API_V1"], "/").concat(this.project).concat(path).concat(queryString);
      var body = {
        url: url,
        data: data,
        method: method
      };

      if (requestId) {
        body.requestId = requestId;
      }

      return this.cachedRequest(body, cacheTime);
    }
  }, {
    key: "chunkAndFetch",
    value: function chunkAndFetch(request) {
      var chunkSize = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 100;
      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
        var _this4 = this;

        var data, requestId, chunkedItems, chunkedRequests, promises, results, mergedItems;
        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                data = request.data, requestId = request.requestId;
                chunkedItems = Object(lodash__WEBPACK_IMPORTED_MODULE_1__["chunk"])(data.items, chunkSize);
                chunkedRequests = chunkedItems.map(function (items, i) {
                  return Object.assign(Object.assign(Object.assign({}, request), chunkedReqId(requestId, i)), {
                    data: Object.assign(Object.assign({}, data), {
                      items: items
                    })
                  });
                });
                promises = chunkedRequests.map(function (chunk) {
                  return _this4.fetchData(chunk);
                });
                _context3.next = 6;
                return Promise.all(promises);

              case 6:
                results = _context3.sent;
                mergedItems = results.reduce(function (all, _ref) {
                  var data = _ref.data;
                  return [].concat(_toConsumableArray(all), _toConsumableArray(data.items));
                }, []);
                return _context3.abrupt("return", Object.assign(Object.assign({}, results[0]), {
                  data: Object.assign(Object.assign({}, results[0].data), {
                    items: mergedItems
                  })
                }));

              case 9:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3);
      }));
    }
  }, {
    key: "fetchItems",
    value: function fetchItems(params) {
      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
        var _yield$this$fetchData, data;

        return regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.next = 2;
                return this.fetchData(params);

              case 2:
                _yield$this$fetchData = _context4.sent;
                data = _yield$this$fetchData.data;
                return _context4.abrupt("return", data.items);

              case 5:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this);
      }));
    }
  }, {
    key: "fetchAndPaginate",
    value: function fetchAndPaginate(params) {
      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
        var maxLimit, queryData, fullLimit, _yield$this$fetchData2, data, cursor, items, _yield$this$fetchData3, current;

        return regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                maxLimit = 1000;
                queryData = params.data;
                fullLimit = queryData.limit || maxLimit;
                _context5.next = 5;
                return this.fetchData(Object.assign(Object.assign({}, params), {
                  data: Object.assign(Object.assign({}, queryData), {
                    limit: Math.min(maxLimit, fullLimit)
                  })
                }));

              case 5:
                _yield$this$fetchData2 = _context5.sent;
                data = _yield$this$fetchData2.data;
                cursor = data.nextCursor, items = data.items;
                /* eslint no-await-in-loop: "off" */

              case 8:
                if (!(cursor && fullLimit > items.length)) {
                  _context5.next = 17;
                  break;
                }

                _context5.next = 11;
                return this.fetchData(Object.assign(Object.assign({}, params), {
                  data: Object.assign(Object.assign({}, queryData), {
                    cursor: cursor,
                    limit: maxLimit
                  })
                }));

              case 11:
                _yield$this$fetchData3 = _context5.sent;
                current = _yield$this$fetchData3.data;
                cursor = current.nextCursor;
                items = [].concat(_toConsumableArray(items), _toConsumableArray(current.items));
                _context5.next = 8;
                break;

              case 17:
                if (items.length > fullLimit) {
                  items.length = fullLimit;
                }

                return _context5.abrupt("return", items);

              case 19:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));
    }
  }, {
    key: "request",
    value: function request(_ref2) {
      var path = _ref2.path,
          _ref2$method = _ref2.method,
          method = _ref2$method === void 0 ? _types__WEBPACK_IMPORTED_MODULE_3__["HttpMethod"].GET : _ref2$method;
      return this.backendSrv.datasourceRequest({
        method: method,
        url: "".concat(this.apiUrlAuth, "/").concat(path)
      });
    }
  }, {
    key: "apiUrlAuth",
    get: function get() {
      var auth;

      switch (true) {
        case !this.oauthPassThru && this.oauthClientCredentials:
          auth = _constants__WEBPACK_IMPORTED_MODULE_5__["AuthType"].OAuthClientCredentials;
          break;

        case this.oauthPassThru:
          auth = _constants__WEBPACK_IMPORTED_MODULE_5__["AuthType"].OAuth;
          break;

        default:
          auth = _constants__WEBPACK_IMPORTED_MODULE_5__["AuthType"].ApiKey;
      }

      return "".concat(this.apiUrl, "/").concat(auth);
    }
  }, {
    key: "isUsingOAuth",
    value: function isUsingOAuth() {
      return this.oauthPassThru || this.oauthClientCredentials;
    }
  }, {
    key: "fetchTemplateQuery",
    value: function fetchTemplateQuery(params) {
      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
        var res;
        return regeneratorRuntime.wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                _context6.next = 2;
                return this.fetchData(params);

              case 2:
                res = _context6.sent;
                return _context6.abrupt("return", res);

              case 4:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6, this);
      }));
    }
  }]);

  return Connector;
}();

var chunkedReqId = function chunkedReqId(requestId, chunk) {
  return requestId ? {
    requestId: chunk ? "".concat(requestId).concat(chunk) : requestId
  } : undefined;
};

/***/ }),

/***/ "./constants.ts":
/*!**********************!*\
  !*** ./constants.ts ***!
  \**********************/
/*! exports provided: API_V1, DATAPOINTS_LIMIT_WARNING, TIMESERIES_LIMIT_WARNING, EVENTS_LIMIT_WARNING, EXTRACTOR_LIMIT_WARNING, failedResponseEvent, responseWarningEvent, CacheTime, AuthType, DateFields, EventFields, ExtractorFields, EVENTS_PAGE_LIMIT, EXTRACTOR_PAGE_LIMIT, DOCS_URL */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "API_V1", function() { return API_V1; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DATAPOINTS_LIMIT_WARNING", function() { return DATAPOINTS_LIMIT_WARNING; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TIMESERIES_LIMIT_WARNING", function() { return TIMESERIES_LIMIT_WARNING; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EVENTS_LIMIT_WARNING", function() { return EVENTS_LIMIT_WARNING; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EXTRACTOR_LIMIT_WARNING", function() { return EXTRACTOR_LIMIT_WARNING; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "failedResponseEvent", function() { return failedResponseEvent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "responseWarningEvent", function() { return responseWarningEvent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CacheTime", function() { return CacheTime; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthType", function() { return AuthType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DateFields", function() { return DateFields; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EventFields", function() { return EventFields; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExtractorFields", function() { return ExtractorFields; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EVENTS_PAGE_LIMIT", function() { return EVENTS_PAGE_LIMIT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EXTRACTOR_PAGE_LIMIT", function() { return EXTRACTOR_PAGE_LIMIT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DOCS_URL", function() { return DOCS_URL; });
/* harmony import */ var _grafana_data__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @grafana/data */ "@grafana/data");
/* harmony import */ var _grafana_data__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_grafana_data__WEBPACK_IMPORTED_MODULE_0__);

var API_V1 = 'api/v1/projects';
var DATAPOINTS_LIMIT_WARNING = "You have reached the data points limit, and some data points may not be displayed.\n" + "Try increasing the granularity, or choose a shorter time range.";
var TIMESERIES_LIMIT_WARNING = "We are only showing the first 100 time series.\n" + "To get better results, change the selected asset or use 'Custom Query'.";
var EVENTS_LIMIT_WARNING = "Some results may have been omitted.\n" + "This typically happens when CDF returns the maximum number of items (1000) and when you are using client-side filters.\n" + "To get better results, use more specific push-down filters, for example, events{externalIdPrefix='fail'} instead of events{externalId=~'fail.*'} or choose a shorter time range.";
var EXTRACTOR_LIMIT_WARNING = "Some results may have been omitted.\n" + "This typically happens when CDF returns the maximum number of items (1000) and when you are using client-side filters.\n" + "To get better results, use more specific push-down filters, for example, events{externalIdPrefix='fail'} instead of events{externalId=~'fail.*'} or choose a shorter time range.";
var failedResponseEvent = Object(_grafana_data__WEBPACK_IMPORTED_MODULE_0__["eventFactory"])('failed-request');
var responseWarningEvent = Object(_grafana_data__WEBPACK_IMPORTED_MODULE_0__["eventFactory"])('request-warning');
var CacheTime = {
  TimeseriesList: '61s',
  ResourceByIds: '61m',
  Default: '11s',
  Dropdown: '3m'
};
var AuthType = {
  OAuthClientCredentials: 'cdf-cc-oauth',
  OAuth: 'cdf-oauth',
  ApiKey: 'cdf-api-key'
};
var DateFields = ['lastUpdatedTime', 'createdTime', 'startTime', 'endTime'];
var EventFields = ['id', 'externalId', 'type', 'subtype', 'dataSetId', 'assetIds', 'source', 'sourceId', 'metadata'].concat(DateFields);
var ExtractorFields = ['id', 'name', 'externalId', 'description', 'schedule', 'source', 'documentation', 'lastSuccess', 'lastFailure', 'lastSeen', 'createdTime'];
var EVENTS_PAGE_LIMIT = 1000;
var EXTRACTOR_PAGE_LIMIT = 1000;
var DOCS_URL = 'https://docs.cognite.com/cdf/dashboards/guides/grafana/getting_started.html';

/***/ }),

/***/ "./css/common.css":
/*!************************!*\
  !*** ./css/common.css ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../node_modules/css-loader/dist/cjs.js??ref--8-1!../../node_modules/postcss-loader/src??ref--8-2!../../node_modules/sass-loader/dist/cjs.js!./common.css */ "../node_modules/css-loader/dist/cjs.js?!../node_modules/postcss-loader/src/index.js?!../node_modules/sass-loader/dist/cjs.js!./css/common.css");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../node_modules/style-loader/lib/addStyles.js */ "../node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./css/query_editor.css":
/*!******************************!*\
  !*** ./css/query_editor.css ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../node_modules/css-loader/dist/cjs.js??ref--8-1!../../node_modules/postcss-loader/src??ref--8-2!../../node_modules/sass-loader/dist/cjs.js!./query_editor.css */ "../node_modules/css-loader/dist/cjs.js?!../node_modules/postcss-loader/src/index.js?!../node_modules/sass-loader/dist/cjs.js!./css/query_editor.css");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../node_modules/style-loader/lib/addStyles.js */ "../node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./datasource.ts":
/*!***********************!*\
  !*** ./datasource.ts ***!
  \***********************/
/*! exports provided: default, filterEmptyQueryTargets, resource2DropdownOption, getRange, getDataQueryRequestItems */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CogniteDatasource; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "filterEmptyQueryTargets", function() { return filterEmptyQueryTargets; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "resource2DropdownOption", function() { return resource2DropdownOption; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getRange", function() { return getRange; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getDataQueryRequestItems", function() { return getDataQueryRequestItems; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "../node_modules/tslib/tslib.es6.js");
/* harmony import */ var _grafana_data__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @grafana/data */ "@grafana/data");
/* harmony import */ var _grafana_data__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_grafana_data__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _grafana_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @grafana/runtime */ "@grafana/runtime");
/* harmony import */ var _grafana_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_grafana_runtime__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash */ "lodash");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _cdf_client__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./cdf/client */ "./cdf/client.ts");
/* harmony import */ var _connector__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./connector */ "./connector.ts");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./constants */ "./constants.ts");
/* harmony import */ var _parser_events_assets__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./parser/events-assets */ "./parser/events-assets/index.ts");
/* harmony import */ var _parser_ts__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./parser/ts */ "./parser/ts/index.ts");
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./types */ "./types.ts");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./utils */ "./utils.ts");
/* harmony import */ var _utils2__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./utils2 */ "./utils2.ts");
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); Object.defineProperty(subClass, "prototype", { writable: false }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } else if (call !== void 0) { throw new TypeError("Derived constructors may only return object or undefined"); } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }













var appEventsLoader = _grafana_runtime__WEBPACK_IMPORTED_MODULE_2__["SystemJS"].load('app/core/app_events');

var CogniteDatasource = /*#__PURE__*/function (_DataSourceApi) {
  _inherits(CogniteDatasource, _DataSourceApi);

  var _super = _createSuper(CogniteDatasource);

  function CogniteDatasource(instanceSettings) {
    var _this;

    _classCallCheck(this, CogniteDatasource);

    _this = _super.call(this, instanceSettings);
    _this.cachedDomains = [];

    _this.fetchSingleTimeseries = function (id) {
      return Object(_cdf_client__WEBPACK_IMPORTED_MODULE_4__["fetchSingleTimeseries"])(id, _this.connector);
    };

    _this.fetchSingleAsset = function (id) {
      return Object(_cdf_client__WEBPACK_IMPORTED_MODULE_4__["fetchSingleAsset"])(id, _this.connector);
    };

    _this.fetchSingleExtractor = function (id) {
      return Object(_cdf_client__WEBPACK_IMPORTED_MODULE_4__["fetchSingleExtractor"])(id, _this.connector);
    };

    _this.fetchTemplateName = function () {
      return Object(_cdf_client__WEBPACK_IMPORTED_MODULE_4__["fetchTemplateName"])(_this.connector);
    };

    _this.fetchTemplateVersion = function (domain) {
      return Object(_cdf_client__WEBPACK_IMPORTED_MODULE_4__["fetchTemplateVersion"])(domain, _this.connector);
    };

    _this.fetchTemplateForTargets = function (params) {
      return Object(_cdf_client__WEBPACK_IMPORTED_MODULE_4__["fetchTemplateForTargets"])(params, _this.connector);
    };

    _this.fetchRelationshipsList = function () {
      return Object(_cdf_client__WEBPACK_IMPORTED_MODULE_4__["fetchRelationshipsList"])({}, _this.connector);
    };

    _this.createRelationshipsNode = function () {
      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_assertThisInitialized(_this), void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
        var realtionshipsList, iterrer, labels, dataSetId, externalId, sourceExternalId, sourceType, targetExternalId, targetType, nodes, edges;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return this.fetchRelationshipsList();

              case 2:
                realtionshipsList = _context.sent;
                iterrer = Object(lodash__WEBPACK_IMPORTED_MODULE_3__["head"])(Object(lodash__WEBPACK_IMPORTED_MODULE_3__["map"])(realtionshipsList, function (_ref) {
                  var source = _ref.source;
                  return Object(lodash__WEBPACK_IMPORTED_MODULE_3__["keys"])(source.metadata);
                }));
                labels = Object(lodash__WEBPACK_IMPORTED_MODULE_3__["uniqBy"])(Object(lodash__WEBPACK_IMPORTED_MODULE_3__["map"])(realtionshipsList, 'labels'), 'externalId');
                dataSetId = Object(lodash__WEBPACK_IMPORTED_MODULE_3__["uniq"])(Object(lodash__WEBPACK_IMPORTED_MODULE_3__["map"])(realtionshipsList, 'dataSetId'));
                externalId = Object(lodash__WEBPACK_IMPORTED_MODULE_3__["uniq"])(Object(lodash__WEBPACK_IMPORTED_MODULE_3__["map"])(realtionshipsList, 'externalId'));
                sourceExternalId = Object(lodash__WEBPACK_IMPORTED_MODULE_3__["uniq"])(Object(lodash__WEBPACK_IMPORTED_MODULE_3__["map"])(realtionshipsList, 'sourceExternalId'));
                sourceType = Object(lodash__WEBPACK_IMPORTED_MODULE_3__["uniq"])(Object(lodash__WEBPACK_IMPORTED_MODULE_3__["map"])(realtionshipsList, 'sourceType'));
                targetExternalId = Object(lodash__WEBPACK_IMPORTED_MODULE_3__["uniq"])(Object(lodash__WEBPACK_IMPORTED_MODULE_3__["map"])(realtionshipsList, 'targetExternalId'));
                targetType = Object(lodash__WEBPACK_IMPORTED_MODULE_3__["uniq"])(Object(lodash__WEBPACK_IMPORTED_MODULE_3__["map"])(realtionshipsList, 'targetType'));
                nodes = Object(_utils2__WEBPACK_IMPORTED_MODULE_11__["nodesFrame"])(iterrer);
                edges = Object(_utils2__WEBPACK_IMPORTED_MODULE_11__["edgesFrame"])();
                Object(lodash__WEBPACK_IMPORTED_MODULE_3__["map"])(realtionshipsList, function (_ref2) {
                  var externalId = _ref2.externalId,
                      labels = _ref2.labels,
                      sourceExternalId = _ref2.sourceExternalId,
                      targetExternalId = _ref2.targetExternalId,
                      source = _ref2.source,
                      target = _ref2.target;
                  var newSourceMeta = {};
                  var newTargetMeta = {};
                  Object(lodash__WEBPACK_IMPORTED_MODULE_3__["map"])(iterrer, function (key) {
                    var selector = Object(lodash__WEBPACK_IMPORTED_MODULE_3__["join"])(['detail__', Object(lodash__WEBPACK_IMPORTED_MODULE_3__["split"])(key, ' ')], '');
                    Object(lodash__WEBPACK_IMPORTED_MODULE_3__["assign"])(newSourceMeta, _defineProperty({}, selector, source.metadata[key]));
                    Object(lodash__WEBPACK_IMPORTED_MODULE_3__["assign"])(newTargetMeta, _defineProperty({}, selector, target.metadata[key]));
                  });
                  nodes.add(Object.assign({
                    id: sourceExternalId,
                    title: source.description,
                    mainStat: source.name
                  }, newSourceMeta));
                  nodes.add(Object.assign({
                    id: targetExternalId,
                    title: target.description,
                    mainStat: target.name
                  }, newTargetMeta));
                  edges.add({
                    id: externalId,
                    source: sourceExternalId,
                    target: targetExternalId,
                    mainStat: Object(lodash__WEBPACK_IMPORTED_MODULE_3__["trim"])(Object(lodash__WEBPACK_IMPORTED_MODULE_3__["join"])(Object(lodash__WEBPACK_IMPORTED_MODULE_3__["map"])(labels, 'externalId'), ' '))
                  });
                });
                return _context.abrupt("return", {
                  data: [nodes, edges],
                  settings: {
                    labels: labels,
                    dataSetId: dataSetId,
                    externalId: externalId,
                    sourceExternalId: sourceExternalId,
                    sourceType: sourceType,
                    targetExternalId: targetExternalId,
                    targetType: targetType
                  }
                });

              case 15:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));
    };

    var url = instanceSettings.url,
        jsonData = instanceSettings.jsonData;
    var cogniteProject = jsonData.cogniteProject,
        oauthPassThru = jsonData.oauthPassThru,
        oauthClientCreds = jsonData.oauthClientCreds;
    _this.backendSrv = Object(_grafana_runtime__WEBPACK_IMPORTED_MODULE_2__["getBackendSrv"])();
    _this.templateSrv = Object(_grafana_runtime__WEBPACK_IMPORTED_MODULE_2__["getTemplateSrv"])();
    _this.url = url;
    _this.connector = new _connector__WEBPACK_IMPORTED_MODULE_5__["Connector"](cogniteProject, url, _this.backendSrv, oauthPassThru, oauthClientCreds);
    _this.project = cogniteProject;
    return _this;
  }
  /**
   * used by panels to get timeseries data
   */


  _createClass(CogniteDatasource, [{
    key: "query",
    value: function query(options) {
      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
        var _this2 = this;

        var validQueryTargets, queryTargets, templateQueryTargets, relationShipsQueryTargets, _groupTargets, eventTargets, tsTargets, extractorTargets, timeRange, responseData, templateResponseData, nodeResponse, _yield$this$fetchTime, failed, succeded, eventResults, extractorResults, _yield$this$templateQ, data, _yield$this$createRel, _data;

        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                validQueryTargets = filterEmptyQueryTargets(options.targets);
                queryTargets = Object(lodash__WEBPACK_IMPORTED_MODULE_3__["map"])(validQueryTargets, function (t) {
                  return _this2.replaceVariablesInTarget(t, options.scopedVars);
                });
                templateQueryTargets = Object(lodash__WEBPACK_IMPORTED_MODULE_3__["map"])(Object(lodash__WEBPACK_IMPORTED_MODULE_3__["filter"])(validQueryTargets, {
                  tab: _types__WEBPACK_IMPORTED_MODULE_9__["Tab"].Template
                }), 'templateQuery');
                relationShipsQueryTargets = Object(lodash__WEBPACK_IMPORTED_MODULE_3__["map"])(Object(lodash__WEBPACK_IMPORTED_MODULE_3__["filter"])(validQueryTargets, {
                  tab: _types__WEBPACK_IMPORTED_MODULE_9__["Tab"].Relationships
                }), 'relationsShipsQuery');
                _groupTargets = groupTargets(queryTargets), eventTargets = _groupTargets.eventTargets, tsTargets = _groupTargets.tsTargets, extractorTargets = _groupTargets.extractorTargets;
                timeRange = getRange(options.range);
                responseData = [];
                templateResponseData = [];
                nodeResponse = [];

                if (!queryTargets.length) {
                  _context2.next = 30;
                  break;
                }

                _context2.prev = 10;
                _context2.next = 13;
                return this.fetchTimeseriesForTargets(tsTargets, options);

              case 13:
                _yield$this$fetchTime = _context2.sent;
                failed = _yield$this$fetchTime.failed;
                succeded = _yield$this$fetchTime.succeded;
                _context2.next = 18;
                return this.fetchEventTargets(eventTargets, timeRange);

              case 18:
                eventResults = _context2.sent;
                _context2.next = 21;
                return this.fetchExtractorTargets(extractorTargets);

              case 21:
                extractorResults = _context2.sent;
                handleFailedTargets(failed);
                showWarnings(succeded);
                responseData = [].concat(_toConsumableArray(Object(_cdf_client__WEBPACK_IMPORTED_MODULE_4__["reduceTimeseries"])(succeded, timeRange)), _toConsumableArray(eventResults), _toConsumableArray(extractorResults));
                _context2.next = 30;
                break;

              case 27:
                _context2.prev = 27;
                _context2.t0 = _context2["catch"](10);

                /* eslint-disable-next-line no-console  */
                console.error(_context2.t0); // TODO: use app-events or something

              case 30:
                if (!templateQueryTargets.length) {
                  _context2.next = 42;
                  break;
                }

                _context2.prev = 31;
                _context2.next = 34;
                return this.templateQuery(Object.assign(Object.assign({}, options), {
                  targets: templateQueryTargets
                }));

              case 34:
                _yield$this$templateQ = _context2.sent;
                data = _yield$this$templateQ.data;
                templateResponseData = data;
                _context2.next = 42;
                break;

              case 39:
                _context2.prev = 39;
                _context2.t1 = _context2["catch"](31);

                /* eslint-disable-next-line no-console  */
                console.error(_context2.t1);

              case 42:
                if (!relationShipsQueryTargets.length) {
                  _context2.next = 54;
                  break;
                }

                _context2.prev = 43;
                _context2.next = 46;
                return this.createRelationshipsNode();

              case 46:
                _yield$this$createRel = _context2.sent;
                _data = _yield$this$createRel.data;
                nodeResponse = _data;
                _context2.next = 54;
                break;

              case 51:
                _context2.prev = 51;
                _context2.t2 = _context2["catch"](43);

                /* eslint-disable-next-line no-console  */
                console.error(_context2.t2);

              case 54:
                return _context2.abrupt("return", {
                  data: [].concat(_toConsumableArray(responseData), _toConsumableArray(templateResponseData), _toConsumableArray(nodeResponse))
                });

              case 55:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this, [[10, 27], [31, 39], [43, 51]]);
      }));
    }
  }, {
    key: "fetchTimeseriesForTargets",
    value: function fetchTimeseriesForTargets(queryTargets, options) {
      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
        var _this3 = this;

        var itemsForTargetsPromises, queryData, queries, metadata, queryProxy, requests;
        return regeneratorRuntime.wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                itemsForTargetsPromises = queryTargets.map(function (target) {
                  return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this3, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
                    return regeneratorRuntime.wrap(function _callee3$(_context3) {
                      while (1) {
                        switch (_context3.prev = _context3.next) {
                          case 0:
                            _context3.prev = 0;
                            _context3.next = 3;
                            return getDataQueryRequestItems(target, this.connector, options.intervalMs);

                          case 3:
                            return _context3.abrupt("return", _context3.sent);

                          case 6:
                            _context3.prev = 6;
                            _context3.t0 = _context3["catch"](0);
                            handleError(_context3.t0, target.refId);

                          case 9:
                            return _context3.abrupt("return", null);

                          case 10:
                          case "end":
                            return _context3.stop();
                        }
                      }
                    }, _callee3, this, [[0, 6]]);
                  }));
                });
                _context6.next = 3;
                return Promise.all(itemsForTargetsPromises);

              case 3:
                queryData = _context6.sent.filter(function (data) {
                  var _a;

                  return (_a = data === null || data === void 0 ? void 0 : data.items) === null || _a === void 0 ? void 0 : _a.length;
                });
                queries = Object(_cdf_client__WEBPACK_IMPORTED_MODULE_4__["formQueriesForTargets"])(queryData, options);
                _context6.next = 7;
                return Promise.all(queryData.map(function (_ref3) {
                  var target = _ref3.target,
                      items = _ref3.items,
                      type = _ref3.type;
                  return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this3, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
                    var labels;
                    return regeneratorRuntime.wrap(function _callee4$(_context4) {
                      while (1) {
                        switch (_context4.prev = _context4.next) {
                          case 0:
                            labels = [];
                            _context4.prev = 1;
                            _context4.next = 4;
                            return Object(_cdf_client__WEBPACK_IMPORTED_MODULE_4__["getLabelsForTarget"])(target, items, this.connector);

                          case 4:
                            labels = _context4.sent;
                            _context4.next = 10;
                            break;

                          case 7:
                            _context4.prev = 7;
                            _context4.t0 = _context4["catch"](1);
                            handleError(_context4.t0, target.refId);

                          case 10:
                            return _context4.abrupt("return", {
                              target: target,
                              labels: labels,
                              type: type
                            });

                          case 11:
                          case "end":
                            return _context4.stop();
                        }
                      }
                    }, _callee4, this, [[1, 7]]);
                  }));
                }));

              case 7:
                metadata = _context6.sent;

                queryProxy = function queryProxy(_ref4) {
                  var _ref5 = _slicedToArray(_ref4, 2),
                      data = _ref5[0],
                      metadata = _ref5[1];

                  return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this3, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
                    var target, type, chunkSize, request, result;
                    return regeneratorRuntime.wrap(function _callee5$(_context5) {
                      while (1) {
                        switch (_context5.prev = _context5.next) {
                          case 0:
                            target = metadata.target, type = metadata.type;
                            chunkSize = type === 'synthetic' ? 10 : 100;
                            request = {
                              data: data,
                              path: Object(_cdf_client__WEBPACK_IMPORTED_MODULE_4__["datapointsPath"])(type),
                              method: _types__WEBPACK_IMPORTED_MODULE_9__["HttpMethod"].POST,
                              requestId: Object(_utils__WEBPACK_IMPORTED_MODULE_10__["getRequestId"])(options, target)
                            };
                            _context5.prev = 3;
                            _context5.next = 6;
                            return this.connector.chunkAndFetch(request, chunkSize);

                          case 6:
                            result = _context5.sent;
                            return _context5.abrupt("return", new _types__WEBPACK_IMPORTED_MODULE_9__["Ok"]({
                              result: result,
                              metadata: metadata
                            }));

                          case 10:
                            _context5.prev = 10;
                            _context5.t0 = _context5["catch"](3);
                            return _context5.abrupt("return", new _types__WEBPACK_IMPORTED_MODULE_9__["Err"]({
                              error: _context5.t0,
                              metadata: metadata
                            }));

                          case 13:
                          case "end":
                            return _context5.stop();
                        }
                      }
                    }, _callee5, this, [[3, 10]]);
                  }));
                };

                requests = queries.map(function (query, i) {
                  return [query, metadata[i]];
                }); // I.e queries.zip(metadata)

                return _context6.abrupt("return", Object(_cdf_client__WEBPACK_IMPORTED_MODULE_4__["concurrent"])(requests, queryProxy));

              case 11:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6);
      }));
    }
    /**
     * Resolves Grafana variables in QueryTarget object (props: label, expr, assetQuery.target)
     * E.g. {..., label: 'date: ${__from:date:YYYY-MM}'} -> {..., label: 'date: 2020-07'}
     */

  }, {
    key: "replaceVariablesInTarget",
    value: function replaceVariablesInTarget(target, scopedVars) {
      var expr = target.expr,
          assetQuery = target.assetQuery,
          label = target.label,
          eventQuery = target.eventQuery;

      var _this$replaceVariable = this.replaceVariablesArr([expr, label, assetQuery === null || assetQuery === void 0 ? void 0 : assetQuery.target, eventQuery === null || eventQuery === void 0 ? void 0 : eventQuery.expr], scopedVars),
          _this$replaceVariable2 = _slicedToArray(_this$replaceVariable, 4),
          exprTemplated = _this$replaceVariable2[0],
          labelTemplated = _this$replaceVariable2[1],
          assetTargetTemplated = _this$replaceVariable2[2],
          eventExprTemplated = _this$replaceVariable2[3];

      var templatedAssetQuery = assetQuery && {
        assetQuery: Object.assign(Object.assign({}, assetQuery), {
          target: assetTargetTemplated
        })
      };
      var templatedEventQuery = eventQuery && {
        eventQuery: Object.assign(Object.assign({}, eventQuery), {
          expr: eventExprTemplated
        })
      };
      return Object.assign(Object.assign(Object.assign(Object.assign({}, target), templatedAssetQuery), templatedEventQuery), {
        expr: exprTemplated,
        label: labelTemplated
      });
    }
  }, {
    key: "replaceVariable",
    value: function replaceVariable(query, scopedVars) {
      return this.templateSrv.replace(query.trim(), scopedVars);
    }
  }, {
    key: "replaceVariablesArr",
    value: function replaceVariablesArr(arr, scopedVars) {
      var _this4 = this;

      return arr.map(function (str) {
        return str && _this4.replaceVariable(str, scopedVars);
      });
    }
  }, {
    key: "fetchEventsForTarget",
    value: function fetchEventsForTarget(_ref6, timeFrame) {
      var eventQuery = _ref6.eventQuery,
          refId = _ref6.refId;
      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
        var timeRange, _yield$this$fetchEven, items, hasMore;

        return regeneratorRuntime.wrap(function _callee7$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                timeRange = eventQuery.activeAtTimeRange ? timeFrame : {};
                _context7.prev = 1;
                _context7.next = 4;
                return this.fetchEvents(eventQuery.expr, timeRange);

              case 4:
                _yield$this$fetchEven = _context7.sent;
                items = _yield$this$fetchEven.items;
                hasMore = _yield$this$fetchEven.hasMore;

                if (hasMore) {
                  emitEvent(_constants__WEBPACK_IMPORTED_MODULE_6__["responseWarningEvent"], {
                    refId: refId,
                    warning: _constants__WEBPACK_IMPORTED_MODULE_6__["EVENTS_LIMIT_WARNING"]
                  });
                }

                return _context7.abrupt("return", items);

              case 11:
                _context7.prev = 11;
                _context7.t0 = _context7["catch"](1);
                handleError(_context7.t0, refId);

              case 14:
                return _context7.abrupt("return", []);

              case 15:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee7, this, [[1, 11]]);
      }));
    }
  }, {
    key: "fetchExtractorsForTarget",
    value: function fetchExtractorsForTarget(_ref7) {
      var extractorQuery = _ref7.extractorQuery,
          refId = _ref7.refId;
      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee8() {
        var _yield$this$fetchExtr, items;

        return regeneratorRuntime.wrap(function _callee8$(_context8) {
          while (1) {
            switch (_context8.prev = _context8.next) {
              case 0:
                _context8.prev = 0;
                _context8.next = 3;
                return this.fetchExtractors(extractorQuery.expr);

              case 3:
                _yield$this$fetchExtr = _context8.sent;
                items = _yield$this$fetchExtr.items;
                return _context8.abrupt("return", items);

              case 8:
                _context8.prev = 8;
                _context8.t0 = _context8["catch"](0);
                handleError(_context8.t0, refId);

              case 11:
                return _context8.abrupt("return", []);

              case 12:
              case "end":
                return _context8.stop();
            }
          }
        }, _callee8, this, [[0, 8]]);
      }));
    }
  }, {
    key: "fetchEventTargets",
    value: function fetchEventTargets(targets, _ref8) {
      var _ref9 = _slicedToArray(_ref8, 2),
          start = _ref9[0],
          end = _ref9[1];

      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee10() {
        var _this5 = this;

        var timeFrame;
        return regeneratorRuntime.wrap(function _callee10$(_context10) {
          while (1) {
            switch (_context10.prev = _context10.next) {
              case 0:
                timeFrame = {
                  activeAtTime: {
                    min: start,
                    max: end
                  }
                };
                return _context10.abrupt("return", Promise.all(targets.map(function (target) {
                  return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this5, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee9() {
                    var events;
                    return regeneratorRuntime.wrap(function _callee9$(_context9) {
                      while (1) {
                        switch (_context9.prev = _context9.next) {
                          case 0:
                            _context9.next = 2;
                            return this.fetchEventsForTarget(target, timeFrame);

                          case 2:
                            events = _context9.sent;
                            return _context9.abrupt("return", Object(_cdf_client__WEBPACK_IMPORTED_MODULE_4__["convertItemsToTable"])(events, target.eventQuery.columns));

                          case 4:
                          case "end":
                            return _context9.stop();
                        }
                      }
                    }, _callee9, this);
                  }));
                })));

              case 2:
              case "end":
                return _context10.stop();
            }
          }
        }, _callee10);
      }));
    }
  }, {
    key: "fetchExtractorTargets",
    value: function fetchExtractorTargets(targets) {
      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee12() {
        var _this6 = this;

        return regeneratorRuntime.wrap(function _callee12$(_context12) {
          while (1) {
            switch (_context12.prev = _context12.next) {
              case 0:
                return _context12.abrupt("return", Promise.all(targets.map(function (target) {
                  return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this6, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee11() {
                    var extpipes;
                    return regeneratorRuntime.wrap(function _callee11$(_context11) {
                      while (1) {
                        switch (_context11.prev = _context11.next) {
                          case 0:
                            _context11.next = 2;
                            return this.fetchExtractorsForTarget(target);

                          case 2:
                            extpipes = _context11.sent;
                            return _context11.abrupt("return", Object(_cdf_client__WEBPACK_IMPORTED_MODULE_4__["convertItemsToTable"])(extpipes, target.extractorQuery.columns));

                          case 4:
                          case "end":
                            return _context11.stop();
                        }
                      }
                    }, _callee11, this);
                  }));
                })));

              case 1:
              case "end":
                return _context12.stop();
            }
          }
        }, _callee12);
      }));
    }
  }, {
    key: "fetchEvents",
    value: function fetchEvents(expr, timeRange) {
      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee13() {
        var _parseQuery, filters, params, data, items;

        return regeneratorRuntime.wrap(function _callee13$(_context13) {
          while (1) {
            switch (_context13.prev = _context13.next) {
              case 0:
                _parseQuery = Object(_parser_events_assets__WEBPACK_IMPORTED_MODULE_7__["parse"])(expr), filters = _parseQuery.filters, params = _parseQuery.params;
                data = {
                  filter: Object.assign(Object.assign({}, timeRange), params),
                  limit: _constants__WEBPACK_IMPORTED_MODULE_6__["EVENTS_PAGE_LIMIT"]
                };
                _context13.next = 4;
                return this.connector.fetchItems({
                  data: data,
                  path: "/events/list",
                  method: _types__WEBPACK_IMPORTED_MODULE_9__["HttpMethod"].POST
                });

              case 4:
                items = _context13.sent;
                return _context13.abrupt("return", {
                  items: Object(_utils__WEBPACK_IMPORTED_MODULE_10__["applyFilters"])(items, filters),
                  hasMore: items.length === _constants__WEBPACK_IMPORTED_MODULE_6__["EVENTS_PAGE_LIMIT"]
                });

              case 6:
              case "end":
                return _context13.stop();
            }
          }
        }, _callee13, this);
      }));
    }
  }, {
    key: "fetchExtractors",
    value: function fetchExtractors(expr) {
      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee14() {
        var data, items;
        return regeneratorRuntime.wrap(function _callee14$(_context14) {
          while (1) {
            switch (_context14.prev = _context14.next) {
              case 0:
                data = {};
                _context14.next = 3;
                return this.connector.fetchItems({
                  data: data,
                  path: "/extpipes/list",
                  method: _types__WEBPACK_IMPORTED_MODULE_9__["HttpMethod"].POST
                });

              case 3:
                items = _context14.sent;
                return _context14.abrupt("return", {
                  items: items
                });

              case 5:
              case "end":
                return _context14.stop();
            }
          }
        }, _callee14, this);
      }));
    }
    /**
     * used by dashboards to get annotations (events)
     */

  }, {
    key: "annotationQuery",
    value: function annotationQuery(options) {
      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee15() {
        var range, annotation, query, error, _getRange, _getRange2, rangeStart, rangeEnd, timeRange, evaluatedQuery, _yield$this$fetchEven2, items;

        return regeneratorRuntime.wrap(function _callee15$(_context15) {
          while (1) {
            switch (_context15.prev = _context15.next) {
              case 0:
                range = options.range, annotation = options.annotation;
                query = annotation.query, error = annotation.error;

                if (!(error || !query)) {
                  _context15.next = 4;
                  break;
                }

                return _context15.abrupt("return", []);

              case 4:
                _getRange = getRange(range), _getRange2 = _slicedToArray(_getRange, 2), rangeStart = _getRange2[0], rangeEnd = _getRange2[1];
                timeRange = {
                  activeAtTime: {
                    min: rangeStart,
                    max: rangeEnd
                  }
                };
                evaluatedQuery = this.replaceVariable(query);
                _context15.next = 9;
                return this.fetchEvents(evaluatedQuery, timeRange);

              case 9:
                _yield$this$fetchEven2 = _context15.sent;
                items = _yield$this$fetchEven2.items;
                return _context15.abrupt("return", items.map(function (_ref10) {
                  var description = _ref10.description,
                      startTime = _ref10.startTime,
                      endTime = _ref10.endTime,
                      type = _ref10.type;
                  return {
                    annotation: annotation,
                    isRegion: true,
                    text: description,
                    time: startTime,
                    timeEnd: endTime || rangeEnd,
                    title: type
                  };
                }));

              case 12:
              case "end":
                return _context15.stop();
            }
          }
        }, _callee15, this);
      }));
    }
    /**
     * used by dashboards to get annotations (events)
     */

  }, {
    key: "extPipelinesQuery",
    value: function extPipelinesQuery(options) {
      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee16() {
        var range, annotation, query, error, _getRange3, _getRange4, rangeStart, rangeEnd, timeRange, evaluatedQuery, _yield$this$fetchExtr2, items;

        return regeneratorRuntime.wrap(function _callee16$(_context16) {
          while (1) {
            switch (_context16.prev = _context16.next) {
              case 0:
                range = options.range, annotation = options.annotation;
                query = annotation.query, error = annotation.error;

                if (!(error || !query)) {
                  _context16.next = 4;
                  break;
                }

                return _context16.abrupt("return", []);

              case 4:
                _getRange3 = getRange(range), _getRange4 = _slicedToArray(_getRange3, 2), rangeStart = _getRange4[0], rangeEnd = _getRange4[1];
                timeRange = {
                  activeAtTime: {
                    min: rangeStart,
                    max: rangeEnd
                  }
                };
                evaluatedQuery = this.replaceVariable(query);
                _context16.next = 9;
                return this.fetchExtractors(evaluatedQuery);

              case 9:
                _yield$this$fetchExtr2 = _context16.sent;
                items = _yield$this$fetchExtr2.items;
                return _context16.abrupt("return", items.map(function (_ref11) {
                  var id = _ref11.id;
                  return {
                    annotation: annotation,
                    isRegion: true
                  };
                }));

              case 12:
              case "end":
                return _context16.stop();
            }
          }
        }, _callee16, this);
      }));
    }
    /**
     * used by query editor to search for assets/timeseries
     */

  }, {
    key: "getOptionsForDropdown",
    value: function getOptionsForDropdown(query, type, options) {
      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee17() {
        var _resources;

        var resources, data, items;
        return regeneratorRuntime.wrap(function _callee17$(_context17) {
          while (1) {
            switch (_context17.prev = _context17.next) {
              case 0:
                resources = (_resources = {}, _defineProperty(_resources, _types__WEBPACK_IMPORTED_MODULE_9__["Tab"].Asset, 'assets'), _defineProperty(_resources, _types__WEBPACK_IMPORTED_MODULE_9__["Tab"].Timeseries, 'timeseries'), _resources);
                data = query ? {
                  search: {
                    query: query
                  }
                } : {};
                _context17.next = 4;
                return this.connector.fetchItems({
                  data: data,
                  path: "/".concat(resources[type], "/search"),
                  method: _types__WEBPACK_IMPORTED_MODULE_9__["HttpMethod"].POST,
                  params: options,
                  cacheTime: _constants__WEBPACK_IMPORTED_MODULE_6__["CacheTime"].Dropdown
                });

              case 4:
                items = _context17.sent;
                return _context17.abrupt("return", items.map(resource2DropdownOption));

              case 6:
              case "end":
                return _context17.stop();
            }
          }
        }, _callee17, this);
      }));
    }
    /**
     * used by query editor to search for assets/timeseries
     */

  }, {
    key: "getOptionsForExtractorDropdown",
    value: function getOptionsForExtractorDropdown(query) {
      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee18() {
        var _resources2;

        var resources, data, items;
        return regeneratorRuntime.wrap(function _callee18$(_context18) {
          while (1) {
            switch (_context18.prev = _context18.next) {
              case 0:
                resources = (_resources2 = {}, _defineProperty(_resources2, _types__WEBPACK_IMPORTED_MODULE_9__["Tab"].Asset, 'assets'), _defineProperty(_resources2, _types__WEBPACK_IMPORTED_MODULE_9__["Tab"].Timeseries, 'timeseries'), _resources2);
                data = query ? {
                  search: {
                    query: query
                  }
                } : {};
                _context18.next = 4;
                return this.connector.fetchItems({
                  data: data,
                  path: "/extpipes",
                  method: _types__WEBPACK_IMPORTED_MODULE_9__["HttpMethod"].GET,
                  cacheTime: _constants__WEBPACK_IMPORTED_MODULE_6__["CacheTime"].Dropdown
                });

              case 4:
                items = _context18.sent;
                return _context18.abrupt("return", items.map(resource2DropdownOption));

              case 6:
              case "end":
                return _context18.stop();
            }
          }
        }, _callee18, this);
      }));
    }
    /**
     * used by query editor to get metric suggestions (template variables)
     */

  }, {
    key: "metricFindQuery",
    value: function metricFindQuery(_ref12) {
      var query = _ref12.query;
      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee19() {
        var params, filters, _parseQuery2, data, assets, filteredAssets;

        return regeneratorRuntime.wrap(function _callee19$(_context19) {
          while (1) {
            switch (_context19.prev = _context19.next) {
              case 0:
                _context19.prev = 0;
                _parseQuery2 = Object(_parser_events_assets__WEBPACK_IMPORTED_MODULE_7__["parse"])(this.replaceVariable(query));
                params = _parseQuery2.params;
                filters = _parseQuery2.filters;
                _context19.next = 9;
                break;

              case 6:
                _context19.prev = 6;
                _context19.t0 = _context19["catch"](0);
                return _context19.abrupt("return", []);

              case 9:
                data = {
                  filter: params,
                  limit: 1000
                };
                _context19.next = 12;
                return this.connector.fetchItems({
                  data: data,
                  path: "/assets/list",
                  method: _types__WEBPACK_IMPORTED_MODULE_9__["HttpMethod"].POST
                });

              case 12:
                assets = _context19.sent;
                filteredAssets = Object(_utils__WEBPACK_IMPORTED_MODULE_10__["applyFilters"])(assets, filters);
                return _context19.abrupt("return", filteredAssets.map(function (_ref13) {
                  var name = _ref13.name,
                      id = _ref13.id;
                  return {
                    text: name,
                    value: id
                  };
                }));

              case 15:
              case "end":
                return _context19.stop();
            }
          }
        }, _callee19, this, [[0, 6]]);
      }));
    }
  }, {
    key: "listDomains",
    value: function listDomains() {
      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee20() {
        var _this7 = this;

        return regeneratorRuntime.wrap(function _callee20$(_context20) {
          while (1) {
            switch (_context20.prev = _context20.next) {
              case 0:
                if (!this.cachedDomains.length) {
                  _context20.next = 2;
                  break;
                }

                return _context20.abrupt("return", this.cachedDomains);

              case 2:
                return _context20.abrupt("return", this.fetchTemplateName().then(function (res) {
                  _this7.cachedDomains = res.data.items;
                  return _this7.cachedDomains;
                }));

              case 3:
              case "end":
                return _context20.stop();
            }
          }
        }, _callee20, this);
      }));
    }
  }, {
    key: "getDomainsForDropdown",
    value: function getDomainsForDropdown() {
      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee21() {
        var domains;
        return regeneratorRuntime.wrap(function _callee21$(_context21) {
          while (1) {
            switch (_context21.prev = _context21.next) {
              case 0:
                _context21.next = 2;
                return this.listDomains();

              case 2:
                domains = _context21.sent;
                return _context21.abrupt("return", Object(lodash__WEBPACK_IMPORTED_MODULE_3__["map"])(domains, function (_ref14) {
                  var externalId = _ref14.externalId;
                  return {
                    label: externalId,
                    value: Object(lodash__WEBPACK_IMPORTED_MODULE_3__["replace"])(externalId, ' ', '%20')
                  };
                }));

              case 4:
              case "end":
                return _context21.stop();
            }
          }
        }, _callee21, this);
      }));
    }
  }, {
    key: "getCurrentDomainVersion",
    value: function getCurrentDomainVersion(domainExternalId) {
      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee22() {
        return regeneratorRuntime.wrap(function _callee22$(_context22) {
          while (1) {
            switch (_context22.prev = _context22.next) {
              case 0:
                return _context22.abrupt("return", this.fetchTemplateVersion(domainExternalId));

              case 1:
              case "end":
                return _context22.stop();
            }
          }
        }, _callee22, this);
      }));
    }
  }, {
    key: "postQuery",
    value: function postQuery(query, payload) {
      var params = Object.assign(Object.assign({}, query), {
        expr: payload
      });
      return this.fetchTemplateForTargets(params).then(function (results) {
        return {
          query: query,
          results: results
        };
      })["catch"](function (err) {
        if (err.data && err.data.error) {
          throw {
            message: "GraphQL error: ".concat(err.data.error.reason),
            error: err.data.error
          };
        }

        throw err;
      });
    }
  }, {
    key: "createQuery",
    value: function createQuery(query, range, intervalMs) {
      var scopedVars = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : undefined;
      var payload = query.expr;

      if (range) {
        payload = Object(lodash__WEBPACK_IMPORTED_MODULE_3__["replace"])(payload, '$__from', range.from.valueOf().toString());
        payload = Object(lodash__WEBPACK_IMPORTED_MODULE_3__["replace"])(payload, '$__to', range.to.valueOf().toString());
        payload = Object(lodash__WEBPACK_IMPORTED_MODULE_3__["replace"])(payload, '$__granularity', "\"".concat(Object(_utils__WEBPACK_IMPORTED_MODULE_10__["toGranularityWithLowerBound"])(intervalMs), "\""));
      }

      payload = this.templateSrv.replace(payload, scopedVars);
      return this.postQuery(query, payload);
    }
  }, {
    key: "templateQuery",
    value: function templateQuery(options) {
      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee23() {
        var _this8 = this;

        return regeneratorRuntime.wrap(function _callee23$(_context23) {
          while (1) {
            switch (_context23.prev = _context23.next) {
              case 0:
                return _context23.abrupt("return", Promise.all(options.targets.map(function (target) {
                  return _this8.createQuery(Object(lodash__WEBPACK_IMPORTED_MODULE_3__["defaults"])(target, _types__WEBPACK_IMPORTED_MODULE_9__["defaultQuery"]), options.range, options.intervalMs, options.scopedVars);
                })).then(function (results) {
                  var dataFrameArray = [];
                  Object(lodash__WEBPACK_IMPORTED_MODULE_3__["map"])(results, function (res) {
                    var refId = res.query.refId;
                    var dataPathArray = Object(_utils__WEBPACK_IMPORTED_MODULE_10__["getDataPathArray"])(res.query.dataPath);
                    var _res$query = res.query,
                        groupBy = _res$query.groupBy,
                        aliasBy = _res$query.aliasBy,
                        dataPointsPath = _res$query.dataPointsPath;
                    var datapointsPaths = Object(lodash__WEBPACK_IMPORTED_MODULE_3__["split"])(dataPointsPath, ',');
                    var splited = Object(lodash__WEBPACK_IMPORTED_MODULE_3__["split"])(groupBy, ',');
                    var groupByList = [];
                    Object(lodash__WEBPACK_IMPORTED_MODULE_3__["map"])(splited, function (element) {
                      var trimmed = element.trim();

                      if (trimmed) {
                        groupByList.push(trimmed);
                      }
                    });
                    Object(lodash__WEBPACK_IMPORTED_MODULE_3__["map"])(dataPathArray, function (dataPath) {
                      var dataFrameMap = {};
                      var docs = Object(_utils__WEBPACK_IMPORTED_MODULE_10__["getDocs"])(res.results.data, dataPath);
                      Object(lodash__WEBPACK_IMPORTED_MODULE_3__["map"])(docs, function (doc) {
                        var identifiers = [];
                        Object(lodash__WEBPACK_IMPORTED_MODULE_3__["map"])(groupByList, function (groupByElement) {
                          identifiers.push(Object(lodash__WEBPACK_IMPORTED_MODULE_3__["get"])(doc, groupByElement));
                        });
                        var identifiersString = identifiers.toString();
                        var dataFrame = Object(_utils__WEBPACK_IMPORTED_MODULE_10__["createDatapointsDataFrame"])(identifiersString, refId);
                        Object(lodash__WEBPACK_IMPORTED_MODULE_3__["map"])(datapointsPaths, function (datapointsPath) {
                          var trimmedDatapointsPath = datapointsPath.trim();
                          var value = Object(lodash__WEBPACK_IMPORTED_MODULE_3__["get"])(doc, trimmedDatapointsPath);
                          Object(lodash__WEBPACK_IMPORTED_MODULE_3__["assignIn"])(dataFrameMap, _defineProperty({}, identifiersString, dataFrame));
                          var hasDatapoints = value != null && value.length > 0;

                          if (hasDatapoints) {
                            Object(lodash__WEBPACK_IMPORTED_MODULE_3__["map"])(value, function (datapoint) {
                              return dataFrame.add(datapoint);
                            });
                          }
                        });
                      });
                      Object(lodash__WEBPACK_IMPORTED_MODULE_3__["map"])(dataFrameMap, function (d) {
                        return dataFrameArray.push(d);
                      });
                    });
                  });
                  return {
                    data: dataFrameArray
                  };
                }));

              case 1:
              case "end":
                return _context23.stop();
            }
          }
        }, _callee23);
      }));
    }
  }, {
    key: "checkLoginStatusApiKey",
    value: function checkLoginStatusApiKey() {
      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee24() {
        var hasAccessToProject, isLoggedIn, _yield$this$connector, status, data, _ref15, project, loggedIn;

        return regeneratorRuntime.wrap(function _callee24$(_context24) {
          while (1) {
            switch (_context24.prev = _context24.next) {
              case 0:
                hasAccessToProject = false;
                isLoggedIn = false;
                _context24.next = 4;
                return this.connector.request({
                  path: 'login/status'
                });

              case 4:
                _yield$this$connector = _context24.sent;
                status = _yield$this$connector.status;
                data = _yield$this$connector.data;

                if (status === 200) {
                  _ref15 = (data === null || data === void 0 ? void 0 : data.data) || {}, project = _ref15.project, loggedIn = _ref15.loggedIn;
                  hasAccessToProject = project === this.project;
                  isLoggedIn = loggedIn;
                }

                return _context24.abrupt("return", [hasAccessToProject, isLoggedIn]);

              case 9:
              case "end":
                return _context24.stop();
            }
          }
        }, _callee24, this);
      }));
    }
  }, {
    key: "checkLoginStatusOAuth",
    value: function checkLoginStatusOAuth() {
      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee25() {
        var hasAccessToProject, isLoggedIn, _yield$this$connector2, status, data, _ref16, _ref16$projects, projects, projectNames;

        return regeneratorRuntime.wrap(function _callee25$(_context25) {
          while (1) {
            switch (_context25.prev = _context25.next) {
              case 0:
                hasAccessToProject = false;
                isLoggedIn = false;
                _context25.next = 4;
                return this.connector.request({
                  path: 'api/v1/token/inspect'
                });

              case 4:
                _yield$this$connector2 = _context25.sent;
                status = _yield$this$connector2.status;
                data = _yield$this$connector2.data;

                if (status === 200) {
                  _ref16 = data || {}, _ref16$projects = _ref16.projects, projects = _ref16$projects === void 0 ? [] : _ref16$projects;
                  projectNames = projects.map(function (_ref17) {
                    var projectUrlName = _ref17.projectUrlName;
                    return projectUrlName;
                  });
                  hasAccessToProject = projectNames.includes(this.project);
                  isLoggedIn = true;
                }

                return _context25.abrupt("return", [hasAccessToProject, isLoggedIn]);

              case 9:
              case "end":
                return _context25.stop();
            }
          }
        }, _callee25, this);
      }));
    }
    /**
     * used by data source configuration page to make sure the connection is working
     */

  }, {
    key: "testDatasource",
    value: function testDatasource() {
      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee26() {
        var hasAccessToProject, isLoggedIn, _yield$this$checkLogi, _yield$this$checkLogi2, _yield$this$checkLogi3, _yield$this$checkLogi4;

        return regeneratorRuntime.wrap(function _callee26$(_context26) {
          while (1) {
            switch (_context26.prev = _context26.next) {
              case 0:
                hasAccessToProject = false;
                isLoggedIn = false;

                if (!this.connector.isUsingOAuth()) {
                  _context26.next = 11;
                  break;
                }

                _context26.next = 5;
                return this.checkLoginStatusOAuth();

              case 5:
                _yield$this$checkLogi = _context26.sent;
                _yield$this$checkLogi2 = _slicedToArray(_yield$this$checkLogi, 2);
                hasAccessToProject = _yield$this$checkLogi2[0];
                isLoggedIn = _yield$this$checkLogi2[1];
                _context26.next = 17;
                break;

              case 11:
                _context26.next = 13;
                return this.checkLoginStatusApiKey();

              case 13:
                _yield$this$checkLogi3 = _context26.sent;
                _yield$this$checkLogi4 = _slicedToArray(_yield$this$checkLogi3, 2);
                hasAccessToProject = _yield$this$checkLogi4[0];
                isLoggedIn = _yield$this$checkLogi4[1];

              case 17:
                _context26.t0 = true;
                _context26.next = _context26.t0 === (isLoggedIn && hasAccessToProject) ? 20 : _context26.t0 === isLoggedIn ? 21 : 22;
                break;

              case 20:
                return _context26.abrupt("return", {
                  status: 'success',
                  message: 'Your Cognite credentials are valid',
                  title: 'Success'
                });

              case 21:
                return _context26.abrupt("return", {
                  status: 'warning',
                  message: "Cannot access '".concat(this.project, "' project"),
                  title: 'Warning'
                });

              case 22:
                return _context26.abrupt("return", {
                  status: 'error',
                  message: 'Your Cognite credentials are invalid',
                  title: 'Error'
                });

              case 23:
              case "end":
                return _context26.stop();
            }
          }
        }, _callee26, this);
      }));
    }
  }]);

  return CogniteDatasource;
}(_grafana_data__WEBPACK_IMPORTED_MODULE_1__["DataSourceApi"]);


function filterEmptyQueryTargets(targets) {
  return targets.filter(function (target) {
    if (target && !target.hide) {
      var tab = target.tab,
          assetQuery = target.assetQuery,
          eventQuery = target.eventQuery,
          templateQuery = target.templateQuery,
          extractorQuery = target.extractorQuery,
          relationsShipsQuery = target.relationsShipsQuery;

      switch (tab) {
        case _types__WEBPACK_IMPORTED_MODULE_9__["Tab"].Event:
          return eventQuery === null || eventQuery === void 0 ? void 0 : eventQuery.expr;

        case _types__WEBPACK_IMPORTED_MODULE_9__["Tab"].Extractor:
          return true;

        case _types__WEBPACK_IMPORTED_MODULE_9__["Tab"].Asset:
          return assetQuery === null || assetQuery === void 0 ? void 0 : assetQuery.target;

        case _types__WEBPACK_IMPORTED_MODULE_9__["Tab"].Custom:
          return target.expr;

        case _types__WEBPACK_IMPORTED_MODULE_9__["Tab"].Template:
          return templateQuery && templateQuery.domain && templateQuery.domainVersion && templateQuery.expr;

        case _types__WEBPACK_IMPORTED_MODULE_9__["Tab"].Relationships:
          {
            return relationsShipsQuery;
          }

        case _types__WEBPACK_IMPORTED_MODULE_9__["Tab"].Timeseries:
        default:
          return target.target;
      }
    }

    return false;
  });
}

function handleFailedTargets(failed) {
  failed.filter(_types__WEBPACK_IMPORTED_MODULE_9__["isError"]).filter(function (_ref18) {
    var error = _ref18.error;
    return !error.cancelled;
  }) // if response was cancelled, no need to show error message
  .forEach(function (_ref19) {
    var error = _ref19.error,
        metadata = _ref19.metadata;
    return handleError(error, metadata.target.refId);
  });
}

function resource2DropdownOption(resource) {
  var id = resource.id,
      name = resource.name,
      externalId = resource.externalId,
      description = resource.description;
  var value = id.toString();
  var label = name || externalId || value;
  return {
    label: label,
    value: value,
    description: description,
    externalId: externalId,
    id: id
  };
}
function getRange(range) {
  var timeFrom = range.from.valueOf();
  var timeTo = range.to.valueOf();
  return [timeFrom, timeTo];
}

function emitEvent(event, payload) {
  return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee27() {
    var appEvents;
    return regeneratorRuntime.wrap(function _callee27$(_context27) {
      while (1) {
        switch (_context27.prev = _context27.next) {
          case 0:
            _context27.next = 2;
            return appEventsLoader;

          case 2:
            appEvents = _context27.sent;
            return _context27.abrupt("return", appEvents.emit(event, payload));

          case 4:
          case "end":
            return _context27.stop();
        }
      }
    }, _callee27);
  }));
}

function handleError(error, refId) {
  var errMessage = Object(_cdf_client__WEBPACK_IMPORTED_MODULE_4__["stringifyError"])(error);
  emitEvent(_constants__WEBPACK_IMPORTED_MODULE_6__["failedResponseEvent"], {
    refId: refId,
    error: errMessage
  });
}

function showWarnings(responses) {
  responses.forEach(function (_ref20) {
    var result = _ref20.result,
        metadata = _ref20.metadata;
    var items = result.data.items;
    var limit = result.config.data.limit;
    var refId = metadata.target.refId;
    var warning = [Object(_cdf_client__WEBPACK_IMPORTED_MODULE_4__["getLimitsWarnings"])(items, limit), Object(_cdf_client__WEBPACK_IMPORTED_MODULE_4__["getCalculationWarnings"])(items)].filter(Boolean).join('\n\n');

    if (warning) {
      emitEvent(_constants__WEBPACK_IMPORTED_MODULE_6__["responseWarningEvent"], {
        refId: refId,
        warning: warning
      });
    }
  });
}

function getDataQueryRequestType(_ref21) {
  var tab = _ref21.tab,
      latestValue = _ref21.latestValue;

  switch (tab) {
    case _types__WEBPACK_IMPORTED_MODULE_9__["Tab"].Custom:
      {
        return 'synthetic';
      }

    default:
      {
        return latestValue ? 'latest' : 'data';
      }
  }
}

function findAssetTimeseries(_ref22, connector) {
  var refId = _ref22.refId,
      assetQuery = _ref22.assetQuery;
  return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee28() {
    var assetId, filter, limit, ts;
    return regeneratorRuntime.wrap(function _callee28$(_context28) {
      while (1) {
        switch (_context28.prev = _context28.next) {
          case 0:
            assetId = assetQuery.target;
            filter = assetQuery.includeSubtrees ? {
              assetSubtreeIds: [{
                id: Number(assetId)
              }]
            } : {
              assetIds: [assetId]
            }; // since /dataquery can only have 100 items and checkboxes become difficult to use past 100 items,
            //  we only get the first 100 timeseries, and show a warning if there are too many timeseries

            limit = 101;
            _context28.next = 5;
            return Object(_cdf_client__WEBPACK_IMPORTED_MODULE_4__["getTimeseries"])({
              filter: filter,
              limit: limit
            }, connector);

          case 5:
            ts = _context28.sent;

            if (ts.length === limit) {
              emitEvent(_constants__WEBPACK_IMPORTED_MODULE_6__["responseWarningEvent"], {
                refId: refId,
                warning: _constants__WEBPACK_IMPORTED_MODULE_6__["TIMESERIES_LIMIT_WARNING"]
              });
              ts.splice(-1);
            }

            return _context28.abrupt("return", ts);

          case 8:
          case "end":
            return _context28.stop();
        }
      }
    }, _callee28);
  }));
}

function getDataQueryRequestItems(target, connector, intervalMs) {
  return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee29() {
    var tab, expr, type, items, timeseries, defaultInterval;
    return regeneratorRuntime.wrap(function _callee29$(_context29) {
      while (1) {
        switch (_context29.prev = _context29.next) {
          case 0:
            tab = target.tab, expr = target.expr;
            type = getDataQueryRequestType(target);
            _context29.t0 = tab;
            _context29.next = _context29.t0 === undefined ? 5 : _context29.t0 === _types__WEBPACK_IMPORTED_MODULE_9__["Tab"].Timeseries ? 5 : _context29.t0 === _types__WEBPACK_IMPORTED_MODULE_9__["Tab"].Asset ? 7 : _context29.t0 === _types__WEBPACK_IMPORTED_MODULE_9__["Tab"].Custom ? 12 : _context29.t0 === _types__WEBPACK_IMPORTED_MODULE_9__["Tab"].Relationships ? 17 : _context29.t0 === _types__WEBPACK_IMPORTED_MODULE_9__["Tab"].Template ? 18 : 5;
            break;

          case 5:
            items = [Object(_cdf_client__WEBPACK_IMPORTED_MODULE_4__["targetToIdEither"])(target)];
            return _context29.abrupt("break", 19);

          case 7:
            _context29.next = 9;
            return findAssetTimeseries(target, connector);

          case 9:
            timeseries = _context29.sent;
            items = timeseries.map(function (_ref23) {
              var id = _ref23.id;
              return {
                id: id
              };
            });
            return _context29.abrupt("break", 19);

          case 12:
            defaultInterval = Object(_utils__WEBPACK_IMPORTED_MODULE_10__["toGranularityWithLowerBound"])(intervalMs);
            _context29.next = 15;
            return Object(_parser_ts__WEBPACK_IMPORTED_MODULE_8__["formQueriesForExpression"])(expr, target, connector, defaultInterval);

          case 15:
            items = _context29.sent;
            return _context29.abrupt("break", 19);

          case 17:
            return _context29.abrupt("break", 19);

          case 18:
            return _context29.abrupt("break", 19);

          case 19:
            return _context29.abrupt("return", {
              type: type,
              items: items,
              target: target
            });

          case 20:
          case "end":
            return _context29.stop();
        }
      }
    }, _callee29);
  }));
}

function groupTargets(targets) {
  var _partition = Object(lodash__WEBPACK_IMPORTED_MODULE_3__["partition"])(targets, function (_ref24) {
    var tab = _ref24.tab;
    return tab === _types__WEBPACK_IMPORTED_MODULE_9__["Tab"].Event;
  }),
      _partition2 = _slicedToArray(_partition, 2),
      eventTargets = _partition2[0],
      tsTargets = _partition2[1];

  var _partition3 = Object(lodash__WEBPACK_IMPORTED_MODULE_3__["partition"])(targets, function (_ref25) {
    var tab = _ref25.tab;
    return tab === _types__WEBPACK_IMPORTED_MODULE_9__["Tab"].Extractor;
  }),
      _partition4 = _slicedToArray(_partition3, 1),
      extractorTargets = _partition4[0];

  return {
    eventTargets: eventTargets,
    tsTargets: tsTargets,
    extractorTargets: extractorTargets
  };
}

/***/ }),

/***/ "./module.ts":
/*!*******************!*\
  !*** ./module.ts ***!
  \*******************/
/*! exports provided: plugin */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "plugin", function() { return plugin; });
/* harmony import */ var _grafana_data__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @grafana/data */ "@grafana/data");
/* harmony import */ var _grafana_data__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_grafana_data__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _datasource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./datasource */ "./datasource.ts");
/* harmony import */ var _components_configEditor__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/configEditor */ "./components/configEditor.tsx");
/* harmony import */ var _components_queryEditor__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/queryEditor */ "./components/queryEditor.tsx");
/* harmony import */ var _annotationCtrl__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./annotationCtrl */ "./annotationCtrl.ts");
/* harmony import */ var _components_variableQueryEditor__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/variableQueryEditor */ "./components/variableQueryEditor.tsx");






var plugin = new _grafana_data__WEBPACK_IMPORTED_MODULE_0__["DataSourcePlugin"](_datasource__WEBPACK_IMPORTED_MODULE_1__["default"]).setConfigEditor(_components_configEditor__WEBPACK_IMPORTED_MODULE_2__["ConfigEditor"]).setVariableQueryEditor(_components_variableQueryEditor__WEBPACK_IMPORTED_MODULE_5__["CogniteVariableQueryEditor"]).setQueryEditor(_components_queryEditor__WEBPACK_IMPORTED_MODULE_3__["QueryEditor"]).setAnnotationQueryCtrl(_annotationCtrl__WEBPACK_IMPORTED_MODULE_4__["CogniteAnnotationsQueryCtrl"]);

/***/ }),

/***/ "./parser/events-assets/grammar.ts":
/*!*****************************************!*\
  !*** ./parser/events-assets/grammar.ts ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

// Generated automatically by nearley, version 2.19.7
// http://github.com/Hardmath123/nearley
// Bypasses TS6133. Allow declared but unused functions.
// @ts-ignore

/* eslint-disable */
function id(d) {
  return d[0];
}

var formatQuery = function formatQuery(_ref) {
  var _ref2 = _slicedToArray(_ref, 2),
      type = _ref2[0],
      query = _ref2[1];

  return {
    type: type,
    query: query
  };
};

var emptyObject = function emptyObject() {
  return {};
};

var emptyArray = function emptyArray() {
  return [];
};

var join = function join(_ref3) {
  var _ref4 = _slicedToArray(_ref3, 1),
      d = _ref4[0];

  return d.join('');
};

var extractPair = function extractPair(d) {
  return d.length > 2 ? _defineProperty({}, d[0] + d[1], {
    key: d[0],
    filter: d[1],
    value: d[2]
  }) : _defineProperty({}, d[0], d[1]);
};

var extractConditionToArray = function extractConditionToArray(d) {
  if (!d.length) return [];
  var output = [extractPair(d[2])];

  for (var i in d[4]) {
    output.push(extractPair(d[4][i][2]));
  }

  return output;
};

var extractObject = function extractObject(d) {
  var output = Object.assign({}, extractPair(d[2]));

  for (var i in d[4]) {
    output = Object.assign(Object.assign({}, output), extractPair(d[4][i][2]));
  }

  return output;
};

var extractArray = function extractArray(d) {
  var output = [d[2]];

  for (var i in d[4]) {
    output.push(d[4][i][2]);
  }

  return output;
};

var grammar = {
  Lexer: undefined,
  ParserRules: [{
    name: 'unsigned_int$ebnf$1',
    symbols: [/[0-9]/]
  }, {
    name: 'unsigned_int$ebnf$1',
    symbols: ['unsigned_int$ebnf$1', /[0-9]/],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'unsigned_int',
    symbols: ['unsigned_int$ebnf$1'],
    postprocess: function postprocess(d) {
      return parseInt(d[0].join(''));
    }
  }, {
    name: 'int$ebnf$1$subexpression$1',
    symbols: [{
      literal: '-'
    }]
  }, {
    name: 'int$ebnf$1$subexpression$1',
    symbols: [{
      literal: '+'
    }]
  }, {
    name: 'int$ebnf$1',
    symbols: ['int$ebnf$1$subexpression$1'],
    postprocess: id
  }, {
    name: 'int$ebnf$1',
    symbols: [],
    postprocess: function postprocess() {
      return null;
    }
  }, {
    name: 'int$ebnf$2',
    symbols: [/[0-9]/]
  }, {
    name: 'int$ebnf$2',
    symbols: ['int$ebnf$2', /[0-9]/],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'int',
    symbols: ['int$ebnf$1', 'int$ebnf$2'],
    postprocess: function postprocess(d) {
      if (d[0]) {
        return parseInt(d[0][0] + d[1].join(''));
      } else {
        return parseInt(d[1].join(''));
      }
    }
  }, {
    name: 'unsigned_decimal$ebnf$1',
    symbols: [/[0-9]/]
  }, {
    name: 'unsigned_decimal$ebnf$1',
    symbols: ['unsigned_decimal$ebnf$1', /[0-9]/],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'unsigned_decimal$ebnf$2$subexpression$1$ebnf$1',
    symbols: [/[0-9]/]
  }, {
    name: 'unsigned_decimal$ebnf$2$subexpression$1$ebnf$1',
    symbols: ['unsigned_decimal$ebnf$2$subexpression$1$ebnf$1', /[0-9]/],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'unsigned_decimal$ebnf$2$subexpression$1',
    symbols: [{
      literal: '.'
    }, 'unsigned_decimal$ebnf$2$subexpression$1$ebnf$1']
  }, {
    name: 'unsigned_decimal$ebnf$2',
    symbols: ['unsigned_decimal$ebnf$2$subexpression$1'],
    postprocess: id
  }, {
    name: 'unsigned_decimal$ebnf$2',
    symbols: [],
    postprocess: function postprocess() {
      return null;
    }
  }, {
    name: 'unsigned_decimal',
    symbols: ['unsigned_decimal$ebnf$1', 'unsigned_decimal$ebnf$2'],
    postprocess: function postprocess(d) {
      return parseFloat(d[0].join('') + (d[1] ? '.' + d[1][1].join('') : ''));
    }
  }, {
    name: 'decimal$ebnf$1',
    symbols: [{
      literal: '-'
    }],
    postprocess: id
  }, {
    name: 'decimal$ebnf$1',
    symbols: [],
    postprocess: function postprocess() {
      return null;
    }
  }, {
    name: 'decimal$ebnf$2',
    symbols: [/[0-9]/]
  }, {
    name: 'decimal$ebnf$2',
    symbols: ['decimal$ebnf$2', /[0-9]/],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'decimal$ebnf$3$subexpression$1$ebnf$1',
    symbols: [/[0-9]/]
  }, {
    name: 'decimal$ebnf$3$subexpression$1$ebnf$1',
    symbols: ['decimal$ebnf$3$subexpression$1$ebnf$1', /[0-9]/],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'decimal$ebnf$3$subexpression$1',
    symbols: [{
      literal: '.'
    }, 'decimal$ebnf$3$subexpression$1$ebnf$1']
  }, {
    name: 'decimal$ebnf$3',
    symbols: ['decimal$ebnf$3$subexpression$1'],
    postprocess: id
  }, {
    name: 'decimal$ebnf$3',
    symbols: [],
    postprocess: function postprocess() {
      return null;
    }
  }, {
    name: 'decimal',
    symbols: ['decimal$ebnf$1', 'decimal$ebnf$2', 'decimal$ebnf$3'],
    postprocess: function postprocess(d) {
      return parseFloat((d[0] || '') + d[1].join('') + (d[2] ? '.' + d[2][1].join('') : ''));
    }
  }, {
    name: 'percentage',
    symbols: ['decimal', {
      literal: '%'
    }],
    postprocess: function postprocess(d) {
      return d[0] / 100;
    }
  }, {
    name: 'jsonfloat$ebnf$1',
    symbols: [{
      literal: '-'
    }],
    postprocess: id
  }, {
    name: 'jsonfloat$ebnf$1',
    symbols: [],
    postprocess: function postprocess() {
      return null;
    }
  }, {
    name: 'jsonfloat$ebnf$2',
    symbols: [/[0-9]/]
  }, {
    name: 'jsonfloat$ebnf$2',
    symbols: ['jsonfloat$ebnf$2', /[0-9]/],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'jsonfloat$ebnf$3$subexpression$1$ebnf$1',
    symbols: [/[0-9]/]
  }, {
    name: 'jsonfloat$ebnf$3$subexpression$1$ebnf$1',
    symbols: ['jsonfloat$ebnf$3$subexpression$1$ebnf$1', /[0-9]/],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'jsonfloat$ebnf$3$subexpression$1',
    symbols: [{
      literal: '.'
    }, 'jsonfloat$ebnf$3$subexpression$1$ebnf$1']
  }, {
    name: 'jsonfloat$ebnf$3',
    symbols: ['jsonfloat$ebnf$3$subexpression$1'],
    postprocess: id
  }, {
    name: 'jsonfloat$ebnf$3',
    symbols: [],
    postprocess: function postprocess() {
      return null;
    }
  }, {
    name: 'jsonfloat$ebnf$4$subexpression$1$ebnf$1',
    symbols: [/[+-]/],
    postprocess: id
  }, {
    name: 'jsonfloat$ebnf$4$subexpression$1$ebnf$1',
    symbols: [],
    postprocess: function postprocess() {
      return null;
    }
  }, {
    name: 'jsonfloat$ebnf$4$subexpression$1$ebnf$2',
    symbols: [/[0-9]/]
  }, {
    name: 'jsonfloat$ebnf$4$subexpression$1$ebnf$2',
    symbols: ['jsonfloat$ebnf$4$subexpression$1$ebnf$2', /[0-9]/],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'jsonfloat$ebnf$4$subexpression$1',
    symbols: [/[eE]/, 'jsonfloat$ebnf$4$subexpression$1$ebnf$1', 'jsonfloat$ebnf$4$subexpression$1$ebnf$2']
  }, {
    name: 'jsonfloat$ebnf$4',
    symbols: ['jsonfloat$ebnf$4$subexpression$1'],
    postprocess: id
  }, {
    name: 'jsonfloat$ebnf$4',
    symbols: [],
    postprocess: function postprocess() {
      return null;
    }
  }, {
    name: 'jsonfloat',
    symbols: ['jsonfloat$ebnf$1', 'jsonfloat$ebnf$2', 'jsonfloat$ebnf$3', 'jsonfloat$ebnf$4'],
    postprocess: function postprocess(d) {
      return parseFloat((d[0] || '') + d[1].join('') + (d[2] ? '.' + d[2][1].join('') : '') + (d[3] ? 'e' + (d[3][1] || '+') + d[3][2].join('') : ''));
    }
  }, {
    name: 'regexp$string$1',
    symbols: [{
      literal: '='
    }, {
      literal: '~'
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'regexp',
    symbols: ['regexp$string$1'],
    postprocess: id
  }, {
    name: 'regexp$string$2',
    symbols: [{
      literal: '!'
    }, {
      literal: '~'
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'regexp',
    symbols: ['regexp$string$2'],
    postprocess: id
  }, {
    name: 'equals',
    symbols: [{
      literal: '='
    }],
    postprocess: id
  }, {
    name: 'not_equals$string$1',
    symbols: [{
      literal: '!'
    }, {
      literal: '='
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'not_equals',
    symbols: ['not_equals$string$1'],
    postprocess: id
  }, {
    name: 'prop_name$ebnf$1',
    symbols: [/[A-Za-z0-9_]/]
  }, {
    name: 'prop_name$ebnf$1',
    symbols: ['prop_name$ebnf$1', /[A-Za-z0-9_]/],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'prop_name',
    symbols: ['prop_name$ebnf$1'],
    postprocess: join
  }, {
    name: 'number',
    symbols: ['decimal'],
    postprocess: id
  }, {
    name: 'dqstring$ebnf$1',
    symbols: []
  }, {
    name: 'dqstring$ebnf$1',
    symbols: ['dqstring$ebnf$1', 'dstrchar'],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'dqstring',
    symbols: [{
      literal: '"'
    }, 'dqstring$ebnf$1', {
      literal: '"'
    }],
    postprocess: function postprocess(d) {
      return d[1].join('');
    }
  }, {
    name: 'sqstring$ebnf$1',
    symbols: []
  }, {
    name: 'sqstring$ebnf$1',
    symbols: ['sqstring$ebnf$1', 'sstrchar'],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'sqstring',
    symbols: [{
      literal: "'"
    }, 'sqstring$ebnf$1', {
      literal: "'"
    }],
    postprocess: function postprocess(d) {
      return d[1].join('');
    }
  }, {
    name: 'dqregexp$ebnf$1',
    symbols: []
  }, {
    name: 'dqregexp$ebnf$1',
    symbols: ['dqregexp$ebnf$1', 'ndstrchar'],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'dqregexp',
    symbols: [{
      literal: '"'
    }, 'dqregexp$ebnf$1', {
      literal: '"'
    }],
    postprocess: function postprocess(d) {
      return d[1].join('');
    }
  }, {
    name: 'sqregexp$ebnf$1',
    symbols: []
  }, {
    name: 'sqregexp$ebnf$1',
    symbols: ['sqregexp$ebnf$1', 'nsstrchar'],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'sqregexp',
    symbols: [{
      literal: "'"
    }, 'sqregexp$ebnf$1', {
      literal: "'"
    }],
    postprocess: function postprocess(d) {
      return d[1].join('');
    }
  }, {
    name: 'dstrchar',
    symbols: [/[^\\"\n]/],
    postprocess: id
  }, {
    name: 'dstrchar',
    symbols: ['backslash', 'strescape'],
    postprocess: function postprocess(d) {
      return JSON.parse('"' + d.join('') + '"');
    }
  }, {
    name: 'dstrchar$string$1',
    symbols: [{
      literal: '\\'
    }, {
      literal: '"'
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'dstrchar',
    symbols: ['dstrchar$string$1'],
    postprocess: function postprocess(d) {
      return '"';
    }
  }, {
    name: 'sstrchar',
    symbols: [/[^\\'\n]/],
    postprocess: id
  }, {
    name: 'sstrchar',
    symbols: ['backslash', 'strescape'],
    postprocess: function postprocess(d) {
      return JSON.parse('"' + d.join('') + '"');
    }
  }, {
    name: 'sstrchar$string$1',
    symbols: [{
      literal: '\\'
    }, {
      literal: "'"
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'sstrchar',
    symbols: ['sstrchar$string$1'],
    postprocess: function postprocess(d) {
      return "'";
    }
  }, {
    name: 'ndstrchar',
    symbols: [/[^\\"\n]/],
    postprocess: id
  }, {
    name: 'ndstrchar',
    symbols: ['backslash', 'unicode'],
    postprocess: function postprocess(d) {
      return JSON.parse('"' + d.join('') + '"');
    }
  }, {
    name: 'ndstrchar$string$1',
    symbols: [{
      literal: '\\'
    }, {
      literal: '"'
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'ndstrchar',
    symbols: ['ndstrchar$string$1'],
    postprocess: function postprocess(d) {
      return '\\"';
    }
  }, {
    name: 'ndstrchar',
    symbols: ['backslash'],
    postprocess: id
  }, {
    name: 'nsstrchar',
    symbols: [/[^\\'\n]/],
    postprocess: id
  }, {
    name: 'nsstrchar',
    symbols: ['backslash', 'unicode'],
    postprocess: function postprocess(d) {
      return JSON.parse('"' + d.join('') + '"');
    }
  }, {
    name: 'nsstrchar$string$1',
    symbols: [{
      literal: '\\'
    }, {
      literal: "'"
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'nsstrchar',
    symbols: ['nsstrchar$string$1'],
    postprocess: function postprocess(d) {
      return "\\'";
    }
  }, {
    name: 'nsstrchar',
    symbols: ['backslash'],
    postprocess: id
  }, {
    name: 'strescape',
    symbols: [/["\\/bfnrt]/],
    postprocess: id
  }, {
    name: 'strescape',
    symbols: ['unicode'],
    postprocess: id
  }, {
    name: 'backslash',
    symbols: [{
      literal: '\\'
    }],
    postprocess: function postprocess(d) {
      return '\\';
    }
  }, {
    name: 'unicode',
    symbols: [{
      literal: 'u'
    }, /[a-fA-F0-9]/, /[a-fA-F0-9]/, /[a-fA-F0-9]/, /[a-fA-F0-9]/],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: '_$ebnf$1',
    symbols: []
  }, {
    name: '_$ebnf$1',
    symbols: ['_$ebnf$1', /[\s]/],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: '_',
    symbols: ['_$ebnf$1'],
    postprocess: null
  }, {
    name: 'value',
    symbols: ['object'],
    postprocess: id
  }, {
    name: 'value',
    symbols: ['array'],
    postprocess: id
  }, {
    name: 'value',
    symbols: ['primitive'],
    postprocess: id
  }, {
    name: 'primitive',
    symbols: ['number'],
    postprocess: id
  }, {
    name: 'primitive',
    symbols: ['string'],
    postprocess: id
  }, {
    name: 'primitive$string$1',
    symbols: [{
      literal: 't'
    }, {
      literal: 'r'
    }, {
      literal: 'u'
    }, {
      literal: 'e'
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'primitive',
    symbols: ['primitive$string$1'],
    postprocess: function postprocess() {
      return true;
    }
  }, {
    name: 'primitive$string$2',
    symbols: [{
      literal: 'f'
    }, {
      literal: 'a'
    }, {
      literal: 'l'
    }, {
      literal: 's'
    }, {
      literal: 'e'
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'primitive',
    symbols: ['primitive$string$2'],
    postprocess: function postprocess() {
      return false;
    }
  }, {
    name: 'primitive$string$3',
    symbols: [{
      literal: 'n'
    }, {
      literal: 'u'
    }, {
      literal: 'l'
    }, {
      literal: 'l'
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'primitive',
    symbols: ['primitive$string$3'],
    postprocess: function postprocess() {
      return null;
    }
  }, {
    name: 'rule',
    symbols: ['type', 'condition'],
    postprocess: formatQuery
  }, {
    name: 'type$string$1',
    symbols: [{
      literal: 'a'
    }, {
      literal: 's'
    }, {
      literal: 's'
    }, {
      literal: 'e'
    }, {
      literal: 't'
    }, {
      literal: 's'
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'type',
    symbols: ['type$string$1'],
    postprocess: id
  }, {
    name: 'type$string$2',
    symbols: [{
      literal: 'e'
    }, {
      literal: 'v'
    }, {
      literal: 'e'
    }, {
      literal: 'n'
    }, {
      literal: 't'
    }, {
      literal: 's'
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'type',
    symbols: ['type$string$2'],
    postprocess: id
  }, {
    name: 'condition',
    symbols: [{
      literal: '{'
    }, {
      literal: '}'
    }],
    postprocess: emptyArray
  }, {
    name: 'condition$ebnf$1',
    symbols: []
  }, {
    name: 'condition$ebnf$1$subexpression$1',
    symbols: [{
      literal: ','
    }, '_', 'pair', '_']
  }, {
    name: 'condition$ebnf$1',
    symbols: ['condition$ebnf$1', 'condition$ebnf$1$subexpression$1'],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'condition',
    symbols: [{
      literal: '{'
    }, '_', 'pair', '_', 'condition$ebnf$1', '_', {
      literal: '}'
    }],
    postprocess: extractConditionToArray
  }, {
    name: 'regexp_string',
    symbols: ['sqregexp'],
    postprocess: id
  }, {
    name: 'regexp_string',
    symbols: ['dqregexp'],
    postprocess: id
  }, {
    name: 'string',
    symbols: ['sqstring'],
    postprocess: id
  }, {
    name: 'string',
    symbols: ['dqstring'],
    postprocess: id
  }, {
    name: 'array',
    symbols: [{
      literal: '['
    }, '_', {
      literal: ']'
    }],
    postprocess: emptyArray
  }, {
    name: 'array$ebnf$1',
    symbols: []
  }, {
    name: 'array$ebnf$1$subexpression$1',
    symbols: [{
      literal: ','
    }, '_', 'value', '_']
  }, {
    name: 'array$ebnf$1',
    symbols: ['array$ebnf$1', 'array$ebnf$1$subexpression$1'],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'array',
    symbols: [{
      literal: '['
    }, '_', 'value', '_', 'array$ebnf$1', '_', {
      literal: ']'
    }],
    postprocess: extractArray
  }, {
    name: 'object',
    symbols: [{
      literal: '{'
    }, '_', {
      literal: '}'
    }],
    postprocess: emptyObject
  }, {
    name: 'object$ebnf$1',
    symbols: []
  }, {
    name: 'object$ebnf$1$subexpression$1',
    symbols: [{
      literal: ','
    }, '_', 'pair', '_']
  }, {
    name: 'object$ebnf$1',
    symbols: ['object$ebnf$1', 'object$ebnf$1$subexpression$1'],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'object',
    symbols: [{
      literal: '{'
    }, '_', 'pair', '_', 'object$ebnf$1', '_', {
      literal: '}'
    }],
    postprocess: extractObject
  }, {
    name: 'pair',
    symbols: ['prop_name', '_', 'equals', '_', 'value'],
    postprocess: function postprocess(d) {
      return [d[0], d[4]];
    }
  }, {
    name: 'pair',
    symbols: ['prop_name', '_', 'regexp', '_', 'regexp_string'],
    postprocess: function postprocess(d) {
      return [d[0], d[2], d[4]];
    }
  }, {
    name: 'pair',
    symbols: ['prop_name', '_', 'not_equals', '_', 'primitive'],
    postprocess: function postprocess(d) {
      return [d[0], d[2], d[4]];
    }
  }],
  ParserStart: 'rule'
};
/* harmony default export */ __webpack_exports__["default"] = (grammar);

/***/ }),

/***/ "./parser/events-assets/index.ts":
/*!***************************************!*\
  !*** ./parser/events-assets/index.ts ***!
  \***************************************/
/*! exports provided: parse, formatQueryParse, parseQuery, parseWith */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "parse", function() { return parse; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "formatQueryParse", function() { return formatQueryParse; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "parseQuery", function() { return parseQuery; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "parseWith", function() { return parseWith; });
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash */ "lodash");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var deepdash_getFilterDeep__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! deepdash/getFilterDeep */ "../node_modules/deepdash/getFilterDeep.js");
/* harmony import */ var deepdash_getFilterDeep__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(deepdash_getFilterDeep__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var deepdash_getPaths__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! deepdash/getPaths */ "../node_modules/deepdash/getPaths.js");
/* harmony import */ var deepdash_getPaths__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(deepdash_getPaths__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var deepdash_getOmitDeep__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! deepdash/getOmitDeep */ "../node_modules/deepdash/getOmitDeep.js");
/* harmony import */ var deepdash_getOmitDeep__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(deepdash_getOmitDeep__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var nearley__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! nearley */ "../node_modules/nearley/lib/nearley.js");
/* harmony import */ var nearley__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(nearley__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _grammar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./grammar */ "./parser/events-assets/grammar.ts");
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }







var compiledGrammar = nearley__WEBPACK_IMPORTED_MODULE_4__["Grammar"].fromCompiled(_grammar__WEBPACK_IMPORTED_MODULE_5__["default"]);
var filterDeep = deepdash_getFilterDeep__WEBPACK_IMPORTED_MODULE_1___default()(lodash__WEBPACK_IMPORTED_MODULE_0___default.a);
var paths = deepdash_getPaths__WEBPACK_IMPORTED_MODULE_2___default()(lodash__WEBPACK_IMPORTED_MODULE_0___default.a);
var omitDeep = deepdash_getOmitDeep__WEBPACK_IMPORTED_MODULE_3___default()(lodash__WEBPACK_IMPORTED_MODULE_0___default.a);

var parseWith = function parseWith(parser, query) {
  var trimmedQuery = query.trim();
  var result;

  try {
    parser.feed(trimmedQuery);

    var _parser$finish = parser.finish();

    var _parser$finish2 = _slicedToArray(_parser$finish, 1);

    result = _parser$finish2[0];
  } catch (e) {
    var message = formatErrorMessage(e, trimmedQuery);
    throw new Error(message);
  }

  if (!result) {
    var _message = formatErrorMessage({
      offset: trimmedQuery.length
    }, trimmedQuery, 'Parser: Unexpected end of input');

    throw new Error(_message);
  }

  return result;
};

var parseQuery = function parseQuery(query) {
  return parseWith(new nearley__WEBPACK_IMPORTED_MODULE_4__["Parser"](compiledGrammar), query);
};

var formatErrorMessage = function formatErrorMessage(_ref, query) {
  var offset = _ref.offset;
  var title = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 'Parser: Syntax error';
  var pointer = Number.isInteger(offset) ? offset + 1 : query.length;
  var message = "".concat(query, "\n").concat(Array(pointer).join(' '), "^");
  return "".concat(title, ":\n").concat(message);
};

var formatQueryParse = function formatQueryParse(_ref2) {
  var type = _ref2.type,
      query = _ref2.query;
  var extractedFilters = filterDeep(query, function (objValue, objKey, _ref3) {
    var value = _ref3.value,
        filter = _ref3.filter;
    return !Object(lodash__WEBPACK_IMPORTED_MODULE_0__["isUndefined"])(value) && filter;
  });
  var filtered = extractedFilters ? extractedFilters.reduce(function (acc, c) {
    return Object.assign(Object.assign({}, acc), c);
  }, {}) : {};
  var emptyFilters = omitDeep(filtered, ['filter', 'value', 'key']);
  var filters = paths(emptyFilters, {
    pathFormat: 'array'
  }).map(function (path) {
    var currentPath = path.join('.');
    var parentPath = path.slice(0, -1);

    var _get = Object(lodash__WEBPACK_IMPORTED_MODULE_0__["get"])(filtered, currentPath),
        filter = _get.filter,
        key = _get.key,
        value = _get.value;

    parentPath.push(key);
    return {
      filter: filter,
      value: value,
      path: parentPath.join('.')
    };
  });
  var extractedParams = filterDeep(query, function (reg, key, _ref4) {
    var value = _ref4.value,
        filter = _ref4.filter;
    return !(!Object(lodash__WEBPACK_IMPORTED_MODULE_0__["isUndefined"])(value) && filter);
  });
  var params = extractedParams ? extractedParams.reduce(function (acc, c) {
    return Object.assign(Object.assign({}, acc), c);
  }, {}) : {};
  return {
    type: type,
    params: params,
    filters: filters
  };
};

var parse = function parse(query) {
  var result = parseQuery(query);
  return formatQueryParse(result);
};



/***/ }),

/***/ "./parser/ts/grammar.ts":
/*!******************************!*\
  !*** ./parser/ts/grammar.ts ***!
  \******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

// Generated automatically by nearley, version 2.19.7
// http://github.com/Hardmath123/nearley
// Bypasses TS6133. Allow declared but unused functions.
// @ts-ignore

/* eslint-disable */
function id(d) {
  return d[0];
}

var formatQuery = function formatQuery(_ref) {
  var _ref2 = _slicedToArray(_ref, 2),
      type = _ref2[0],
      query = _ref2[1];

  return {
    type: type,
    query: query
  };
};

var emptyObject = function emptyObject() {
  return {};
};

var emptyArray = function emptyArray() {
  return [];
};

var join = function join(_ref3) {
  var _ref4 = _slicedToArray(_ref3, 1),
      d = _ref4[0];

  return joinArr(d);
};

var joinArr = function joinArr(d) {
  return d.join('');
};

var extractPair = function extractPair(d) {
  return {
    path: d[0],
    filter: d[1],
    value: d[2]
  };
};

var extractConditionPair = function extractConditionPair(_ref5) {
  var _ref6 = _slicedToArray(_ref5, 3),
      path = _ref6[0],
      filter = _ref6[1],
      value = _ref6[2];

  return path ? {
    path: path,
    filter: filter,
    value: value
  } : {};
};

var extract = function extract(extractor, d) {
  var output = Object.assign({}, extractor(d[1]));

  for (var i in d[2]) {
    output = Object.assign(Object.assign({}, output), extractor(d[2][i][2]));
  }

  return output;
};

var extractConditionToArray = function extractConditionToArray(d) {
  if (!d.length) return [];
  var output = [extractPair(d[1])];

  for (var i in d[2]) {
    output.push(extractPair(d[2][i][1]));
  }

  return output;
};

var extractObject = function extractObject(d) {
  var output = [extractPair(d[1])];

  for (var i in d[2]) {
    output.push(extractPair(d[2][i][1]));
  }

  return output;
};

var extractArray = function extractArray(d) {
  var output = [d[1]];

  for (var i in d[2]) {
    output.push(d[2][i][1]);
  }

  return output;
};

var extractOperationsArray = function extractOperationsArray(d) {
  var output = Array.isArray(d[0]) ? _toConsumableArray(d[0]) : [d[0]];

  for (var i in d[1]) {
    var _ref7;

    var flatten = (_ref7 = []).concat.apply(_ref7, _toConsumableArray(d[1][i]));

    output.push.apply(output, _toConsumableArray(flatten));
  }

  return output;
};

var extractCommaSeparatedArray = function extractCommaSeparatedArray(d) {
  var output = [d[0]];

  for (var i in d[1]) {
    output.push(d[1][i][1]);
  }

  return output;
};

var extractMapFuncArgs = function extractMapFuncArgs(d) {
  return d.filter(function (d) {
    return d !== ',';
  });
};

var extract2Elements = function extract2Elements(d) {
  return [d[0], d[2]];
};

var extractOperator = function extractOperator(_ref8) {
  var _ref9 = _slicedToArray(_ref8, 3),
      s = _ref9[0],
      operator = _ref9[1],
      S = _ref9[2];

  return {
    operator: operator
  };
};

var extractNumber = function extractNumber(_ref10) {
  var _ref11 = _slicedToArray(_ref10, 1),
      constant = _ref11[0];

  return {
    constant: constant
  };
};

var extractPI = function extractPI(d) {
  return {
    constant: d[0] + d[2]
  };
};

var extractFunction = function extractFunction(_ref12) {
  var _ref13 = _slicedToArray(_ref12, 4),
      func = _ref13[0],
      br = _ref13[1],
      args = _ref13[2],
      BR = _ref13[3];

  if (args && args.length) {
    return {
      func: func || '',
      args: args
    };
  }

  return {
    func: func
  };
};

var extractUnaryOperator = function extractUnaryOperator(_ref14) {
  var _ref15 = _slicedToArray(_ref14, 2),
      operator = _ref15[0],
      element = _ref15[1];

  return operator ? [operator[0], element] : element;
};

var grammar = {
  Lexer: undefined,
  ParserRules: [{
    name: 'unsigned_int$ebnf$1',
    symbols: [/[0-9]/]
  }, {
    name: 'unsigned_int$ebnf$1',
    symbols: ['unsigned_int$ebnf$1', /[0-9]/],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'unsigned_int',
    symbols: ['unsigned_int$ebnf$1'],
    postprocess: function postprocess(d) {
      return parseInt(d[0].join(''));
    }
  }, {
    name: 'int$ebnf$1$subexpression$1',
    symbols: [{
      literal: '-'
    }]
  }, {
    name: 'int$ebnf$1$subexpression$1',
    symbols: [{
      literal: '+'
    }]
  }, {
    name: 'int$ebnf$1',
    symbols: ['int$ebnf$1$subexpression$1'],
    postprocess: id
  }, {
    name: 'int$ebnf$1',
    symbols: [],
    postprocess: function postprocess() {
      return null;
    }
  }, {
    name: 'int$ebnf$2',
    symbols: [/[0-9]/]
  }, {
    name: 'int$ebnf$2',
    symbols: ['int$ebnf$2', /[0-9]/],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'int',
    symbols: ['int$ebnf$1', 'int$ebnf$2'],
    postprocess: function postprocess(d) {
      if (d[0]) {
        return parseInt(d[0][0] + d[1].join(''));
      } else {
        return parseInt(d[1].join(''));
      }
    }
  }, {
    name: 'unsigned_decimal$ebnf$1',
    symbols: [/[0-9]/]
  }, {
    name: 'unsigned_decimal$ebnf$1',
    symbols: ['unsigned_decimal$ebnf$1', /[0-9]/],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'unsigned_decimal$ebnf$2$subexpression$1$ebnf$1',
    symbols: [/[0-9]/]
  }, {
    name: 'unsigned_decimal$ebnf$2$subexpression$1$ebnf$1',
    symbols: ['unsigned_decimal$ebnf$2$subexpression$1$ebnf$1', /[0-9]/],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'unsigned_decimal$ebnf$2$subexpression$1',
    symbols: [{
      literal: '.'
    }, 'unsigned_decimal$ebnf$2$subexpression$1$ebnf$1']
  }, {
    name: 'unsigned_decimal$ebnf$2',
    symbols: ['unsigned_decimal$ebnf$2$subexpression$1'],
    postprocess: id
  }, {
    name: 'unsigned_decimal$ebnf$2',
    symbols: [],
    postprocess: function postprocess() {
      return null;
    }
  }, {
    name: 'unsigned_decimal',
    symbols: ['unsigned_decimal$ebnf$1', 'unsigned_decimal$ebnf$2'],
    postprocess: function postprocess(d) {
      return parseFloat(d[0].join('') + (d[1] ? '.' + d[1][1].join('') : ''));
    }
  }, {
    name: 'decimal$ebnf$1',
    symbols: [{
      literal: '-'
    }],
    postprocess: id
  }, {
    name: 'decimal$ebnf$1',
    symbols: [],
    postprocess: function postprocess() {
      return null;
    }
  }, {
    name: 'decimal$ebnf$2',
    symbols: [/[0-9]/]
  }, {
    name: 'decimal$ebnf$2',
    symbols: ['decimal$ebnf$2', /[0-9]/],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'decimal$ebnf$3$subexpression$1$ebnf$1',
    symbols: [/[0-9]/]
  }, {
    name: 'decimal$ebnf$3$subexpression$1$ebnf$1',
    symbols: ['decimal$ebnf$3$subexpression$1$ebnf$1', /[0-9]/],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'decimal$ebnf$3$subexpression$1',
    symbols: [{
      literal: '.'
    }, 'decimal$ebnf$3$subexpression$1$ebnf$1']
  }, {
    name: 'decimal$ebnf$3',
    symbols: ['decimal$ebnf$3$subexpression$1'],
    postprocess: id
  }, {
    name: 'decimal$ebnf$3',
    symbols: [],
    postprocess: function postprocess() {
      return null;
    }
  }, {
    name: 'decimal',
    symbols: ['decimal$ebnf$1', 'decimal$ebnf$2', 'decimal$ebnf$3'],
    postprocess: function postprocess(d) {
      return parseFloat((d[0] || '') + d[1].join('') + (d[2] ? '.' + d[2][1].join('') : ''));
    }
  }, {
    name: 'percentage',
    symbols: ['decimal', {
      literal: '%'
    }],
    postprocess: function postprocess(d) {
      return d[0] / 100;
    }
  }, {
    name: 'jsonfloat$ebnf$1',
    symbols: [{
      literal: '-'
    }],
    postprocess: id
  }, {
    name: 'jsonfloat$ebnf$1',
    symbols: [],
    postprocess: function postprocess() {
      return null;
    }
  }, {
    name: 'jsonfloat$ebnf$2',
    symbols: [/[0-9]/]
  }, {
    name: 'jsonfloat$ebnf$2',
    symbols: ['jsonfloat$ebnf$2', /[0-9]/],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'jsonfloat$ebnf$3$subexpression$1$ebnf$1',
    symbols: [/[0-9]/]
  }, {
    name: 'jsonfloat$ebnf$3$subexpression$1$ebnf$1',
    symbols: ['jsonfloat$ebnf$3$subexpression$1$ebnf$1', /[0-9]/],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'jsonfloat$ebnf$3$subexpression$1',
    symbols: [{
      literal: '.'
    }, 'jsonfloat$ebnf$3$subexpression$1$ebnf$1']
  }, {
    name: 'jsonfloat$ebnf$3',
    symbols: ['jsonfloat$ebnf$3$subexpression$1'],
    postprocess: id
  }, {
    name: 'jsonfloat$ebnf$3',
    symbols: [],
    postprocess: function postprocess() {
      return null;
    }
  }, {
    name: 'jsonfloat$ebnf$4$subexpression$1$ebnf$1',
    symbols: [/[+-]/],
    postprocess: id
  }, {
    name: 'jsonfloat$ebnf$4$subexpression$1$ebnf$1',
    symbols: [],
    postprocess: function postprocess() {
      return null;
    }
  }, {
    name: 'jsonfloat$ebnf$4$subexpression$1$ebnf$2',
    symbols: [/[0-9]/]
  }, {
    name: 'jsonfloat$ebnf$4$subexpression$1$ebnf$2',
    symbols: ['jsonfloat$ebnf$4$subexpression$1$ebnf$2', /[0-9]/],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'jsonfloat$ebnf$4$subexpression$1',
    symbols: [/[eE]/, 'jsonfloat$ebnf$4$subexpression$1$ebnf$1', 'jsonfloat$ebnf$4$subexpression$1$ebnf$2']
  }, {
    name: 'jsonfloat$ebnf$4',
    symbols: ['jsonfloat$ebnf$4$subexpression$1'],
    postprocess: id
  }, {
    name: 'jsonfloat$ebnf$4',
    symbols: [],
    postprocess: function postprocess() {
      return null;
    }
  }, {
    name: 'jsonfloat',
    symbols: ['jsonfloat$ebnf$1', 'jsonfloat$ebnf$2', 'jsonfloat$ebnf$3', 'jsonfloat$ebnf$4'],
    postprocess: function postprocess(d) {
      return parseFloat((d[0] || '') + d[1].join('') + (d[2] ? '.' + d[2][1].join('') : '') + (d[3] ? 'e' + (d[3][1] || '+') + d[3][2].join('') : ''));
    }
  }, {
    name: 'regexp$string$1',
    symbols: [{
      literal: '='
    }, {
      literal: '~'
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'regexp',
    symbols: ['regexp$string$1'],
    postprocess: id
  }, {
    name: 'regexp$string$2',
    symbols: [{
      literal: '!'
    }, {
      literal: '~'
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'regexp',
    symbols: ['regexp$string$2'],
    postprocess: id
  }, {
    name: 'equals',
    symbols: [{
      literal: '='
    }],
    postprocess: id
  }, {
    name: 'not_equals$string$1',
    symbols: [{
      literal: '!'
    }, {
      literal: '='
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'not_equals',
    symbols: ['not_equals$string$1'],
    postprocess: id
  }, {
    name: 'prop_name$ebnf$1',
    symbols: [/[A-Za-z0-9_]/]
  }, {
    name: 'prop_name$ebnf$1',
    symbols: ['prop_name$ebnf$1', /[A-Za-z0-9_]/],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'prop_name',
    symbols: ['prop_name$ebnf$1'],
    postprocess: join
  }, {
    name: 'number',
    symbols: ['decimal'],
    postprocess: id
  }, {
    name: 'dqstring$ebnf$1',
    symbols: []
  }, {
    name: 'dqstring$ebnf$1',
    symbols: ['dqstring$ebnf$1', 'dstrchar'],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'dqstring',
    symbols: [{
      literal: '"'
    }, 'dqstring$ebnf$1', {
      literal: '"'
    }],
    postprocess: function postprocess(d) {
      return d[1].join('');
    }
  }, {
    name: 'sqstring$ebnf$1',
    symbols: []
  }, {
    name: 'sqstring$ebnf$1',
    symbols: ['sqstring$ebnf$1', 'sstrchar'],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'sqstring',
    symbols: [{
      literal: "'"
    }, 'sqstring$ebnf$1', {
      literal: "'"
    }],
    postprocess: function postprocess(d) {
      return d[1].join('');
    }
  }, {
    name: 'dqregexp$ebnf$1',
    symbols: []
  }, {
    name: 'dqregexp$ebnf$1',
    symbols: ['dqregexp$ebnf$1', 'ndstrchar'],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'dqregexp',
    symbols: [{
      literal: '"'
    }, 'dqregexp$ebnf$1', {
      literal: '"'
    }],
    postprocess: function postprocess(d) {
      return d[1].join('');
    }
  }, {
    name: 'sqregexp$ebnf$1',
    symbols: []
  }, {
    name: 'sqregexp$ebnf$1',
    symbols: ['sqregexp$ebnf$1', 'nsstrchar'],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'sqregexp',
    symbols: [{
      literal: "'"
    }, 'sqregexp$ebnf$1', {
      literal: "'"
    }],
    postprocess: function postprocess(d) {
      return d[1].join('');
    }
  }, {
    name: 'dstrchar',
    symbols: [/[^\\"\n]/],
    postprocess: id
  }, {
    name: 'dstrchar',
    symbols: ['backslash', 'strescape'],
    postprocess: function postprocess(d) {
      return JSON.parse('"' + d.join('') + '"');
    }
  }, {
    name: 'dstrchar$string$1',
    symbols: [{
      literal: '\\'
    }, {
      literal: '"'
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'dstrchar',
    symbols: ['dstrchar$string$1'],
    postprocess: function postprocess(d) {
      return '"';
    }
  }, {
    name: 'sstrchar',
    symbols: [/[^\\'\n]/],
    postprocess: id
  }, {
    name: 'sstrchar',
    symbols: ['backslash', 'strescape'],
    postprocess: function postprocess(d) {
      return JSON.parse('"' + d.join('') + '"');
    }
  }, {
    name: 'sstrchar$string$1',
    symbols: [{
      literal: '\\'
    }, {
      literal: "'"
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'sstrchar',
    symbols: ['sstrchar$string$1'],
    postprocess: function postprocess(d) {
      return "'";
    }
  }, {
    name: 'ndstrchar',
    symbols: [/[^\\"\n]/],
    postprocess: id
  }, {
    name: 'ndstrchar',
    symbols: ['backslash', 'unicode'],
    postprocess: function postprocess(d) {
      return JSON.parse('"' + d.join('') + '"');
    }
  }, {
    name: 'ndstrchar$string$1',
    symbols: [{
      literal: '\\'
    }, {
      literal: '"'
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'ndstrchar',
    symbols: ['ndstrchar$string$1'],
    postprocess: function postprocess(d) {
      return '\\"';
    }
  }, {
    name: 'ndstrchar',
    symbols: ['backslash'],
    postprocess: id
  }, {
    name: 'nsstrchar',
    symbols: [/[^\\'\n]/],
    postprocess: id
  }, {
    name: 'nsstrchar',
    symbols: ['backslash', 'unicode'],
    postprocess: function postprocess(d) {
      return JSON.parse('"' + d.join('') + '"');
    }
  }, {
    name: 'nsstrchar$string$1',
    symbols: [{
      literal: '\\'
    }, {
      literal: "'"
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'nsstrchar',
    symbols: ['nsstrchar$string$1'],
    postprocess: function postprocess(d) {
      return "\\'";
    }
  }, {
    name: 'nsstrchar',
    symbols: ['backslash'],
    postprocess: id
  }, {
    name: 'strescape',
    symbols: [/["\\/bfnrt]/],
    postprocess: id
  }, {
    name: 'strescape',
    symbols: ['unicode'],
    postprocess: id
  }, {
    name: 'backslash',
    symbols: [{
      literal: '\\'
    }],
    postprocess: function postprocess(d) {
      return '\\';
    }
  }, {
    name: 'unicode',
    symbols: [{
      literal: 'u'
    }, /[a-fA-F0-9]/, /[a-fA-F0-9]/, /[a-fA-F0-9]/, /[a-fA-F0-9]/],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: '_$ebnf$1',
    symbols: []
  }, {
    name: '_$ebnf$1',
    symbols: ['_$ebnf$1', /[\s]/],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: '_',
    symbols: ['_$ebnf$1'],
    postprocess: null
  }, {
    name: 'value',
    symbols: ['object'],
    postprocess: id
  }, {
    name: 'value',
    symbols: ['array'],
    postprocess: id
  }, {
    name: 'value',
    symbols: ['primitive'],
    postprocess: id
  }, {
    name: 'primitive',
    symbols: ['number'],
    postprocess: id
  }, {
    name: 'primitive',
    symbols: ['string'],
    postprocess: id
  }, {
    name: 'primitive$string$1',
    symbols: [{
      literal: 't'
    }, {
      literal: 'r'
    }, {
      literal: 'u'
    }, {
      literal: 'e'
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'primitive',
    symbols: ['primitive$string$1'],
    postprocess: function postprocess() {
      return true;
    }
  }, {
    name: 'primitive$string$2',
    symbols: [{
      literal: 'f'
    }, {
      literal: 'a'
    }, {
      literal: 'l'
    }, {
      literal: 's'
    }, {
      literal: 'e'
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'primitive',
    symbols: ['primitive$string$2'],
    postprocess: function postprocess() {
      return false;
    }
  }, {
    name: 'primitive$string$3',
    symbols: [{
      literal: 'n'
    }, {
      literal: 'u'
    }, {
      literal: 'l'
    }, {
      literal: 'l'
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'primitive',
    symbols: ['primitive$string$3'],
    postprocess: function postprocess() {
      return null;
    }
  }, {
    name: 'query',
    symbols: ['_', 'trimmed', '_'],
    postprocess: function postprocess(d) {
      return d[1];
    }
  }, {
    name: 'trimmed',
    symbols: ['compositeElement'],
    postprocess: id
  }, {
    name: 'trimmed',
    symbols: ['function'],
    postprocess: id
  }, {
    name: 'function',
    symbols: ['unary', 'br', 'arithmeticElements', 'BR'],
    postprocess: extractFunction
  }, {
    name: 'function',
    symbols: ['unary', 'br', 'oneElement', 'BR'],
    postprocess: extractFunction
  }, {
    name: 'function',
    symbols: ['binary', 'br', 'twoElements', 'BR'],
    postprocess: extractFunction
  }, {
    name: 'function',
    symbols: ['n_ary', 'br', 'commaSeparatedElements', 'BR'],
    postprocess: extractFunction
  }, {
    name: 'function$string$1',
    symbols: [{
      literal: 'm'
    }, {
      literal: 'a'
    }, {
      literal: 'p'
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'function',
    symbols: ['function$string$1', 'br', 'map_func_args', 'BR'],
    postprocess: extractFunction
  }, {
    name: 'oneElement',
    symbols: ['arithmeticElement'],
    postprocess: function postprocess(_ref16) {
      var _ref17 = _slicedToArray(_ref16, 1),
          d = _ref17[0];

      return Array.isArray(d) ? d : [d];
    }
  }, {
    name: 'twoElements',
    symbols: ['compositeElement', 'comma', 'compositeElement'],
    postprocess: extract2Elements
  }, {
    name: 'commaSeparatedElements$ebnf$1',
    symbols: []
  }, {
    name: 'commaSeparatedElements$ebnf$1$subexpression$1',
    symbols: ['comma', 'compositeElement']
  }, {
    name: 'commaSeparatedElements$ebnf$1',
    symbols: ['commaSeparatedElements$ebnf$1', 'commaSeparatedElements$ebnf$1$subexpression$1'],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'commaSeparatedElements',
    symbols: ['compositeElement', 'commaSeparatedElements$ebnf$1'],
    postprocess: extractCommaSeparatedArray
  }, {
    name: 'arithmeticElements$ebnf$1$subexpression$1',
    symbols: ['operator', 'arithmeticElement']
  }, {
    name: 'arithmeticElements$ebnf$1',
    symbols: ['arithmeticElements$ebnf$1$subexpression$1']
  }, {
    name: 'arithmeticElements$ebnf$1$subexpression$2',
    symbols: ['operator', 'arithmeticElement']
  }, {
    name: 'arithmeticElements$ebnf$1',
    symbols: ['arithmeticElements$ebnf$1', 'arithmeticElements$ebnf$1$subexpression$2'],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'arithmeticElements',
    symbols: ['arithmeticElement', 'arithmeticElements$ebnf$1'],
    postprocess: extractOperationsArray
  }, {
    name: 'map_func_args',
    symbols: ['compositeElement', {
      literal: ','
    }, 'array', {
      literal: ','
    }, 'array', 'comma', 'number'],
    postprocess: extractMapFuncArgs
  }, {
    name: 'compositeElement',
    symbols: ['arithmeticElement'],
    postprocess: id
  }, {
    name: 'compositeElement',
    symbols: ['arithmeticElements'],
    postprocess: id
  }, {
    name: 'arithmeticElement$ebnf$1$subexpression$1',
    symbols: ['unary_operator']
  }, {
    name: 'arithmeticElement$ebnf$1',
    symbols: ['arithmeticElement$ebnf$1$subexpression$1'],
    postprocess: id
  }, {
    name: 'arithmeticElement$ebnf$1',
    symbols: [],
    postprocess: function postprocess() {
      return null;
    }
  }, {
    name: 'arithmeticElement',
    symbols: ['arithmeticElement$ebnf$1', 'element'],
    postprocess: extractUnaryOperator
  }, {
    name: 'element',
    symbols: ['function'],
    postprocess: id
  }, {
    name: 'element',
    symbols: ['type', 'condition'],
    postprocess: formatQuery
  }, {
    name: 'element',
    symbols: ['number'],
    postprocess: extractNumber
  }, {
    name: 'element$string$1',
    symbols: [{
      literal: 'p'
    }, {
      literal: 'i'
    }, {
      literal: '('
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'element',
    symbols: ['element$string$1', '_', {
      literal: ')'
    }],
    postprocess: extractPI
  }, {
    name: 'type$string$1',
    symbols: [{
      literal: 't'
    }, {
      literal: 's'
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'type',
    symbols: ['type$string$1'],
    postprocess: id
  }, {
    name: 'type$string$2',
    symbols: [{
      literal: 'T'
    }, {
      literal: 'S'
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'type',
    symbols: ['type$string$2'],
    postprocess: function postprocess(_ref18) {
      var _ref19 = _slicedToArray(_ref18, 1),
          d = _ref19[0];

      return d.toLowerCase();
    }
  }, {
    name: 'condition',
    symbols: ['curl', 'CURL'],
    postprocess: emptyArray
  }, {
    name: 'condition$ebnf$1',
    symbols: []
  }, {
    name: 'condition$ebnf$1$subexpression$1',
    symbols: ['comma', 'pair']
  }, {
    name: 'condition$ebnf$1',
    symbols: ['condition$ebnf$1', 'condition$ebnf$1$subexpression$1'],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'condition',
    symbols: ['curl', 'pair', 'condition$ebnf$1', 'CURL'],
    postprocess: extractConditionToArray
  }, {
    name: 'string',
    symbols: ['sqstring'],
    postprocess: id
  }, {
    name: 'string',
    symbols: ['dqstring'],
    postprocess: id
  }, {
    name: 'string',
    symbols: ['variable'],
    postprocess: id
  }, {
    name: 'regexp_string',
    symbols: ['sqregexp'],
    postprocess: id
  }, {
    name: 'regexp_string',
    symbols: ['dqregexp'],
    postprocess: id
  }, {
    name: 'regexp_string',
    symbols: ['variable'],
    postprocess: id
  }, {
    name: 'array',
    symbols: ['sqr', 'SQR'],
    postprocess: emptyArray
  }, {
    name: 'array$ebnf$1',
    symbols: []
  }, {
    name: 'array$ebnf$1$subexpression$1',
    symbols: ['comma', 'value']
  }, {
    name: 'array$ebnf$1',
    symbols: ['array$ebnf$1', 'array$ebnf$1$subexpression$1'],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'array',
    symbols: ['sqr', 'value', 'array$ebnf$1', 'SQR'],
    postprocess: extractArray
  }, {
    name: 'object',
    symbols: ['curl', 'CURL'],
    postprocess: emptyObject
  }, {
    name: 'object$ebnf$1',
    symbols: []
  }, {
    name: 'object$ebnf$1$subexpression$1',
    symbols: ['comma', 'pair']
  }, {
    name: 'object$ebnf$1',
    symbols: ['object$ebnf$1', 'object$ebnf$1$subexpression$1'],
    postprocess: function postprocess(d) {
      return d[0].concat([d[1]]);
    }
  }, {
    name: 'object',
    symbols: ['curl', 'pair', 'object$ebnf$1', 'CURL'],
    postprocess: extractObject
  }, {
    name: 'pair',
    symbols: ['prop_name', '_', 'equals', '_', 'value'],
    postprocess: function postprocess(d) {
      return [d[0], d[2], d[4]];
    }
  }, {
    name: 'pair',
    symbols: ['prop_name', '_', 'not_equals', '_', 'primitive'],
    postprocess: function postprocess(d) {
      return [d[0], d[2], d[4]];
    }
  }, {
    name: 'pair',
    symbols: ['prop_name', '_', 'regexp', '_', 'regexp_string'],
    postprocess: function postprocess(d) {
      return [d[0], d[2], d[4]];
    }
  }, {
    name: 'variable',
    symbols: [{
      literal: '$'
    }, 'prop_name'],
    postprocess: joinArr
  }, {
    name: 'variable$string$1',
    symbols: [{
      literal: '['
    }, {
      literal: '['
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'variable$string$2',
    symbols: [{
      literal: ']'
    }, {
      literal: ']'
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'variable',
    symbols: ['variable$string$1', 'prop_name', 'variable$string$2'],
    postprocess: joinArr
  }, {
    name: 'variable',
    symbols: [{
      literal: '$'
    }, 'advanced_variable'],
    postprocess: joinArr
  }, {
    name: 'advanced_variable',
    symbols: [{
      literal: '{'
    }, 'prop_name', {
      literal: ':'
    }, 'prop_name', {
      literal: '}'
    }],
    postprocess: joinArr
  }, {
    name: 'unary_operator',
    symbols: ['_', {
      literal: '-'
    }, '_'],
    postprocess: extractOperator
  }, {
    name: 'operator',
    symbols: ['_', {
      literal: '+'
    }, '_'],
    postprocess: extractOperator
  }, {
    name: 'operator',
    symbols: ['_', {
      literal: '-'
    }, '_'],
    postprocess: extractOperator
  }, {
    name: 'operator',
    symbols: ['_', {
      literal: '/'
    }, '_'],
    postprocess: extractOperator
  }, {
    name: 'operator',
    symbols: ['_', {
      literal: '*'
    }, '_'],
    postprocess: extractOperator
  }, {
    name: 'comma',
    symbols: ['_', {
      literal: ','
    }, '_'],
    postprocess: function postprocess(d) {
      return d[1];
    }
  }, {
    name: 'unary$string$1',
    symbols: [{
      literal: 's'
    }, {
      literal: 'i'
    }, {
      literal: 'n'
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'unary',
    symbols: ['unary$string$1'],
    postprocess: id
  }, {
    name: 'unary$string$2',
    symbols: [{
      literal: 'c'
    }, {
      literal: 'o'
    }, {
      literal: 's'
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'unary',
    symbols: ['unary$string$2'],
    postprocess: id
  }, {
    name: 'unary$string$3',
    symbols: [{
      literal: 'l'
    }, {
      literal: 'n'
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'unary',
    symbols: ['unary$string$3'],
    postprocess: id
  }, {
    name: 'unary$string$4',
    symbols: [{
      literal: 's'
    }, {
      literal: 'q'
    }, {
      literal: 'r'
    }, {
      literal: 't'
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'unary',
    symbols: ['unary$string$4'],
    postprocess: id
  }, {
    name: 'unary$string$5',
    symbols: [{
      literal: 'e'
    }, {
      literal: 'x'
    }, {
      literal: 'p'
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'unary',
    symbols: ['unary$string$5'],
    postprocess: id
  }, {
    name: 'unary$string$6',
    symbols: [{
      literal: 'a'
    }, {
      literal: 'b'
    }, {
      literal: 's'
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'unary',
    symbols: ['unary$string$6'],
    postprocess: id
  }, {
    name: 'unary',
    symbols: [],
    postprocess: id
  }, {
    name: 'binary$string$1',
    symbols: [{
      literal: 'p'
    }, {
      literal: 'o'
    }, {
      literal: 'w'
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'binary',
    symbols: ['binary$string$1'],
    postprocess: id
  }, {
    name: 'binary$string$2',
    symbols: [{
      literal: 'r'
    }, {
      literal: 'o'
    }, {
      literal: 'u'
    }, {
      literal: 'n'
    }, {
      literal: 'd'
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'binary',
    symbols: ['binary$string$2'],
    postprocess: id
  }, {
    name: 'binary$string$3',
    symbols: [{
      literal: 'o'
    }, {
      literal: 'n'
    }, {
      literal: '_'
    }, {
      literal: 'e'
    }, {
      literal: 'r'
    }, {
      literal: 'r'
    }, {
      literal: 'o'
    }, {
      literal: 'r'
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'binary',
    symbols: ['binary$string$3'],
    postprocess: id
  }, {
    name: 'n_ary$string$1',
    symbols: [{
      literal: 'm'
    }, {
      literal: 'a'
    }, {
      literal: 'x'
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'n_ary',
    symbols: ['n_ary$string$1'],
    postprocess: id
  }, {
    name: 'n_ary$string$2',
    symbols: [{
      literal: 'm'
    }, {
      literal: 'i'
    }, {
      literal: 'n'
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'n_ary',
    symbols: ['n_ary$string$2'],
    postprocess: id
  }, {
    name: 'n_ary$string$3',
    symbols: [{
      literal: 'a'
    }, {
      literal: 'v'
    }, {
      literal: 'g'
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'n_ary',
    symbols: ['n_ary$string$3'],
    postprocess: id
  }, {
    name: 'n_ary$string$4',
    symbols: [{
      literal: 's'
    }, {
      literal: 'u'
    }, {
      literal: 'm'
    }],
    postprocess: function postprocess(d) {
      return d.join('');
    }
  }, {
    name: 'n_ary',
    symbols: ['n_ary$string$4'],
    postprocess: id
  }, {
    name: 'br',
    symbols: ['_', {
      literal: '('
    }],
    postprocess: null
  }, {
    name: 'BR',
    symbols: ['_', {
      literal: ')'
    }],
    postprocess: null
  }, {
    name: 'curl',
    symbols: ['_', {
      literal: '{'
    }],
    postprocess: null
  }, {
    name: 'CURL',
    symbols: ['_', {
      literal: '}'
    }],
    postprocess: null
  }, {
    name: 'sqr',
    symbols: ['_', {
      literal: '['
    }],
    postprocess: null
  }, {
    name: 'SQR',
    symbols: ['_', {
      literal: ']'
    }],
    postprocess: null
  }],
  ParserStart: 'query'
};
/* harmony default export */ __webpack_exports__["default"] = (grammar);

/***/ }),

/***/ "./parser/ts/index.ts":
/*!****************************!*\
  !*** ./parser/ts/index.ts ***!
  \****************************/
/*! exports provided: formQueriesForExpression, enrichWithDefaultAggregates, injectTSIdsInExpression, parse, generateAllPossiblePermutations, convertExpressionToLabel, getLabelsForExpression, getReferencedTimeseries, flattenServerQueryFilters, walk, getIndicesOfMultiaryFunctionArgs, extractFilters, getServerFilters, flattenClientQueryFilters, getClientFilters, composeSTSQuery, STSReference, STSFilter, Operator, Constant */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "formQueriesForExpression", function() { return formQueriesForExpression; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "enrichWithDefaultAggregates", function() { return enrichWithDefaultAggregates; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "injectTSIdsInExpression", function() { return injectTSIdsInExpression; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "parse", function() { return parse; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "generateAllPossiblePermutations", function() { return generateAllPossiblePermutations; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "convertExpressionToLabel", function() { return convertExpressionToLabel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLabelsForExpression", function() { return getLabelsForExpression; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getReferencedTimeseries", function() { return getReferencedTimeseries; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "flattenServerQueryFilters", function() { return flattenServerQueryFilters; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "walk", function() { return walk; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getIndicesOfMultiaryFunctionArgs", function() { return getIndicesOfMultiaryFunctionArgs; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "extractFilters", function() { return extractFilters; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getServerFilters", function() { return getServerFilters; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "flattenClientQueryFilters", function() { return flattenClientQueryFilters; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getClientFilters", function() { return getClientFilters; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "composeSTSQuery", function() { return composeSTSQuery; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "STSReference", function() { return STSReference; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "STSFilter", function() { return STSFilter; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Operator", function() { return Operator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Constant", function() { return Constant; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "../node_modules/tslib/tslib.es6.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash */ "lodash");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var nearley__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! nearley */ "../node_modules/nearley/lib/nearley.js");
/* harmony import */ var nearley__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(nearley__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _grammar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./grammar */ "./parser/ts/grammar.ts");
/* harmony import */ var _cdf_client__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../cdf/client */ "./cdf/client.ts");
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../types */ "./parser/types.ts");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../utils */ "./utils.ts");
/* harmony import */ var _events_assets_index__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../events-assets/index */ "./parser/events-assets/index.ts");
/* harmony import */ var deepdash_getFilterDeep__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! deepdash/getFilterDeep */ "../node_modules/deepdash/getFilterDeep.js");
/* harmony import */ var deepdash_getFilterDeep__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(deepdash_getFilterDeep__WEBPACK_IMPORTED_MODULE_8__);
function _toArray(arr) { return _arrayWithHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableRest(); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e2) { throw _e2; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e3) { didErr = true; err = _e3; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }










var filterDeep = deepdash_getFilterDeep__WEBPACK_IMPORTED_MODULE_8___default()(lodash__WEBPACK_IMPORTED_MODULE_1___default.a);
var compiledGrammar = nearley__WEBPACK_IMPORTED_MODULE_2__["Grammar"].fromCompiled(_grammar__WEBPACK_IMPORTED_MODULE_3__["default"]);
var formQueriesForExpression = function formQueriesForExpression(expression, target, connector, defaultInterval) {
  return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(void 0, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
    var rawParsed, aggregation, granularity, parsed, serverFilters, timeseries, clientFilters, clientFilteredTimeseries, multiaryFuncTsIndices, permutations, queryExpressions;
    return regeneratorRuntime.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            rawParsed = parse(expression);
            aggregation = target.aggregation, granularity = target.granularity;
            parsed = enrichWithDefaultAggregates(rawParsed, {
              granularity: granularity,
              aggregate: aggregation
            }, defaultInterval);
            serverFilters = getServerFilters(parsed);

            if (serverFilters.length) {
              _context2.next = 6;
              break;
            }

            return _context2.abrupt("return", [{
              expression: composeSTSQuery(parsed)
            }]);

          case 6:
            _context2.next = 8;
            return Promise.all(serverFilters.map(function (filter) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(void 0, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                var tsResult;
                return regeneratorRuntime.wrap(function _callee$(_context) {
                  while (1) {
                    switch (_context.prev = _context.next) {
                      case 0:
                        _context.next = 2;
                        return Object(_cdf_client__WEBPACK_IMPORTED_MODULE_4__["getTimeseries"])({
                          filter: filter
                        }, connector, false);

                      case 2:
                        tsResult = _context.sent;

                        if (tsResult.length) {
                          _context.next = 5;
                          break;
                        }

                        throw NoTimeseriesFound(expression, filter);

                      case 5:
                        return _context.abrupt("return", tsResult);

                      case 6:
                      case "end":
                        return _context.stop();
                    }
                  }
                }, _callee);
              }));
            }));

          case 8:
            timeseries = _context2.sent;
            clientFilters = getClientFilters(parsed);
            clientFilteredTimeseries = timeseries.map(function (arr, i) {
              return Object(_utils__WEBPACK_IMPORTED_MODULE_6__["applyFilters"])(arr, clientFilters[i]);
            });
            multiaryFuncTsIndices = getIndicesOfMultiaryFunctionArgs(parsed);
            permutations = generateAllPossiblePermutations(clientFilteredTimeseries, multiaryFuncTsIndices);
            queryExpressions = permutations.map(function (series) {
              return injectTSIdsInExpression(parsed, series);
            });

            if (queryExpressions.length) {
              _context2.next = 16;
              break;
            }

            throw NoTimeseriesFound(expression);

          case 16:
            return _context2.abrupt("return", queryExpressions.map(function (expression) {
              return {
                expression: expression
              };
            }));

          case 17:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));
};

var NoTimeseriesFound = function NoTimeseriesFound(expr, filter) {
  var where = filter ? " ".concat(JSON.stringify(filter)) : 's';
  return new Error("No timeseries found for filter".concat(where, " in expression ").concat(expr));
};
/**
 * Injects default values of aggregate and granularity (if it is not provided).s
 * @param parsedData: synthetic timeseries parsed data
 * @param target: {aggregation, granularity}
 * @param defaultInterval – interval that comes from grafana options
 * @return result – parsed data with default values of aggregation and granularity
 */


var enrichWithDefaultAggregates = function enrichWithDefaultAggregates(parsedData, _ref, defaultInterval) {
  var aggregate = _ref.aggregate,
      granularity = _ref.granularity;

  if (aggregate === 'none') {
    return parsedData;
  }

  var result = Object(lodash__WEBPACK_IMPORTED_MODULE_1__["cloneDeep"])(parsedData);
  var defaultValues = {
    aggregate: aggregate,
    granularity: granularity || defaultInterval
  };
  walk(result, function (obj) {
    if (isSTSReference(obj)) {
      Object.keys(defaultValues).forEach(function (key) {
        if (Object(lodash__WEBPACK_IMPORTED_MODULE_1__["findIndex"])(obj.query, ['path', key]) === -1) {
          obj.query.push(STSFilter(key, defaultValues[key]));
        }
      });
    }
  });
  return result;
};
var injectTSIdsInExpression = function injectTSIdsInExpression(parsedData, timeseries) {
  var i = 0;
  var exprWithSum = composeSTSQuery(parsedData, function (item) {
    if (isSTSReference(item) && !hasIdsFilter(item)) {
      var syntheticFilters = item.query.filter(isSTSAggregateFilter);
      var paramTSIds = timeseries[i++].map(function (_ref2) {
        var id = _ref2.id;
        return id;
      });
      var pseudoParsedSTS = paramTSIds.map(function (id) {
        return STSReference([STSFilter('id', id)].concat(_toConsumableArray(syntheticFilters)));
      });
      return pseudoParsedSTS.map(function (ts) {
        return composeSTSQuery(ts);
      }).join(', ');
    }
  });
  return flattenSumFunctions(exprWithSum);
};
var parse = function parse(s) {
  return Object(_events_assets_index__WEBPACK_IMPORTED_MODULE_7__["parseWith"])(new nearley__WEBPACK_IMPORTED_MODULE_2__["Parser"](compiledGrammar), s);
};
var generateAllPossiblePermutations = function generateAllPossiblePermutations(arrayOfArrays) {
  var lockIndices = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
  var res = [];

  for (var i = 0; i < arrayOfArrays.length; i++) {
    var locked = lockIndices.includes(i);

    var array = _toConsumableArray(arrayOfArrays[i]);

    if (res.length) {
      var temp = _toConsumableArray(res);

      var temptemp = [];

      var _iterator = _createForOfIteratorHelper(temp),
          _step;

      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var t = _step.value;

          if (locked) {
            temptemp.push([].concat(_toConsumableArray(t), [array]));
          } else {
            var _iterator2 = _createForOfIteratorHelper(array),
                _step2;

            try {
              for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
                var item = _step2.value;
                temptemp.push([].concat(_toConsumableArray(t), [[item]]));
              }
            } catch (err) {
              _iterator2.e(err);
            } finally {
              _iterator2.f();
            }
          }
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }

      res = [].concat(temptemp);
    } else {
      if (locked) {
        res = [[array]];
      } else {
        res = array.map(function (i) {
          return [[i]];
        });
      }
    }
  }

  return res;
};
var convertExpressionToLabel = function convertExpressionToLabel(expression, labelSrc, tsMap) {
  return composeSTSQuery(parse(expression), function (item) {
    if (isSTSReference(item)) {
      var _getIdFilters = getIdFilters(item),
          _getIdFilters2 = _slicedToArray(_getIdFilters, 1),
          value = _getIdFilters2[0].value;

      var serie = tsMap[String(value)];

      if (labelSrc) {
        return Object(_cdf_client__WEBPACK_IMPORTED_MODULE_4__["getLabelWithInjectedProps"])(labelSrc, serie);
      }

      return "".concat(serie.name || serie.externalId || serie.id);
    }
  });
};
var getLabelsForExpression = function getLabelsForExpression(expressions, labelSrc, connector) {
  return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(void 0, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
    var tsIds, tsUniqueIds, referencedTS, tsMap;
    return regeneratorRuntime.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            tsIds = getReferencedIdsInExpressions(expressions);
            tsUniqueIds = Object(lodash__WEBPACK_IMPORTED_MODULE_1__["uniqBy"])(tsIds, unwrapId);
            _context3.next = 4;
            return Object(_cdf_client__WEBPACK_IMPORTED_MODULE_4__["getTimeseries"])({
              items: tsUniqueIds
            }, connector, false);

          case 4:
            referencedTS = _context3.sent;
            tsMap = reduceTsToMap(referencedTS);
            return _context3.abrupt("return", expressions.map(function (expr) {
              return convertExpressionToLabel(expr, labelSrc, tsMap);
            }));

          case 7:
          case "end":
            return _context3.stop();
        }
      }
    }, _callee3);
  }));
};
var getReferencedTimeseries = function getReferencedTimeseries(route) {
  var idFilters = [];
  walk(route, function (obj) {
    if (isSTSReference(obj)) {
      var ids = getIdFilters(obj);
      idFilters = [].concat(_toConsumableArray(idFilters), _toConsumableArray(ids));
    }
  });
  return idFilters.map(function (_ref3) {
    var path = _ref3.path,
        value = _ref3.value;
    return _defineProperty({}, path, value);
  });
};
var flattenServerQueryFilters = function flattenServerQueryFilters(items) {
  return items.filter(isSTSFilter).reduce(function (res, filter) {
    var value;

    if (isByIdsQuery(filter.value)) {
      value = filter.value.map(function (item) {
        return flattenServerQueryFilters([item]);
      });
    } else if (isSTSFilterArr(filter.value)) {
      value = Object.assign(Object.assign({}, res[filter.path]), flattenServerQueryFilters(filter.value));
    } else if (isSTSFilterArr2d(filter.value)) {
      value = filter.value.map(flattenServerQueryFilters);
    } else {
      value = filter.value;
    }

    res[filter.path] = value;
    return res;
  }, {});
};
var walk = function walk(route, iterator) {
  if (Object(lodash__WEBPACK_IMPORTED_MODULE_1__["isArray"])(route)) {
    route.forEach(function (r) {
      return walk(r, iterator);
    });
  } else {
    iterator(route);

    if (isSTSFunction(route)) {
      walk(isMapFunction(route) ? route.args[0] : route.args, iterator);
    }
  }
};
var getIndicesOfMultiaryFunctionArgs = function getIndicesOfMultiaryFunctionArgs(route) {
  var responseArr = [];
  var argsIndices = [];
  var index = 0;
  walk(route, function (obj) {
    if (isMultiaryFunction(obj) && obj.args.length === 1) {
      argsIndices.push.apply(argsIndices, _toConsumableArray(obj.args));
    } else if (isSTSReference(obj) && !hasIdsFilter(obj)) {
      if (argsIndices.includes(obj)) {
        responseArr.push(index);
      }

      index++;
    }
  });
  return responseArr;
};
var extractFilters = function extractFilters(route, condition) {
  var extracted = [];
  walk(route, function (obj) {
    if (isSTSReference(obj) && !hasIdsFilter(obj)) {
      extracted.push(filterDeep(obj.query, condition));
    }
  });
  return extracted;
};
var getServerFilters = function getServerFilters(route) {
  var filter = function filter(_, __, parent) {
    return isServerFilter(parent) || !isSTSFilter(parent);
  };

  return extractFilters(route, filter).map(function (filters) {
    return flattenServerQueryFilters(filters || []);
  });
};
var flattenClientQueryFilters = function flattenClientQueryFilters(filters) {
  var path = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
  var res = [];
  filters.filter(isSTSFilter).forEach(function (filter) {
    if (isServerFilter(filter) && isSTSFilterArr(filter.value)) {
      res.push.apply(res, _toConsumableArray(flattenClientQueryFilters(filter.value, [].concat(_toConsumableArray(path), [filter.path]))));
    } else {
      res.push({
        path: [].concat(_toConsumableArray(path), [filter.path]).join('.'),
        value: filter.value,
        filter: filter.filter
      });
    }
  });
  return res;
};
var getClientFilters = function getClientFilters(route) {
  var filter = function filter(_, __, parent) {
    return isClientFilter(parent) || Object(lodash__WEBPACK_IMPORTED_MODULE_1__["isArray"])(parent.value);
  };

  return extractFilters(route, filter).map(function (filters) {
    return flattenClientQueryFilters(filters || []);
  });
};

var reverseSTSFilter = function reverseSTSFilter(_ref5) {
  var path = _ref5.path,
      filter = _ref5.filter,
      value = _ref5.value;
  return "".concat(path).concat(filter).concat(stringifyValue(value));
};

var stringifyValue = function stringifyValue(val) {
  var wrap = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;

  if (Object(lodash__WEBPACK_IMPORTED_MODULE_1__["isArray"])(val)) {
    var items = val.map(function (item) {
      return isSTSFilter(item) ? reverseSTSFilter(item) : stringifyValue(item);
    });
    var joinedStr = items.join(', ');

    if (wrap) {
      return isSTSFilterArr(val) ? "{".concat(joinedStr, "}") : "[".concat(joinedStr, "]");
    }

    return joinedStr;
  }

  return JSON.stringify(val);
};

var composeSTSQuery = function composeSTSQuery(target, custom) {
  var separateWith = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '';

  if (custom) {
    var customRes = custom(target);

    if (customRes !== undefined) {
      return customRes;
    }
  }

  if (Object(lodash__WEBPACK_IMPORTED_MODULE_1__["isArray"])(target)) {
    return target.map(function (i) {
      return composeSTSQuery(i, custom);
    }).join(separateWith);
  }

  if (isSTSReference(target)) {
    return "".concat(target.type, "{").concat(stringifyValue(target.query, false), "}");
  }

  if (isOperator(target)) {
    return " ".concat(target.operator, " ");
  }

  if (isWrappedConst(target)) {
    return "".concat(target.constant);
  }

  var separator = isMultiaryFunction(target) ? ', ' : '';
  var stringArgs = '';

  if (isMapFunction(target)) {
    var _target$args = _toArray(target.args),
        arg0 = _target$args[0],
        args = _target$args.slice(1);

    stringArgs = "".concat(composeSTSQuery(arg0, custom), ", ").concat(args.map(function (arg) {
      return stringifyValue(arg);
    }).join(', '));
  } else {
    stringArgs = composeSTSQuery(target.args, custom, separator);
  }

  return "".concat(target.func, "(").concat(stringArgs, ")");
};

var flattenSumFunctions = function flattenSumFunctions(expression) {
  return composeSTSQuery(parse(expression), function (item) {
    if (isSumFunction(item)) {
      return "(".concat(composeSTSQuery(item.args, null, ' + '), ")");
    }
  });
};

var unwrapId = function unwrapId(idEither) {
  if ('id' in idEither) {
    return idEither.id;
  }

  return idEither.externalId;
};

var getReferencedIdsInExpressions = function getReferencedIdsInExpressions(expressions) {
  var allIds = [];

  var _iterator3 = _createForOfIteratorHelper(expressions),
      _step3;

  try {
    for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
      var expression = _step3.value;
      var parsed = parse(expression);
      var referenced = getReferencedTimeseries(parsed);
      allIds.push.apply(allIds, _toConsumableArray(referenced));
    }
  } catch (err) {
    _iterator3.e(err);
  } finally {
    _iterator3.f();
  }

  return allIds;
};

var reduceTsToMap = function reduceTsToMap(timeseries) {
  return timeseries.reduce(function (map, serie) {
    map[serie.id] = serie;

    if (serie.externalId) {
      map[serie.externalId] = serie;
    }

    return map;
  }, {});
};

var STSReference = function STSReference() {
  var query = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
  return {
    query: query,
    type: 'ts'
  };
};
var STSFilter = function STSFilter(path, value) {
  var filter = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '=';
  return {
    path: path,
    value: value,
    filter: filter
  };
};
var Operator = function Operator(operator) {
  return {
    operator: operator
  };
};
var Constant = function Constant(constant) {
  return {
    constant: constant
  };
};

var getIdFilters = function getIdFilters(obj) {
  return obj.query.filter(isIdsFilter);
};

var hasIdsFilter = function hasIdsFilter(obj) {
  return getIdFilters(obj).length;
};

var isEqualsFilter = function isEqualsFilter(query) {
  return isSTSFilter(query) && query.filter === _types__WEBPACK_IMPORTED_MODULE_5__["FilterTypes"].Equals;
};

var isOneOf = function isOneOf(value) {
  for (var _len = arguments.length, arr = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
    arr[_key - 1] = arguments[_key];
  }

  return arr.indexOf(value) !== -1;
};

var isSTSAggregateFilter = function isSTSAggregateFilter(query) {
  return isEqualsFilter(query) && isOneOf(query.path, 'granularity', 'aggregate', 'alignment');
};

var isIdsFilter = function isIdsFilter(query) {
  return isEqualsFilter(query) && isOneOf(query.path, 'id', 'externalId');
};

var isServerFilter = function isServerFilter(item) {
  return isEqualsFilter(item) && !isSTSAggregateFilter(item);
};

var isClientFilter = function isClientFilter(item) {
  return isSTSFilter(item) && !isEqualsFilter(item);
};

var isByIdsQuery = function isByIdsQuery(query) {
  return Object(lodash__WEBPACK_IMPORTED_MODULE_1__["isArray"])(query) && query.some(isIdsFilter);
};

var isSTSFilter = function isSTSFilter(item) {
  return Object(lodash__WEBPACK_IMPORTED_MODULE_1__["isObjectLike"])(item) && item.path && item.filter && 'value' in item;
};

var isSTSFilterArr = function isSTSFilterArr(query) {
  return Object(lodash__WEBPACK_IMPORTED_MODULE_1__["isArray"])(query) && query.length && query.every(isSTSFilter);
};

var isSTSFilterArr2d = function isSTSFilterArr2d(query) {
  return Object(lodash__WEBPACK_IMPORTED_MODULE_1__["isArray"])(query) && query.every(isSTSFilterArr);
};

var isWrappedConst = function isWrappedConst(obj) {
  return Object(lodash__WEBPACK_IMPORTED_MODULE_1__["isObjectLike"])(obj) && 'constant' in obj;
};

var isSTSReference = function isSTSReference(obj) {
  return Object(lodash__WEBPACK_IMPORTED_MODULE_1__["isObjectLike"])(obj) && obj.type === 'ts';
};

var isOperator = function isOperator(obj) {
  return Object(lodash__WEBPACK_IMPORTED_MODULE_1__["isObjectLike"])(obj) && 'operator' in obj;
};

var isSTSFunction = function isSTSFunction(obj) {
  return Object(lodash__WEBPACK_IMPORTED_MODULE_1__["isObjectLike"])(obj) && 'args' in obj && 'func' in obj;
};

var isSpecificFunction = function isSpecificFunction(obj, name) {
  return isSTSFunction(obj) && name === obj.func;
};

var isMapFunction = function isMapFunction(obj) {
  return isSpecificFunction(obj, 'map');
};

var isSumFunction = function isSumFunction(obj) {
  return isSpecificFunction(obj, 'sum');
};

var isMultiaryFunction = function isMultiaryFunction(obj) {
  return isSTSFunction(obj) && isOneOf(obj.func, 'avg', 'sum', 'min', 'max', 'pow', 'round', 'on_error');
};

/***/ }),

/***/ "./parser/types.ts":
/*!*************************!*\
  !*** ./parser/types.ts ***!
  \*************************/
/*! exports provided: FilterTypes, QueryParserTypes */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FilterTypes", function() { return FilterTypes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QueryParserTypes", function() { return QueryParserTypes; });
var FilterTypes = {
  RegexNotEquals: '!~',
  RegexEquals: '=~',
  NotEquals: '!=',
  Equals: '='
};
var QueryParserTypes;

(function (QueryParserTypes) {
  QueryParserTypes["assets"] = "assets";
  QueryParserTypes["events"] = "events";
  QueryParserTypes["extractors"] = "extractors";
})(QueryParserTypes || (QueryParserTypes = {}));

/***/ }),

/***/ "./types.ts":
/*!******************!*\
  !*** ./types.ts ***!
  \******************/
/*! exports provided: Tab, TabTitles, defaultQuery, isError, HttpMethod, Result, Ok, Err */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab", function() { return Tab; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabTitles", function() { return TabTitles; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "defaultQuery", function() { return defaultQuery; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isError", function() { return isError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HttpMethod", function() { return HttpMethod; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Result", function() { return Result; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Ok", function() { return Ok; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Err", function() { return Err; });
var _TabTitles;

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var Tab;

(function (Tab) {
  Tab["Timeseries"] = "Timeseries";
  Tab["Asset"] = "Asset";
  Tab["Custom"] = "Custom";
  Tab["Event"] = "Event";
  Tab["Template"] = "Template";
  Tab["Extractor"] = "Extractor";
  Tab["Relationships"] = "Relationships";
})(Tab || (Tab = {}));

var TabTitles = (_TabTitles = {}, _defineProperty(_TabTitles, Tab.Timeseries, 'Time series search'), _defineProperty(_TabTitles, Tab.Asset, 'Time series from asset'), _defineProperty(_TabTitles, Tab.Custom, 'Time series custom query'), _defineProperty(_TabTitles, Tab.Event, 'Events'), _defineProperty(_TabTitles, Tab.Relationships, 'Relationships'), _TabTitles); // it is just a place to try integrate the Relationships query

var defaultRelationsShipQuery = {
  dataSetId: [],
  labels: [],
  refId: '',
  expr: {}
};
var defaultTemplateQuery = {
  domain: undefined,
  domainVersion: undefined,
  expr: "{\n    positionQuery {\n      items {\n        Speed {\n          name\n          aggregatedDatapoints(\n            granularity: $__granularity\n            start: $__from\n            end: $__to\n          ) {\n          average {\n            timestamp\n            value\n          }\n          max {\n            timestamp\n            value\n            }\n          }\n        }\n      }\n    }\n  }",
  dataPath: 'positionQuery.items',
  dataPointsPath: 'Speed.aggregatedDatapoints.average',
  groupBy: 'Speed.name',
  aliasBy: '',
  annotationTitle: '',
  annotationText: '',
  annotationTags: '',
  constant: 6.5,
  refId: ''
};
var defaultAssetQuery = {
  includeSubtrees: false,
  target: ''
};
var defaultEventQuery = {
  expr: '',
  columns: ['externalId', 'type', 'subtype', 'description', 'startTime', 'endTime'],
  activeAtTimeRange: true
};
var defaultQuery = {
  target: '',
  latestValue: false,
  aggregation: 'average',
  granularity: '',
  label: '',
  tab: Tab.Timeseries,
  expr: '',
  assetQuery: defaultAssetQuery,
  eventQuery: defaultEventQuery,
  templateQuery: defaultTemplateQuery,
  relationsShipsQuery: defaultRelationsShipQuery
};
/**
 * Value that is used in the backend, but never sent over HTTP to the frontend
 */

function isError(maybeError) {
  return maybeError.error !== undefined;
}
var HttpMethod;

(function (HttpMethod) {
  HttpMethod["POST"] = "POST";
  HttpMethod["GET"] = "GET";
  HttpMethod["PATCH"] = "PATCH";
  HttpMethod["DELETE"] = "DELETE";
})(HttpMethod || (HttpMethod = {}));

var Result = /*#__PURE__*/_createClass(function Result() {
  _classCallCheck(this, Result);
});
var Ok = /*#__PURE__*/_createClass(function Ok(v) {
  _classCallCheck(this, Ok);

  this.isOk = true;
  this.isErr = false;
  this.value = v;
});
var Err = /*#__PURE__*/_createClass(function Err(error) {
  _classCallCheck(this, Err);

  this.isOk = false;
  this.isErr = true;
  this.error = error;
});

/***/ }),

/***/ "./utils.ts":
/*!******************!*\
  !*** ./utils.ts ***!
  \******************/
/*! exports provided: getQueryString, toGranularityWithLowerBound, getRequestId, applyFilters, checkFilter, getDataPathArray, createDatapointsDataFrame, getDocs */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getQueryString", function() { return getQueryString; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "toGranularityWithLowerBound", function() { return toGranularityWithLowerBound; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getRequestId", function() { return getRequestId; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "applyFilters", function() { return applyFilters; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "checkFilter", function() { return checkFilter; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getDataPathArray", function() { return getDataPathArray; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createDatapointsDataFrame", function() { return createDatapointsDataFrame; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getDocs", function() { return getDocs; });
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash */ "lodash");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var query_string__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! query-string */ "../node_modules/query-string/index.js");
/* harmony import */ var query_string__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(query_string__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var ms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ms */ "../node_modules/ms/index.js");
/* harmony import */ var ms__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(ms__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _grafana_data__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @grafana/data */ "@grafana/data");
/* harmony import */ var _grafana_data__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_grafana_data__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _parser_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./parser/types */ "./parser/types.ts");





function getQueryString(obj) {
  return Object(query_string__WEBPACK_IMPORTED_MODULE_1__["stringify"])(Object(lodash__WEBPACK_IMPORTED_MODULE_0__["omitBy"])(obj, lodash__WEBPACK_IMPORTED_MODULE_0__["isNil"]));
}
function toGranularityWithLowerBound(milliseconds) {
  var lowerBound = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1000;
  return ms__WEBPACK_IMPORTED_MODULE_2___default()(Math.max(milliseconds, lowerBound));
} // used for generating the options.requestId

function getRequestId(options, target) {
  return "".concat(options.dashboardId, "_").concat(options.panelId, "_").concat(target.refId);
}
var applyFilters = function applyFilters(objs, filters) {
  if (!filters.length) {
    return objs;
  }

  return objs.filter(function (obj) {
    return filters.every(function (filter) {
      return checkFilter(obj, filter);
    });
  });
};
var checkFilter = function checkFilter(obj, _ref) {
  var path = _ref.path,
      filter = _ref.filter,
      value = _ref.value;
  var valueToFilter = Object(lodash__WEBPACK_IMPORTED_MODULE_0__["get"])(obj, path, null);
  var regex = new RegExp("^".concat(value, "$"));

  switch (filter) {
    case _parser_types__WEBPACK_IMPORTED_MODULE_4__["FilterTypes"].RegexEquals:
      return regex.test(valueToFilter);

    case _parser_types__WEBPACK_IMPORTED_MODULE_4__["FilterTypes"].RegexNotEquals:
      return !regex.test(valueToFilter);

    case _parser_types__WEBPACK_IMPORTED_MODULE_4__["FilterTypes"].NotEquals:
      return value !== valueToFilter;

    default:
      return false;
  }
}; // Template

var getDataPathArray = function getDataPathArray(dataPathString) {
  var dataPathArray = [];
  Object(lodash__WEBPACK_IMPORTED_MODULE_0__["map"])(Object(lodash__WEBPACK_IMPORTED_MODULE_0__["split"])(dataPathString, ','), function (dataPath) {
    var trimmed = dataPath.trim();

    if (trimmed) {
      dataPathArray.push(trimmed);
    }
  });

  if (!dataPathArray) {
    throw 'data path is empty!';
  }

  return dataPathArray;
};
var createDatapointsDataFrame = function createDatapointsDataFrame(name, refId) {
  return new _grafana_data__WEBPACK_IMPORTED_MODULE_3__["MutableDataFrame"]({
    name: name,
    refId: refId,
    fields: [{
      name: 'timestamp',
      type: _grafana_data__WEBPACK_IMPORTED_MODULE_3__["FieldType"].time
    }, {
      name: 'value',
      type: _grafana_data__WEBPACK_IMPORTED_MODULE_3__["FieldType"].number,
      config: {
        displayName: name
      }
    }]
  });
};
var getDocs = function getDocs(resultsData, dataPath) {
  if (!resultsData) {
    throw 'resultsData was null or undefined';
  }

  var data = dataPath.split('.').reduce(function (d, p) {
    if (!d) {
      return null;
    }

    return d[p];
  }, resultsData.data);

  if (!data) {
    var errors = resultsData.errors;

    if (errors && errors.length !== 0) {
      throw errors[0];
    }

    throw "Your data path did not exist! dataPath: ".concat(dataPath);
  }

  if (resultsData.errors) {
    // There can still be errors even if there is data

    /* eslint-disable-next-line no-console  */
    console.log('Got GraphQL errors:', resultsData.errors);
  }

  return data;
}; // till here

/***/ }),

/***/ "./utils2.ts":
/*!*******************!*\
  !*** ./utils2.ts ***!
  \*******************/
/*! exports provided: nodesFrame, edgesFrame */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "nodesFrame", function() { return nodesFrame; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "edgesFrame", function() { return edgesFrame; });
/* harmony import */ var _grafana_data__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @grafana/data */ "@grafana/data");
/* harmony import */ var _grafana_data__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_grafana_data__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash */ "lodash");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);
function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



function nodesFrame(iterer) {
  var fields = {
    id: {
      type: _grafana_data__WEBPACK_IMPORTED_MODULE_0__["FieldType"].string
    },
    title: {
      type: _grafana_data__WEBPACK_IMPORTED_MODULE_0__["FieldType"].string
    },
    mainStat: {
      type: _grafana_data__WEBPACK_IMPORTED_MODULE_0__["FieldType"].string
    }
  };
  Object(lodash__WEBPACK_IMPORTED_MODULE_1__["map"])(iterer, function (key) {
    Object(lodash__WEBPACK_IMPORTED_MODULE_1__["assignIn"])(fields, _defineProperty({}, Object(lodash__WEBPACK_IMPORTED_MODULE_1__["join"])(['detail__', Object(lodash__WEBPACK_IMPORTED_MODULE_1__["split"])(key, ' ')], ''), {
      type: _grafana_data__WEBPACK_IMPORTED_MODULE_0__["FieldType"].string,
      config: {
        displayName: key
      }
    }));
  });
  return new _grafana_data__WEBPACK_IMPORTED_MODULE_0__["MutableDataFrame"]({
    name: 'nodes',
    fields: Object.keys(fields).map(function (key) {
      return Object.assign(Object.assign({}, fields[key]), {
        name: key
      });
    }),
    meta: {
      preferredVisualisationType: 'nodeGraph'
    }
  });
}
function edgesFrame() {
  var fields = {
    id: {
      type: _grafana_data__WEBPACK_IMPORTED_MODULE_0__["FieldType"].string
    },
    source: {
      type: _grafana_data__WEBPACK_IMPORTED_MODULE_0__["FieldType"].string
    },
    target: {
      type: _grafana_data__WEBPACK_IMPORTED_MODULE_0__["FieldType"].string
    },
    mainStat: {
      type: _grafana_data__WEBPACK_IMPORTED_MODULE_0__["FieldType"].string
    }
  };
  return new _grafana_data__WEBPACK_IMPORTED_MODULE_0__["MutableDataFrame"]({
    name: 'edges',
    fields: Object.keys(fields).map(function (key) {
      return Object.assign(Object.assign({}, fields[key]), {
        name: key
      });
    }),
    meta: {
      preferredVisualisationType: 'nodeGraph'
    }
  });
}

/***/ }),

/***/ "@grafana/data":
/*!********************************!*\
  !*** external "@grafana/data" ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE__grafana_data__;

/***/ }),

/***/ "@grafana/runtime":
/*!***********************************!*\
  !*** external "@grafana/runtime" ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE__grafana_runtime__;

/***/ }),

/***/ "@grafana/ui":
/*!******************************!*\
  !*** external "@grafana/ui" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE__grafana_ui__;

/***/ }),

/***/ "lodash":
/*!*************************!*\
  !*** external "lodash" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE_lodash__;

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE_react__;

/***/ })

/******/ })});;
//# sourceMappingURL=module.js.map